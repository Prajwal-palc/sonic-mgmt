      3840632 K total memory
      2717436 K used memory
       415620 K active memory
      2637944 K inactive memory
       246100 K free memory
        51952 K buffer memory
      1101288 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       229651 non-nice user cpu ticks
         1808 nice user cpu ticks
        82092 system cpu ticks
       835556 idle cpu ticks
          311 IO-wait cpu ticks
            0 IRQ cpu ticks
         8584 softirq cpu ticks
          141 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       952116 K paged in
       332856 K paged out
            0 pages swapped in
            0 pages swapped out
      5534470 interrupts
     24860860 CPU context switches
   1765948401 boot time
        36035 forks
