      3840636 K total memory
      2618388 K used memory
       435580 K active memory
      2619252 K inactive memory
       288840 K free memory
        59164 K buffer memory
      1150972 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       218113 non-nice user cpu ticks
         1863 nice user cpu ticks
        75346 system cpu ticks
       768293 idle cpu ticks
          297 IO-wait cpu ticks
            0 IRQ cpu ticks
         7555 softirq cpu ticks
          128 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       940968 K paged in
       351172 K paged out
            0 pages swapped in
            0 pages swapped out
      5162268 interrupts
     23243716 CPU context switches
   1765949270 boot time
        38014 forks
