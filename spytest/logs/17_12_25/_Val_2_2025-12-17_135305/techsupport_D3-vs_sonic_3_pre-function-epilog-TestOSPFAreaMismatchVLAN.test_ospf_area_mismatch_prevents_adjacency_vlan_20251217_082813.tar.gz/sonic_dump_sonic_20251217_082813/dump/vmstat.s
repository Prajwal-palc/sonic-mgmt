      3840620 K total memory
      2679216 K used memory
       396624 K active memory
      2640276 K inactive memory
       278776 K free memory
        52084 K buffer memory
      1106300 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       228751 non-nice user cpu ticks
         2001 nice user cpu ticks
        80970 system cpu ticks
       838272 idle cpu ticks
          210 IO-wait cpu ticks
            0 IRQ cpu ticks
         8302 softirq cpu ticks
          125 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       917604 K paged in
       327972 K paged out
            0 pages swapped in
            0 pages swapped out
      5350148 interrupts
     24414663 CPU context switches
   1765948397 boot time
        35857 forks
