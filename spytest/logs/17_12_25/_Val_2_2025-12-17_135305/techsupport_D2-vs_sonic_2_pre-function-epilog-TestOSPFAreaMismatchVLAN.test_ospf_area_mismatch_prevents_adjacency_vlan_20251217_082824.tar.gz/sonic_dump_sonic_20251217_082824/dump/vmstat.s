      3840632 K total memory
      2672016 K used memory
       423360 K active memory
      2623856 K inactive memory
       275060 K free memory
        52860 K buffer memory
      1116624 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       226286 non-nice user cpu ticks
         1793 nice user cpu ticks
        78580 system cpu ticks
       843615 idle cpu ticks
          335 IO-wait cpu ticks
            0 IRQ cpu ticks
         8143 softirq cpu ticks
          129 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       953802 K paged in
       334288 K paged out
            0 pages swapped in
            0 pages swapped out
      5411394 interrupts
     24733283 CPU context switches
   1765948394 boot time
        36217 forks
