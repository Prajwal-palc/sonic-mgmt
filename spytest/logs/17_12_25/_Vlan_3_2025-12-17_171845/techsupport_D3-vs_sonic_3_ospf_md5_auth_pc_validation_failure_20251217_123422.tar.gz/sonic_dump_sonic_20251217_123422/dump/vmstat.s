      3840620 K total memory
      2755296 K used memory
       497408 K active memory
      2523288 K inactive memory
       273620 K free memory
        96064 K buffer memory
      1001212 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       541394 non-nice user cpu ticks
        23742 nice user cpu ticks
       206117 system cpu ticks
      1819389 idle cpu ticks
          778 IO-wait cpu ticks
            0 IRQ cpu ticks
        23399 softirq cpu ticks
          302 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1207087 K paged in
       672600 K paged out
            0 pages swapped in
            0 pages swapped out
     15419650 interrupts
     64251324 CPU context switches
   1765948397 boot time
       125459 forks
