      3840632 K total memory
      2756952 K used memory
       476760 K active memory
      2524016 K inactive memory
       292628 K free memory
        96668 K buffer memory
       980468 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       538464 non-nice user cpu ticks
        21230 nice user cpu ticks
       198351 system cpu ticks
      1731953 idle cpu ticks
          756 IO-wait cpu ticks
            0 IRQ cpu ticks
        23502 softirq cpu ticks
          288 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1240652 K paged in
       669004 K paged out
            0 pages swapped in
            0 pages swapped out
     17843015 interrupts
     63956795 CPU context switches
   1765948394 boot time
       125509 forks
