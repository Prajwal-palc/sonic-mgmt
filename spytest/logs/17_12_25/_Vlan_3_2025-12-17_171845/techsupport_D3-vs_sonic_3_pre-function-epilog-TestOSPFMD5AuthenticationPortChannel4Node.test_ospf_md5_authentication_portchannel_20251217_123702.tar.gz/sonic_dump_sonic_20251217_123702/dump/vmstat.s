      3840620 K total memory
      2744260 K used memory
       494420 K active memory
      2511276 K inactive memory
       285532 K free memory
        96276 K buffer memory
      1000388 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       544823 non-nice user cpu ticks
        26090 nice user cpu ticks
       209072 system cpu ticks
      1826397 idle cpu ticks
          781 IO-wait cpu ticks
            0 IRQ cpu ticks
        23520 softirq cpu ticks
          305 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1216260 K paged in
       699336 K paged out
            0 pages swapped in
            0 pages swapped out
     15547227 interrupts
     64854796 CPU context switches
   1765948397 boot time
       131539 forks
