      3840632 K total memory
      2715008 K used memory
       446624 K active memory
      2456488 K inactive memory
       428100 K free memory
        98392 K buffer memory
       884660 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       565331 non-nice user cpu ticks
        25989 nice user cpu ticks
       210693 system cpu ticks
      1803161 idle cpu ticks
          797 IO-wait cpu ticks
            0 IRQ cpu ticks
        24390 softirq cpu ticks
          300 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1300879 K paged in
       726424 K paged out
            0 pages swapped in
            0 pages swapped out
     18526849 interrupts
     67170811 CPU context switches
   1765948394 boot time
       141574 forks
