      3840636 K total memory
      2841024 K used memory
       492140 K active memory
      2612548 K inactive memory
       202396 K free memory
        94860 K buffer memory
       987884 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       504524 non-nice user cpu ticks
        18600 nice user cpu ticks
       189894 system cpu ticks
      1660723 idle cpu ticks
          747 IO-wait cpu ticks
            0 IRQ cpu ticks
        21149 softirq cpu ticks
          308 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1208729 K paged in
       654820 K paged out
            0 pages swapped in
            0 pages swapped out
     15274705 interrupts
     62707830 CPU context switches
   1765949270 boot time
       113656 forks
