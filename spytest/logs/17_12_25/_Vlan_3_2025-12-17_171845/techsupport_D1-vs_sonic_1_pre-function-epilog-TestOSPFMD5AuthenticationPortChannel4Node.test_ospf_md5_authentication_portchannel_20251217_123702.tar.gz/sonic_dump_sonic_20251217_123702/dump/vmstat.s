      3840636 K total memory
      2788420 K used memory
       488256 K active memory
      2556656 K inactive memory
       253268 K free memory
        98688 K buffer memory
       987756 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       535832 non-nice user cpu ticks
        26090 nice user cpu ticks
       205440 system cpu ticks
      1753348 idle cpu ticks
          792 IO-wait cpu ticks
            0 IRQ cpu ticks
        22277 softirq cpu ticks
          324 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1240887 K paged in
       727096 K paged out
            0 pages swapped in
            0 pages swapped out
     16155539 interrupts
     66752032 CPU context switches
   1765949270 boot time
       134936 forks
