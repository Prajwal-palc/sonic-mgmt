      3840632 K total memory
      2732048 K used memory
       482064 K active memory
      2530980 K inactive memory
       306304 K free memory
        96160 K buffer memory
       992260 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       533592 non-nice user cpu ticks
        18827 nice user cpu ticks
       195045 system cpu ticks
      1718622 idle cpu ticks
          748 IO-wait cpu ticks
            0 IRQ cpu ticks
        23320 softirq cpu ticks
          285 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1226330 K paged in
       650632 K paged out
            0 pages swapped in
            0 pages swapped out
     17677823 interrupts
     63197589 CPU context switches
   1765948394 boot time
       119259 forks
