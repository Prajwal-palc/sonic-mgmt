      3840632 K total memory
      2906552 K used memory
       424408 K active memory
      2575784 K inactive memory
       321076 K free memory
        95028 K buffer memory
       801892 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       556234 non-nice user cpu ticks
        20973 nice user cpu ticks
       213843 system cpu ticks
      1697727 idle cpu ticks
          846 IO-wait cpu ticks
            0 IRQ cpu ticks
        24698 softirq cpu ticks
          314 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1336269 K paged in
       714168 K paged out
            0 pages swapped in
            0 pages swapped out
     17604987 interrupts
     76259489 CPU context switches
   1765948401 boot time
       125438 forks
