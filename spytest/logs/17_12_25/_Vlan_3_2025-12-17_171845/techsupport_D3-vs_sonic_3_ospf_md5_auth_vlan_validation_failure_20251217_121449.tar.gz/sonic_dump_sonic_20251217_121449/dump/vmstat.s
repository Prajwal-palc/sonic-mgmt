      3840620 K total memory
      2723168 K used memory
       497840 K active memory
      2519184 K inactive memory
       298380 K free memory
        92884 K buffer memory
      1011512 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       517181 non-nice user cpu ticks
        18972 nice user cpu ticks
       194484 system cpu ticks
      1745307 idle cpu ticks
          727 IO-wait cpu ticks
            0 IRQ cpu ticks
        22512 softirq cpu ticks
          284 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1171072 K paged in
       623180 K paged out
            0 pages swapped in
            0 pages swapped out
     14764926 interrupts
     61189463 CPU context switches
   1765948397 boot time
       110598 forks
