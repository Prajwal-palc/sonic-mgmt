      3840632 K total memory
      2920276 K used memory
       415724 K active memory
      2576860 K inactive memory
       316704 K free memory
        97376 K buffer memory
       790540 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       582241 non-nice user cpu ticks
        23379 nice user cpu ticks
       224190 system cpu ticks
      1766891 idle cpu ticks
          881 IO-wait cpu ticks
            0 IRQ cpu ticks
        25603 softirq cpu ticks
          326 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1352171 K paged in
       755760 K paged out
            0 pages swapped in
            0 pages swapped out
     18223293 interrupts
     79110774 CPU context switches
   1765948401 boot time
       135619 forks
