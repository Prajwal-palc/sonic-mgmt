      3840632 K total memory
      2737156 K used memory
       470120 K active memory
      2513356 K inactive memory
       326780 K free memory
        99004 K buffer memory
       964052 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       560658 non-nice user cpu ticks
        23601 nice user cpu ticks
       207419 system cpu ticks
      1789536 idle cpu ticks
          785 IO-wait cpu ticks
            0 IRQ cpu ticks
        24210 softirq cpu ticks
          297 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1264725 K paged in
       705688 K paged out
            0 pages swapped in
            0 pages swapped out
     18361379 interrupts
     66406263 CPU context switches
   1765948394 boot time
       135409 forks
