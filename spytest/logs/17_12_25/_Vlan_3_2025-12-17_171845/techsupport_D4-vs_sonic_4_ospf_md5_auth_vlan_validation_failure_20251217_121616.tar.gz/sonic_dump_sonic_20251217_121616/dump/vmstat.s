      3840632 K total memory
      2915932 K used memory
       429764 K active memory
      2575736 K inactive memory
       305380 K free memory
        95100 K buffer memory
       809816 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       554616 non-nice user cpu ticks
        18578 nice user cpu ticks
       211703 system cpu ticks
      1696846 idle cpu ticks
          845 IO-wait cpu ticks
            0 IRQ cpu ticks
        24643 softirq cpu ticks
          313 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1326627 K paged in
       696200 K paged out
            0 pages swapped in
            0 pages swapped out
     17519730 interrupts
     75850081 CPU context switches
   1765948401 boot time
       119496 forks
