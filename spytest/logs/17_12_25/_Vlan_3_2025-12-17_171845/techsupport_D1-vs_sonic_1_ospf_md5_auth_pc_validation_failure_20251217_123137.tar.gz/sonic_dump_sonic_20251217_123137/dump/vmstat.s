      3840636 K total memory
      2753980 K used memory
       489236 K active memory
      2502728 K inactive memory
       288616 K free memory
        98008 K buffer memory
       987388 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       529687 non-nice user cpu ticks
        23713 nice user cpu ticks
       201744 system cpu ticks
      1733899 idle cpu ticks
          781 IO-wait cpu ticks
            0 IRQ cpu ticks
        22031 softirq cpu ticks
          320 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1226821 K paged in
       705900 K paged out
            0 pages swapped in
            0 pages swapped out
     15956119 interrupts
     65834193 CPU context switches
   1765949270 boot time
       128679 forks
