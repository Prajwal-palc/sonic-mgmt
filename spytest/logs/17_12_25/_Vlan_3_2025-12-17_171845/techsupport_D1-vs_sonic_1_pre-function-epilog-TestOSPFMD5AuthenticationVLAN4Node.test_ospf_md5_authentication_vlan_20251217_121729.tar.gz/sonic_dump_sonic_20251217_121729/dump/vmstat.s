      3840636 K total memory
      2746744 K used memory
       492596 K active memory
      2495248 K inactive memory
       293032 K free memory
        95828 K buffer memory
       991056 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       511154 non-nice user cpu ticks
        21233 nice user cpu ticks
       193983 system cpu ticks
      1679952 idle cpu ticks
          756 IO-wait cpu ticks
            0 IRQ cpu ticks
        21415 softirq cpu ticks
          312 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1215457 K paged in
       674864 K paged out
            0 pages swapped in
            0 pages swapped out
     15491319 interrupts
     63680093 CPU context switches
   1765949270 boot time
       120002 forks
