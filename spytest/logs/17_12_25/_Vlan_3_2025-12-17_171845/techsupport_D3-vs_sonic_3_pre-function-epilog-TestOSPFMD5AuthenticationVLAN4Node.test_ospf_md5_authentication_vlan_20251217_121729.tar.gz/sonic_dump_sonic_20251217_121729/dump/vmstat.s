      3840620 K total memory
      2719328 K used memory
       491616 K active memory
      2515072 K inactive memory
       311424 K free memory
        92856 K buffer memory
      1002348 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       520113 non-nice user cpu ticks
        21350 nice user cpu ticks
       197177 system cpu ticks
      1752447 idle cpu ticks
          735 IO-wait cpu ticks
            0 IRQ cpu ticks
        22641 softirq cpu ticks
          288 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1183312 K paged in
       638796 K paged out
            0 pages swapped in
            0 pages swapped out
     14884785 interrupts
     61764105 CPU context switches
   1765948397 boot time
       116636 forks
