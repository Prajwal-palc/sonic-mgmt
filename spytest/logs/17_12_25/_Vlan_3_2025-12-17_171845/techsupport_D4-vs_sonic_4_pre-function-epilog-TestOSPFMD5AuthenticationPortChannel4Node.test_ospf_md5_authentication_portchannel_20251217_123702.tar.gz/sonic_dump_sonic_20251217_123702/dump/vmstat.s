      3840632 K total memory
      2923000 K used memory
       420720 K active memory
      2575020 K inactive memory
       310436 K free memory
        97608 K buffer memory
       793988 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       583887 non-nice user cpu ticks
        25799 nice user cpu ticks
       226349 system cpu ticks
      1767679 idle cpu ticks
          882 IO-wait cpu ticks
            0 IRQ cpu ticks
        25670 softirq cpu ticks
          327 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1366026 K paged in
       776892 K paged out
            0 pages swapped in
            0 pages swapped out
     18309770 interrupts
     79525167 CPU context switches
   1765948401 boot time
       141514 forks
