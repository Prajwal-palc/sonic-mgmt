      3840620 K total memory
      2701236 K used memory
       482640 K active memory
      2529468 K inactive memory
       291000 K free memory
        74032 K buffer memory
      1055624 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       383727 non-nice user cpu ticks
        11677 nice user cpu ticks
       144664 system cpu ticks
      1319037 idle cpu ticks
          524 IO-wait cpu ticks
            0 IRQ cpu ticks
        17665 softirq cpu ticks
          205 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1088299 K paged in
       487084 K paged out
            0 pages swapped in
            0 pages swapped out
     11572352 interrupts
     46794773 CPU context switches
   1765948397 boot time
        75480 forks
