      3840632 K total memory
      2908196 K used memory
       387776 K active memory
      2590720 K inactive memory
       359828 K free memory
        72716 K buffer memory
       777808 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       407391 non-nice user cpu ticks
        11242 nice user cpu ticks
       158275 system cpu ticks
      1279396 idle cpu ticks
          604 IO-wait cpu ticks
            0 IRQ cpu ticks
        19620 softirq cpu ticks
          239 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1269080 K paged in
       545296 K paged out
            0 pages swapped in
            0 pages swapped out
     14145107 interrupts
     60644800 CPU context switches
   1765948401 boot time
        79112 forks
