      3840632 K total memory
      2981772 K used memory
       408524 K active memory
      2661048 K inactive memory
       244876 K free memory
        73164 K buffer memory
       821112 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       405464 non-nice user cpu ticks
         8860 nice user cpu ticks
       155984 system cpu ticks
      1278568 idle cpu ticks
          596 IO-wait cpu ticks
            0 IRQ cpu ticks
        19546 softirq cpu ticks
          236 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1221128 K paged in
       522564 K paged out
            0 pages swapped in
            0 pages swapped out
     14053589 interrupts
     60209571 CPU context switches
   1765948401 boot time
        72980 forks
