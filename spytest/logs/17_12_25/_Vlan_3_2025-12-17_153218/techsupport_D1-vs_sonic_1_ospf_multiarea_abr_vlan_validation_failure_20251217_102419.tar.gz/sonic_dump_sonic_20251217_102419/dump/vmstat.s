      3840636 K total memory
      2698620 K used memory
       485048 K active memory
      2542804 K inactive memory
       278012 K free memory
        77020 K buffer memory
      1068624 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       369403 non-nice user cpu ticks
         9032 nice user cpu ticks
       138146 system cpu ticks
      1225105 idle cpu ticks
          518 IO-wait cpu ticks
            0 IRQ cpu ticks
        16370 softirq cpu ticks
          217 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1092143 K paged in
       499084 K paged out
            0 pages swapped in
            0 pages swapped out
     11909916 interrupts
     47522449 CPU context switches
   1765949270 boot time
        71143 forks
