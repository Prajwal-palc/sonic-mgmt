      3840636 K total memory
      2672876 K used memory
       494668 K active memory
      2524144 K inactive memory
       313652 K free memory
        77848 K buffer memory
      1057992 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       375211 non-nice user cpu ticks
        11323 nice user cpu ticks
       141660 system cpu ticks
      1244442 idle cpu ticks
          528 IO-wait cpu ticks
            0 IRQ cpu ticks
        16607 softirq cpu ticks
          220 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1110053 K paged in
       515440 K paged out
            0 pages swapped in
            0 pages swapped out
     12104369 interrupts
     48422331 CPU context switches
   1765949270 boot time
        77468 forks
