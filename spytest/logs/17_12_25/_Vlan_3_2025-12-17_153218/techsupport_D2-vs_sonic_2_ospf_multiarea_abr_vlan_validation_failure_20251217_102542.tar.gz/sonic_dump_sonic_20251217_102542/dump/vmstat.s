      3840632 K total memory
      2706560 K used memory
       474460 K active memory
      2542212 K inactive memory
       289576 K free memory
        76556 K buffer memory
      1050160 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       386293 non-nice user cpu ticks
         9010 nice user cpu ticks
       139464 system cpu ticks
      1299094 idle cpu ticks
          556 IO-wait cpu ticks
            0 IRQ cpu ticks
        18508 softirq cpu ticks
          205 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1116312 K paged in
       489960 K paged out
            0 pages swapped in
            0 pages swapped out
     14277507 interrupts
     47736238 CPU context switches
   1765948394 boot time
        72880 forks
