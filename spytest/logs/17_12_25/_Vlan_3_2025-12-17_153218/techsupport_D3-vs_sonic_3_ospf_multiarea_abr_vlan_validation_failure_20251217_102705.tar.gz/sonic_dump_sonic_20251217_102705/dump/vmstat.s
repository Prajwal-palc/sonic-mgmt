      3840620 K total memory
      2712240 K used memory
       478416 K active memory
      2547620 K inactive memory
       266000 K free memory
        73472 K buffer memory
      1070044 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       380379 non-nice user cpu ticks
         9303 nice user cpu ticks
       142013 system cpu ticks
      1312090 idle cpu ticks
          518 IO-wait cpu ticks
            0 IRQ cpu ticks
        17553 softirq cpu ticks
          203 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1075525 K paged in
       463664 K paged out
            0 pages swapped in
            0 pages swapped out
     11449662 interrupts
     46217450 CPU context switches
   1765948397 boot time
        69250 forks
