      3840632 K total memory
      2716096 K used memory
       474144 K active memory
      2531512 K inactive memory
       296100 K free memory
        77404 K buffer memory
      1033324 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       390941 non-nice user cpu ticks
        11420 nice user cpu ticks
       142713 system cpu ticks
      1312136 idle cpu ticks
          564 IO-wait cpu ticks
            0 IRQ cpu ticks
        18677 softirq cpu ticks
          207 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1145614 K paged in
       509040 K paged out
            0 pages swapped in
            0 pages swapped out
     14441718 interrupts
     48495093 CPU context switches
   1765948394 boot time
        79158 forks
