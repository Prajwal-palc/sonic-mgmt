      3840632 K total memory
      2812640 K used memory
       424628 K active memory
      2584804 K inactive memory
       320984 K free memory
        56304 K buffer memory
       929432 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       281507 non-nice user cpu ticks
         6484 nice user cpu ticks
       106778 system cpu ticks
       947607 idle cpu ticks
          388 IO-wait cpu ticks
            0 IRQ cpu ticks
        12535 softirq cpu ticks
          168 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1109717 K paged in
       412184 K paged out
            0 pages swapped in
            0 pages swapped out
      9035777 interrupts
     37945905 CPU context switches
   1765948401 boot time
        53279 forks
