      3840632 K total memory
      2699148 K used memory
       456436 K active memory
      2560804 K inactive memory
       290128 K free memory
        58928 K buffer memory
      1071460 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       273764 non-nice user cpu ticks
         6552 nice user cpu ticks
        98997 system cpu ticks
       964799 idle cpu ticks
          393 IO-wait cpu ticks
            0 IRQ cpu ticks
        11728 softirq cpu ticks
          151 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1045117 K paged in
       395876 K paged out
            0 pages swapped in
            0 pages swapped out
      8636034 interrupts
     32501651 CPU context switches
   1765948394 boot time
        53363 forks
