      3840620 K total memory
      2666100 K used memory
       434440 K active memory
      2596524 K inactive memory
       300252 K free memory
        57332 K buffer memory
      1095828 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       271718 non-nice user cpu ticks
         4426 nice user cpu ticks
        99811 system cpu ticks
       952900 idle cpu ticks
          348 IO-wait cpu ticks
            0 IRQ cpu ticks
        11623 softirq cpu ticks
          145 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       988692 K paged in
       370276 K paged out
            0 pages swapped in
            0 pages swapped out
      7692512 interrupts
     32159822 CPU context switches
   1765948397 boot time
        46088 forks
