      3840632 K total memory
      2811508 K used memory
       414004 K active memory
      2614064 K inactive memory
       300892 K free memory
        55916 K buffer memory
       951108 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       279958 non-nice user cpu ticks
         4128 nice user cpu ticks
       104692 system cpu ticks
       946820 idle cpu ticks
          382 IO-wait cpu ticks
            0 IRQ cpu ticks
        12478 softirq cpu ticks
          163 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1088292 K paged in
       395140 K paged out
            0 pages swapped in
            0 pages swapped out
      8951274 interrupts
     37546569 CPU context switches
   1765948401 boot time
        47359 forks
