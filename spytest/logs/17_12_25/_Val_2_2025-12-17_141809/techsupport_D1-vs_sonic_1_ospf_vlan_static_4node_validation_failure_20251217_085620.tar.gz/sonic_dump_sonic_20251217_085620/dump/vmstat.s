      3840636 K total memory
      2666044 K used memory
       439636 K active memory
      2590652 K inactive memory
       297064 K free memory
        62584 K buffer memory
      1094444 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       257625 non-nice user cpu ticks
         4251 nice user cpu ticks
        92719 system cpu ticks
       872647 idle cpu ticks
          344 IO-wait cpu ticks
            0 IRQ cpu ticks
        10196 softirq cpu ticks
          147 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1000935 K paged in
       401892 K paged out
            0 pages swapped in
            0 pages swapped out
      7248422 interrupts
     30393477 CPU context switches
   1765949270 boot time
        48000 forks
