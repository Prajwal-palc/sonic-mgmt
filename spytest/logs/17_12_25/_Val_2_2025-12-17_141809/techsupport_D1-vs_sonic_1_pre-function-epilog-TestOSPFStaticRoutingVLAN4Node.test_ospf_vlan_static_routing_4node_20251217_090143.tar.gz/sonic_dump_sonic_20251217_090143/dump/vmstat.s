      3840636 K total memory
      2685156 K used memory
       465132 K active memory
      2560344 K inactive memory
       286992 K free memory
        63828 K buffer memory
      1084040 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       264173 non-nice user cpu ticks
         6710 nice user cpu ticks
        96696 system cpu ticks
       891823 idle cpu ticks
          352 IO-wait cpu ticks
            0 IRQ cpu ticks
        10424 softirq cpu ticks
          151 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1030196 K paged in
       421444 K paged out
            0 pages swapped in
            0 pages swapped out
      7457197 interrupts
     31332973 CPU context switches
   1765949270 boot time
        54359 forks
