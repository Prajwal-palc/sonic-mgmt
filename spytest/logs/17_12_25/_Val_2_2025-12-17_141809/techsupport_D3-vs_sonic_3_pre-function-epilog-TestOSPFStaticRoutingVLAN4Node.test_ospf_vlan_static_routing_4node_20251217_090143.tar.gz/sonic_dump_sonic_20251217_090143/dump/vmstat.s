      3840620 K total memory
      2669844 K used memory
       446732 K active memory
      2556188 K inactive memory
       325160 K free memory
        57336 K buffer memory
      1067296 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       275078 non-nice user cpu ticks
         6869 nice user cpu ticks
       102530 system cpu ticks
       959908 idle cpu ticks
          353 IO-wait cpu ticks
            0 IRQ cpu ticks
        11735 softirq cpu ticks
          147 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1022516 K paged in
       388680 K paged out
            0 pages swapped in
            0 pages swapped out
      7817665 interrupts
     32744475 CPU context switches
   1765948397 boot time
        52249 forks
