      3840632 K total memory
      2678328 K used memory
       435484 K active memory
      2594468 K inactive memory
       299504 K free memory
        58164 K buffer memory
      1083648 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       269125 non-nice user cpu ticks
         4154 nice user cpu ticks
        95730 system cpu ticks
       951658 idle cpu ticks
          386 IO-wait cpu ticks
            0 IRQ cpu ticks
        11546 softirq cpu ticks
          148 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1023773 K paged in
       377100 K paged out
            0 pages swapped in
            0 pages swapped out
      8472905 interrupts
     31750200 CPU context switches
   1765948394 boot time
        47136 forks
