      3840632 K total memory
      2737052 K used memory
       491832 K active memory
      2518944 K inactive memory
       270736 K free memory
        84548 K buffer memory
      1031108 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       439483 non-nice user cpu ticks
        13891 nice user cpu ticks
       160611 system cpu ticks
      1449161 idle cpu ticks
          625 IO-wait cpu ticks
            0 IRQ cpu ticks
        20272 softirq cpu ticks
          233 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1174185 K paged in
       558136 K paged out
            0 pages swapped in
            0 pages swapped out
     15544393 interrupts
     53552427 CPU context switches
   1765948394 boot time
        93298 forks
