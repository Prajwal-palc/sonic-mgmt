      3840632 K total memory
      2926096 K used memory
       418952 K active memory
      2534956 K inactive memory
       319536 K free memory
        80828 K buffer memory
       796660 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       459311 non-nice user cpu ticks
        13675 nice user cpu ticks
       177278 system cpu ticks
      1428717 idle cpu ticks
          700 IO-wait cpu ticks
            0 IRQ cpu ticks
        21442 softirq cpu ticks
          266 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1294019 K paged in
       597872 K paged out
            0 pages swapped in
            0 pages swapped out
     15345503 interrupts
     66089744 CPU context switches
   1765948401 boot time
        93410 forks
