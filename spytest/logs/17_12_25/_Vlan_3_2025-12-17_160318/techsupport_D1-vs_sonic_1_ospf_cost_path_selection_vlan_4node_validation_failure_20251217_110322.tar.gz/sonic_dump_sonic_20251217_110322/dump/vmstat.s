      3840636 K total memory
      2723488 K used memory
       504660 K active memory
      2523852 K inactive memory
       264944 K free memory
        84568 K buffer memory
      1051392 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       417841 non-nice user cpu ticks
        13642 nice user cpu ticks
       157545 system cpu ticks
      1381724 idle cpu ticks
          605 IO-wait cpu ticks
            0 IRQ cpu ticks
        18105 softirq cpu ticks
          250 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1134182 K paged in
       564676 K paged out
            0 pages swapped in
            0 pages swapped out
     13162694 interrupts
     53209707 CPU context switches
   1765949270 boot time
        90130 forks
