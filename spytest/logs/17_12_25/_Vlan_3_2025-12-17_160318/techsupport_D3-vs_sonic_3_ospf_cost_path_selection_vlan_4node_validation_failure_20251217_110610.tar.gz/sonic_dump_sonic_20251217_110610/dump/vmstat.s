      3840620 K total memory
      2724836 K used memory
       493756 K active memory
      2517264 K inactive memory
       265724 K free memory
        80720 K buffer memory
      1051516 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       429671 non-nice user cpu ticks
        14125 nice user cpu ticks
       161807 system cpu ticks
      1467704 idle cpu ticks
          597 IO-wait cpu ticks
            0 IRQ cpu ticks
        19344 softirq cpu ticks
          232 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1113231 K paged in
       529832 K paged out
            0 pages swapped in
            0 pages swapped out
     12685673 interrupts
     51817457 CPU context switches
   1765948398 boot time
        87624 forks
