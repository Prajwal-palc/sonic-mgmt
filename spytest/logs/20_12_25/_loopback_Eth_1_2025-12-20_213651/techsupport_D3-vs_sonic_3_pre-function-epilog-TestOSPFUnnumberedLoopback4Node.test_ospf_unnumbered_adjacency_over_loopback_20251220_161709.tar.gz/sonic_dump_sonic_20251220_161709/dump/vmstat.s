      3840620 K total memory
      2700356 K used memory
       437400 K active memory
      2599700 K inactive memory
       294600 K free memory
        59340 K buffer memory
      1065452 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       173143 non-nice user cpu ticks
         4050 nice user cpu ticks
        64159 system cpu ticks
       559813 idle cpu ticks
          268 IO-wait cpu ticks
            0 IRQ cpu ticks
         5471 softirq cpu ticks
          110 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1015397 K paged in
       386320 K paged out
            0 pages swapped in
            0 pages swapped out
      3959263 interrupts
     18179179 CPU context switches
   1766239289 boot time
        44615 forks
