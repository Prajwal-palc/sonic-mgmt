      3840620 K total memory
      2642720 K used memory
       350352 K active memory
      2561032 K inactive memory
       456712 K free memory
        54160 K buffer memory
       961180 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       167230 non-nice user cpu ticks
         1990 nice user cpu ticks
        60087 system cpu ticks
       547765 idle cpu ticks
          254 IO-wait cpu ticks
            0 IRQ cpu ticks
         5454 softirq cpu ticks
          111 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       995653 K paged in
       363672 K paged out
            0 pages swapped in
            0 pages swapped out
      3868883 interrupts
     17505074 CPU context switches
   1766239281 boot time
        38222 forks
