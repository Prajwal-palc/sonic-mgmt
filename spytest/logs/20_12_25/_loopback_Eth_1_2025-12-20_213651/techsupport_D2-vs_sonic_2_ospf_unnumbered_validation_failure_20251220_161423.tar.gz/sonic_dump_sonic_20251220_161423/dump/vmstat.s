      3840620 K total memory
      2697244 K used memory
       431684 K active memory
      2601904 K inactive memory
       293736 K free memory
        62756 K buffer memory
      1065764 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       177851 non-nice user cpu ticks
         4305 nice user cpu ticks
        65223 system cpu ticks
       538276 idle cpu ticks
          286 IO-wait cpu ticks
            0 IRQ cpu ticks
         5562 softirq cpu ticks
           95 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1022219 K paged in
       400636 K paged out
            0 pages swapped in
            0 pages swapped out
      3973094 interrupts
     18068693 CPU context switches
   1766239286 boot time
        47198 forks
