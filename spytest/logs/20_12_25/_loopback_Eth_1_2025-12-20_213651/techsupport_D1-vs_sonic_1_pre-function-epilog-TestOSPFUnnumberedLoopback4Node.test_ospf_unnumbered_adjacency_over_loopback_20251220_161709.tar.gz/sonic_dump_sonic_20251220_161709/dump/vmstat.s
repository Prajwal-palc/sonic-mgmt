      3840620 K total memory
      2715024 K used memory
       391132 K active memory
      2564188 K inactive memory
       339460 K free memory
        58024 K buffer memory
      1008276 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       172398 non-nice user cpu ticks
         4634 nice user cpu ticks
        63734 system cpu ticks
       561537 idle cpu ticks
          270 IO-wait cpu ticks
            0 IRQ cpu ticks
         5651 softirq cpu ticks
          116 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1033918 K paged in
       387972 K paged out
            0 pages swapped in
            0 pages swapped out
      4047235 interrupts
     18299884 CPU context switches
   1766239281 boot time
        44599 forks
