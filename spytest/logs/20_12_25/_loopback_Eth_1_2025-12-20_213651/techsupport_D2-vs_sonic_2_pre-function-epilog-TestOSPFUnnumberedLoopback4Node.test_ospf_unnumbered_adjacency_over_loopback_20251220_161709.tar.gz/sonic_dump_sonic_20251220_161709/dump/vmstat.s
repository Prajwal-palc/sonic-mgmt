      3840620 K total memory
      2719596 K used memory
       453808 K active memory
      2576768 K inactive memory
       280912 K free memory
        62776 K buffer memory
      1056136 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       181066 non-nice user cpu ticks
         6644 nice user cpu ticks
        67890 system cpu ticks
       546088 idle cpu ticks
          295 IO-wait cpu ticks
            0 IRQ cpu ticks
         5696 softirq cpu ticks
           97 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1042349 K paged in
       421208 K paged out
            0 pages swapped in
            0 pages swapped out
      4096597 interrupts
     18652126 CPU context switches
   1766239286 boot time
        53230 forks
