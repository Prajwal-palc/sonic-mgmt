      3840620 K total memory
      2708092 K used memory
       423060 K active memory
      2632680 K inactive memory
       242548 K free memory
        61608 K buffer memory
      1106648 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       180499 non-nice user cpu ticks
         2215 nice user cpu ticks
        64454 system cpu ticks
       553336 idle cpu ticks
          285 IO-wait cpu ticks
            0 IRQ cpu ticks
         5576 softirq cpu ticks
           92 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       982531 K paged in
       390248 K paged out
            0 pages swapped in
            0 pages swapped out
      3996193 interrupts
     18182502 CPU context switches
   1766239294 boot time
        42801 forks
