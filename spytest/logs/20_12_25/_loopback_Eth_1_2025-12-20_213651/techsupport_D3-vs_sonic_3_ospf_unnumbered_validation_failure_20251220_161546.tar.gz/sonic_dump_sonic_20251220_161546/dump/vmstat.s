      3840620 K total memory
      2710760 K used memory
       418100 K active memory
      2646256 K inactive memory
       249860 K free memory
        58024 K buffer memory
      1099384 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       171175 non-nice user cpu ticks
         1695 nice user cpu ticks
        61861 system cpu ticks
       558104 idle cpu ticks
          266 IO-wait cpu ticks
            0 IRQ cpu ticks
         5411 softirq cpu ticks
          109 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       966162 K paged in
       364552 K paged out
            0 pages swapped in
            0 pages swapped out
      3868364 interrupts
     17741891 CPU context switches
   1766239289 boot time
        38388 forks
