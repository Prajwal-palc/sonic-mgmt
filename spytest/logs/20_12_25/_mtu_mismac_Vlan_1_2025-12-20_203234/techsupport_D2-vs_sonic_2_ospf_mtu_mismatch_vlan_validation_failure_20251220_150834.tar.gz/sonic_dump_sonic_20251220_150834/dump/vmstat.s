      3840620 K total memory
      2670652 K used memory
       419472 K active memory
      2646784 K inactive memory
       289908 K free memory
        50168 K buffer memory
      1106760 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       106216 non-nice user cpu ticks
         1788 nice user cpu ticks
        38439 system cpu ticks
       253278 idle cpu ticks
          173 IO-wait cpu ticks
            0 IRQ cpu ticks
         2720 softirq cpu ticks
           51 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       944550 K paged in
       337732 K paged out
            0 pages swapped in
            0 pages swapped out
      2154340 interrupts
      9825563 CPU context switches
   1766239286 boot time
        34255 forks
