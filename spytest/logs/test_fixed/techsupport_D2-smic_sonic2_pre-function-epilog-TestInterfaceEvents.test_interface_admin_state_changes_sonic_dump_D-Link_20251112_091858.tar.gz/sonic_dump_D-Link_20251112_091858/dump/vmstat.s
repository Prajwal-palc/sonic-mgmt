      3845316 K total memory
      2812540 K used memory
       314184 K active memory
      2489468 K inactive memory
       322812 K free memory
       115832 K buffer memory
       594132 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6706949 non-nice user cpu ticks
        19849 nice user cpu ticks
      2964863 system cpu ticks
     47403820 idle cpu ticks
        15972 IO-wait cpu ticks
            0 IRQ cpu ticks
        72806 softirq cpu ticks
        44302 stolen cpu ticks
      3543976 pages paged in
      9942956 pages paged out
            0 pages swapped in
            0 pages swapped out
    736451116 interrupts
   1735670117 CPU context switches
   1762339277 boot time
       977990 forks
