      3845316 K total memory
      2772512 K used memory
       334916 K active memory
      2376280 K inactive memory
       394756 K free memory
        69268 K buffer memory
       608780 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6713209 non-nice user cpu ticks
        19482 nice user cpu ticks
      3008213 system cpu ticks
     47229789 idle cpu ticks
        14900 IO-wait cpu ticks
            0 IRQ cpu ticks
        73439 softirq cpu ticks
        43580 stolen cpu ticks
      3539640 pages paged in
      9808056 pages paged out
            0 pages swapped in
            0 pages swapped out
    744990572 interrupts
   1755917840 CPU context switches
   1762341322 boot time
       982817 forks
