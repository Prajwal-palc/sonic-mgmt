SAI_INIT_CONFIG_FILE=/usr/share/sonic/hwsku/td3-ds3000-32x100G.config.bcm
SAI_LED_PORT_LOCATOR_FW_FILE=/usr/share/sonic/platform/port_locator.bin
