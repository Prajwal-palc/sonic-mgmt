timeout --foreground 10m show spanning_tree root_guard
Spanning-tree is not configured
