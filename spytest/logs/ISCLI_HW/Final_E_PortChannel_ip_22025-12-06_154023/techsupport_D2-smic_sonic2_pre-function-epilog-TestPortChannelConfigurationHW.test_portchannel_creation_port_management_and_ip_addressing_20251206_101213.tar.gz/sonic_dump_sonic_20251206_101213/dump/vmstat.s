timeout --foreground 10m vmstat -s
     15838904 K total memory
      2894700 K used memory
       615732 K active memory
      3978276 K inactive memory
     10833648 K free memory
       131260 K buffer memory
      1979296 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       617632 non-nice user cpu ticks
        25034 nice user cpu ticks
       274144 system cpu ticks
      6541799 idle cpu ticks
         2803 IO-wait cpu ticks
            0 IRQ cpu ticks
         2172 softirq cpu ticks
            0 stolen cpu ticks
      1581122 pages paged in
       588766 pages paged out
            0 pages swapped in
            0 pages swapped out
    117560959 interrupts
    264720069 CPU context switches
   1764997144 boot time
       397123 forks
