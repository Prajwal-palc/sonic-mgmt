#!/bin/bash

# QoS Initialization script for Supermicro SSE T8196

# Log to syslog
logger "qos-init.sh: Starting QoS configuration load"

# Function to retry a command with backoff
retry_with_backoff() {
    local cmd="$1"
    local description="$2"
    local max_attempts=4
    local attempt=1
    local delay=5

    while [ $attempt -le $max_attempts ]; do
        logger "qos-init.sh: $description (attempt $attempt/$max_attempts)"
        
        if eval "$cmd" &> /dev/null; then
            logger "qos-init.sh: $description - SUCCESS"
            return 0
        fi
        
        if [ $attempt -eq $max_attempts ]; then
            logger "qos-init.sh: $description - FAILED after $max_attempts attempts"
            return 1
        fi
        
        logger "qos-init.sh: $description - FAILED, retrying in ${delay}s"
        sleep $delay
        delay=$((delay * 2))  # Exponential backoff: 5s, 10s, 20s
        attempt=$((attempt + 1))
    done
}

# Check if config command is available with retry
if ! retry_with_backoff "command -v config" "Checking config command availability"; then
    logger "qos-init.sh: config command not available after retries, exiting"
    exit 1
fi

# Check if CONFIG_DB is accessible with retry
if ! retry_with_backoff "redis-cli -n 4 ping" "Checking CONFIG_DB accessibility"; then
    logger "qos-init.sh: CONFIG_DB not accessible after retries, exiting"
    exit 1
fi

# Load QoS configuration with retry
logger "qos-init.sh: Loading QoS configuration"
if retry_with_backoff "/usr/local/bin/config qos reload --no-delay" "Loading QoS configuration"; then
    logger "qos-init.sh: QoS configuration loaded successfully"
else
    logger "qos-init.sh: Failed to load QoS configuration after retries"
    exit 1
fi

exit 0
