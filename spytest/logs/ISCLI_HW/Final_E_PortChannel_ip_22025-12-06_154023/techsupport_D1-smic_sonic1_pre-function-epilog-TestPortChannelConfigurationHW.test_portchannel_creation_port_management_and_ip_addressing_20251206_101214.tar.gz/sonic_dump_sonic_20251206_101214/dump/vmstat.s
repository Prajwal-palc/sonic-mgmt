     31977784 K total memory
      4800296 K used memory
       536932 K active memory
      5441284 K inactive memory
     25214760 K free memory
        87144 K buffer memory
      2745304 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      1503856 non-nice user cpu ticks
         5898 nice user cpu ticks
       575000 system cpu ticks
     27958298 idle cpu ticks
         4287 IO-wait cpu ticks
            0 IRQ cpu ticks
         4168 softirq cpu ticks
            0 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      2126128 K paged in
       419068 K paged out
            0 pages swapped in
            0 pages swapped out
     87675969 interrupts
    239319447 CPU context switches
   1764997121 boot time
       468836 forks
