      3845316 K total memory
      2779604 K used memory
       331948 K active memory
      2382192 K inactive memory
       384924 K free memory
        69288 K buffer memory
       611500 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6720391 non-nice user cpu ticks
        21443 nice user cpu ticks
      3012683 system cpu ticks
     47258847 idle cpu ticks
        14914 IO-wait cpu ticks
            0 IRQ cpu ticks
        73519 softirq cpu ticks
        43633 stolen cpu ticks
      3550022 pages paged in
      9835144 pages paged out
            0 pages swapped in
            0 pages swapped out
    745577653 interrupts
   1757513405 CPU context switches
   1762341321 boot time
       988352 forks
