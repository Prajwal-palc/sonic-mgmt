      3845316 K total memory
      2816500 K used memory
       315164 K active memory
      2479708 K inactive memory
       322736 K free memory
       107740 K buffer memory
       598340 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6713806 non-nice user cpu ticks
        21781 nice user cpu ticks
      2969219 system cpu ticks
     47433681 idle cpu ticks
        15989 IO-wait cpu ticks
            0 IRQ cpu ticks
        72866 softirq cpu ticks
        44333 stolen cpu ticks
      3562923 pages paged in
      9970040 pages paged out
            0 pages swapped in
            0 pages swapped out
    737034411 interrupts
   1737259886 CPU context switches
   1762339277 boot time
       983511 forks
