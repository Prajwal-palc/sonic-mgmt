      3845316 K total memory
      2806112 K used memory
       317892 K active memory
      2527852 K inactive memory
       326000 K free memory
       137120 K buffer memory
       576084 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5821393 non-nice user cpu ticks
         8634 nice user cpu ticks
      2547112 system cpu ticks
     40133958 idle cpu ticks
        13214 IO-wait cpu ticks
            0 IRQ cpu ticks
        75114 softirq cpu ticks
        42501 stolen cpu ticks
      3311384 pages paged in
      8428320 pages paged out
            0 pages swapped in
            0 pages swapped out
    621723630 interrupts
   1464741942 CPU context switches
   1761727776 boot time
       835400 forks
