      3845316 K total memory
      2538968 K used memory
       347428 K active memory
      2613744 K inactive memory
       324348 K free memory
        40980 K buffer memory
       941020 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        37251 non-nice user cpu ticks
         1419 nice user cpu ticks
        17993 system cpu ticks
       153488 idle cpu ticks
          243 IO-wait cpu ticks
            0 IRQ cpu ticks
          255 softirq cpu ticks
          139 stolen cpu ticks
       835656 pages paged in
       121184 pages paged out
            0 pages swapped in
            0 pages swapped out
      2693170 interrupts
      8050183 CPU context switches
   1763011717 boot time
        20778 forks
