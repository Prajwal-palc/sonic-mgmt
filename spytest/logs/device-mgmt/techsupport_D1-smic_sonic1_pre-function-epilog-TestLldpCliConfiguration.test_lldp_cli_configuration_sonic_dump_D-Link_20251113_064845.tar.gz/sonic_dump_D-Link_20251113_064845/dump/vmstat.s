      3845316 K total memory
      2609544 K used memory
       408088 K active memory
      2514320 K inactive memory
       325264 K free memory
        52356 K buffer memory
       858152 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        77415 non-nice user cpu ticks
         9163 nice user cpu ticks
        40203 system cpu ticks
       337910 idle cpu ticks
          313 IO-wait cpu ticks
            0 IRQ cpu ticks
          618 softirq cpu ticks
          305 stolen cpu ticks
       984418 pages paged in
       251808 pages paged out
            0 pages swapped in
            0 pages swapped out
      6167488 interrupts
     17161603 CPU context switches
   1763011716 boot time
        46857 forks
