      3845316 K total memory
      2649412 K used memory
       387516 K active memory
      2523372 K inactive memory
       325684 K free memory
        98596 K buffer memory
       771624 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       263219 non-nice user cpu ticks
         7425 nice user cpu ticks
       120986 system cpu ticks
      1611755 idle cpu ticks
          801 IO-wait cpu ticks
            0 IRQ cpu ticks
         2718 softirq cpu ticks
         1590 stolen cpu ticks
      1076728 pages paged in
       491796 pages paged out
            0 pages swapped in
            0 pages swapped out
     26084231 interrupts
     64011054 CPU context switches
   1762339295 boot time
        66858 forks
