      3845316 K total memory
      2633904 K used memory
       417664 K active memory
      2472852 K inactive memory
       312968 K free memory
        61244 K buffer memory
       837200 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       108853 non-nice user cpu ticks
        16061 nice user cpu ticks
        58264 system cpu ticks
       522032 idle cpu ticks
          775 IO-wait cpu ticks
            0 IRQ cpu ticks
         1001 softirq cpu ticks
          505 stolen cpu ticks
      1021639 pages paged in
       375880 pages paged out
            0 pages swapped in
            0 pages swapped out
      9431265 interrupts
     25836494 CPU context switches
   1763011705 boot time
        69830 forks
