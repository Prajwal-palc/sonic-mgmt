      3845328 K total memory
      2857528 K used memory
       287684 K active memory
      2518280 K inactive memory
       330120 K free memory
        98124 K buffer memory
       559556 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5875618 non-nice user cpu ticks
        16717 nice user cpu ticks
      2545567 system cpu ticks
     40106128 idle cpu ticks
        13589 IO-wait cpu ticks
            0 IRQ cpu ticks
        74077 softirq cpu ticks
        42147 stolen cpu ticks
      3477983 pages paged in
      8499536 pages paged out
            0 pages swapped in
            0 pages swapped out
    624927478 interrupts
   1477468212 CPU context switches
   1761727864 boot time
       854945 forks
