      3845316 K total memory
      2324988 K used memory
       330164 K active memory
      2432588 K inactive memory
       520696 K free memory
        47828 K buffer memory
       951804 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        30520 non-nice user cpu ticks
         1390 nice user cpu ticks
        15353 system cpu ticks
        82107 idle cpu ticks
          100 IO-wait cpu ticks
            0 IRQ cpu ticks
          229 softirq cpu ticks
           84 stolen cpu ticks
       827001 pages paged in
        98900 pages paged out
            0 pages swapped in
            0 pages swapped out
      1664340 interrupts
      5603207 CPU context switches
   1762341341 boot time
        19229 forks
