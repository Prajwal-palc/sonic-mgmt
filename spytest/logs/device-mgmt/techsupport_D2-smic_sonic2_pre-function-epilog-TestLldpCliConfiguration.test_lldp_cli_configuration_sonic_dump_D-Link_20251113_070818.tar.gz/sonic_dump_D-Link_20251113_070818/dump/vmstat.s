      3845316 K total memory
      2611840 K used memory
       397800 K active memory
      2470476 K inactive memory
       361924 K free memory
        55984 K buffer memory
       815568 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        89739 non-nice user cpu ticks
        12358 nice user cpu ticks
        47577 system cpu ticks
       427269 idle cpu ticks
          372 IO-wait cpu ticks
            0 IRQ cpu ticks
          817 softirq cpu ticks
          415 stolen cpu ticks
       992613 pages paged in
       313956 pages paged out
            0 pages swapped in
            0 pages swapped out
      7679698 interrupts
     21275611 CPU context switches
   1763011706 boot time
        57557 forks
