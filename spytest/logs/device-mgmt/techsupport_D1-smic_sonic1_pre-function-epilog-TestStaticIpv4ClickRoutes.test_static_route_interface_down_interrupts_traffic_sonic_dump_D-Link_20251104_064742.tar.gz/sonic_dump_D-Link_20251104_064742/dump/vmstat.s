      3845328 K total memory
      2853516 K used memory
       293976 K active memory
      2527360 K inactive memory
       318020 K free memory
       113948 K buffer memory
       559844 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5864094 non-nice user cpu ticks
         9083 nice user cpu ticks
      2535380 system cpu ticks
     40065201 idle cpu ticks
        13564 IO-wait cpu ticks
            0 IRQ cpu ticks
        73904 softirq cpu ticks
        42104 stolen cpu ticks
      3431454 pages paged in
      8424964 pages paged out
            0 pages swapped in
            0 pages swapped out
    623901785 interrupts
   1474668261 CPU context switches
   1761727863 boot time
       838835 forks
