      3845328 K total memory
      2844364 K used memory
       294112 K active memory
      2510736 K inactive memory
       320584 K free memory
       128636 K buffer memory
       551744 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7021387 non-nice user cpu ticks
         5506 nice user cpu ticks
      1169901 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4050 softirq cpu ticks
         1490 stolen cpu ticks
      1573210 pages paged in
      1305772 pages paged out
            0 pages swapped in
            0 pages swapped out
     47820762 interrupts
    105751714 CPU context switches
   1763451064 boot time
       161262 forks
