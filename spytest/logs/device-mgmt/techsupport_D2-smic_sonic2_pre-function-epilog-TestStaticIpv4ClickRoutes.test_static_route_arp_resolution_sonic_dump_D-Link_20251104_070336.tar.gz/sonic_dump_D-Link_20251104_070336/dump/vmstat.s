      3845316 K total memory
      2815548 K used memory
       318888 K active memory
      2531652 K inactive memory
       315676 K free memory
       126676 K buffer memory
       587416 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5835850 non-nice user cpu ticks
        19096 nice user cpu ticks
      2560008 system cpu ticks
     40187597 idle cpu ticks
        13241 IO-wait cpu ticks
            0 IRQ cpu ticks
        75329 softirq cpu ticks
        42572 stolen cpu ticks
      3368251 pages paged in
      8527724 pages paged out
            0 pages swapped in
            0 pages swapped out
    623019832 interrupts
   1468274065 CPU context switches
   1761727777 boot time
       859303 forks
