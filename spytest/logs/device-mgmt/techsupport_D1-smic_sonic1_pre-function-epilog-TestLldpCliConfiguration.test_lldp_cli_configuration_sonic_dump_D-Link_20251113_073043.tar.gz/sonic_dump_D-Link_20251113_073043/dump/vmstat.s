      3845316 K total memory
      2641700 K used memory
       404572 K active memory
      2484144 K inactive memory
       317028 K free memory
        62684 K buffer memory
       823904 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       116709 non-nice user cpu ticks
        16947 nice user cpu ticks
        62298 system cpu ticks
       509661 idle cpu ticks
          719 IO-wait cpu ticks
            0 IRQ cpu ticks
          942 softirq cpu ticks
          463 stolen cpu ticks
      1041176 pages paged in
       373848 pages paged out
            0 pages swapped in
            0 pages swapped out
      9480234 interrupts
     25894146 CPU context switches
   1763011716 boot time
        72630 forks
