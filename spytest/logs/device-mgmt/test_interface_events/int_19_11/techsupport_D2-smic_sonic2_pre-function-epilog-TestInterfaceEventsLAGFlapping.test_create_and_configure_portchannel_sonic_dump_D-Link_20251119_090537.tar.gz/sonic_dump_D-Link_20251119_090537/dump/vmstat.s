      3845328 K total memory
      3007436 K used memory
       273080 K active memory
      2461188 K inactive memory
       274820 K free memory
        48080 K buffer memory
       514992 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7832439 non-nice user cpu ticks
        37040 nice user cpu ticks
      1337130 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4713 softirq cpu ticks
         1595 stolen cpu ticks
      1987359 pages paged in
      1719592 pages paged out
            0 pages swapped in
            0 pages swapped out
     53909795 interrupts
    121127346 CPU context switches
   1763451063 boot time
       244658 forks
