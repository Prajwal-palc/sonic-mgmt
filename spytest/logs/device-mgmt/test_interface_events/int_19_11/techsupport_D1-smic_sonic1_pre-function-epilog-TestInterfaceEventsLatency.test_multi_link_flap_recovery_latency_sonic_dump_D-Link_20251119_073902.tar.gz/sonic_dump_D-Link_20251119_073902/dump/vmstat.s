      3845316 K total memory
      2927288 K used memory
       317504 K active memory
      2385476 K inactive memory
       318244 K free memory
        33032 K buffer memory
       566752 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7396363 non-nice user cpu ticks
        14726 nice user cpu ticks
      1277290 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4402 softirq cpu ticks
         1365 stolen cpu ticks
      1963142 pages paged in
      1487916 pages paged out
            0 pages swapped in
            0 pages swapped out
     49341679 interrupts
    111204270 CPU context switches
   1763451054 boot time
       202175 forks
