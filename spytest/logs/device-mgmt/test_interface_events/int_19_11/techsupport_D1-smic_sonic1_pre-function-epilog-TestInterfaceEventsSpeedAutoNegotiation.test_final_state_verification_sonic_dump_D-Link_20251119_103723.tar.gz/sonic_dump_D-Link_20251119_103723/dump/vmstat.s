      3845316 K total memory
      2550688 K used memory
       416484 K active memory
      2499904 K inactive memory
       359308 K free memory
        70960 K buffer memory
       864360 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       306343 non-nice user cpu ticks
        10465 nice user cpu ticks
        63821 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
          288 softirq cpu ticks
           43 stolen cpu ticks
      1028377 pages paged in
       223312 pages paged out
            0 pages swapped in
            0 pages swapped out
      2366202 interrupts
      7369650 CPU context switches
   1763544886 boot time
        43226 forks
