      3845316 K total memory
      2533072 K used memory
       366468 K active memory
      2506420 K inactive memory
       408412 K free memory
        65472 K buffer memory
       838360 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       192913 non-nice user cpu ticks
         3183 nice user cpu ticks
        39492 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
          178 softirq cpu ticks
           26 stolen cpu ticks
       961577 pages paged in
       141436 pages paged out
            0 pages swapped in
            0 pages swapped out
      1461005 interrupts
      5020766 CPU context switches
   1763544886 boot time
        25810 forks
