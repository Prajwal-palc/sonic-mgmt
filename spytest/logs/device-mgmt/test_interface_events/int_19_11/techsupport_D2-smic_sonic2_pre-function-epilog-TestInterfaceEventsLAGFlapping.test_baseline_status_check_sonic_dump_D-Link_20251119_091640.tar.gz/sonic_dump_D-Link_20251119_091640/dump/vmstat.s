      3845328 K total memory
      2964776 K used memory
       253868 K active memory
      2392016 K inactive memory
       359780 K free memory
        33116 K buffer memory
       487656 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7883088 non-nice user cpu ticks
        40639 nice user cpu ticks
      1348639 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4763 softirq cpu ticks
         1602 stolen cpu ticks
      2042320 pages paged in
      1756812 pages paged out
            0 pages swapped in
            0 pages swapped out
     54316025 interrupts
    122174352 CPU context switches
   1763451063 boot time
       252882 forks
