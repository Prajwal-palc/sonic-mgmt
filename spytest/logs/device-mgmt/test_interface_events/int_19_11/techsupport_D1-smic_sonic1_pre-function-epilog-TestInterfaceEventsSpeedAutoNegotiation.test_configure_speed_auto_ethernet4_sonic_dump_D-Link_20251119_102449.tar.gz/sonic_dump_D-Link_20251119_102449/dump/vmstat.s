      3845316 K total memory
      2544956 K used memory
       400904 K active memory
      2509796 K inactive memory
       362392 K free memory
        68372 K buffer memory
       869596 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       247726 non-nice user cpu ticks
         6833 nice user cpu ticks
        51417 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
          229 softirq cpu ticks
           32 stolen cpu ticks
      1000083 pages paged in
       182264 pages paged out
            0 pages swapped in
            0 pages swapped out
      1901289 interrupts
      6170813 CPU context switches
   1763544886 boot time
        34485 forks
