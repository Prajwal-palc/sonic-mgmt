      3845328 K total memory
      2922040 K used memory
       284484 K active memory
      2446424 K inactive memory
       317740 K free memory
        62908 K buffer memory
       542640 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7476592 non-nice user cpu ticks
        16690 nice user cpu ticks
      1260151 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4411 softirq cpu ticks
         1551 stolen cpu ticks
      1848370 pages paged in
      1493460 pages paged out
            0 pages swapped in
            0 pages swapped out
     51162849 interrupts
    114190686 CPU context switches
   1763451063 boot time
       197052 forks
