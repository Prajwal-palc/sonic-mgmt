      3845316 K total memory
      2959568 K used memory
       310532 K active memory
      2372784 K inactive memory
       310180 K free memory
        23060 K buffer memory
       552508 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7527051 non-nice user cpu ticks
        21997 nice user cpu ticks
      1306122 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4522 softirq cpu ticks
         1372 stolen cpu ticks
      2105658 pages paged in
      1582804 pages paged out
            0 pages swapped in
            0 pages swapped out
     50376060 interrupts
    114100800 CPU context switches
   1763451054 boot time
       221539 forks
