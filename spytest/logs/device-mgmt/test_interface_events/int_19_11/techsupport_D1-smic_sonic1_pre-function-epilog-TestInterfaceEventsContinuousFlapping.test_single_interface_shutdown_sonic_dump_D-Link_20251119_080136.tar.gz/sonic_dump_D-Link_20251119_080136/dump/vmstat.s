      3845316 K total memory
      2950548 K used memory
       302576 K active memory
      2375796 K inactive memory
       320352 K free memory
        22116 K buffer memory
       552300 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7502880 non-nice user cpu ticks
        20189 nice user cpu ticks
      1300497 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4496 softirq cpu ticks
         1371 stolen cpu ticks
      2090795 pages paged in
      1562848 pages paged out
            0 pages swapped in
            0 pages swapped out
     50176289 interrupts
    113539587 CPU context switches
   1763451054 boot time
       217172 forks
