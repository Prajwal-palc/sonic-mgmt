      3845316 K total memory
      2759048 K used memory
       387688 K active memory
      2370292 K inactive memory
       310044 K free memory
        47052 K buffer memory
       729172 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       650424 non-nice user cpu ticks
        17824 nice user cpu ticks
       132747 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
          652 softirq cpu ticks
          101 stolen cpu ticks
      1188275 pages paged in
       449028 pages paged out
            0 pages swapped in
            0 pages swapped out
      4901861 interrupts
     16787378 CPU context switches
   1763544886 boot time
        87186 forks
