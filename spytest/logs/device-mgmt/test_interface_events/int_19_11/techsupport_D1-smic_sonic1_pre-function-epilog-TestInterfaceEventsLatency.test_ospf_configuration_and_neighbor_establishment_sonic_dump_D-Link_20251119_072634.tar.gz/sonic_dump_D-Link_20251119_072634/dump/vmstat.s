      3845316 K total memory
      2921416 K used memory
       287400 K active memory
      2405024 K inactive memory
       333604 K free memory
        40600 K buffer memory
       549696 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7341136 non-nice user cpu ticks
         9253 nice user cpu ticks
      1263366 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4336 softirq cpu ticks
         1357 stolen cpu ticks
      1840727 pages paged in
      1432360 pages paged out
            0 pages swapped in
            0 pages swapped out
     48854474 interrupts
    109806220 CPU context switches
   1763451054 boot time
       189442 forks
