      3845328 K total memory
      2933600 K used memory
       259752 K active memory
      2401248 K inactive memory
       372912 K free memory
        37928 K buffer memory
       500888 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7602068 non-nice user cpu ticks
        25898 nice user cpu ticks
      1288531 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4526 softirq cpu ticks
         1563 stolen cpu ticks
      1930172 pages paged in
      1586160 pages paged out
            0 pages swapped in
            0 pages swapped out
     52163306 interrupts
    116756268 CPU context switches
   1763451063 boot time
       217629 forks
