      3845328 K total memory
      2966916 K used memory
       223352 K active memory
      2407752 K inactive memory
       380184 K free memory
        31892 K buffer memory
       466336 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7856287 non-nice user cpu ticks
        38856 nice user cpu ticks
      1342601 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4735 softirq cpu ticks
         1598 stolen cpu ticks
      2018634 pages paged in
      1738348 pages paged out
            0 pages swapped in
            0 pages swapped out
     54104912 interrupts
    121635640 CPU context switches
   1763451063 boot time
       248773 forks
