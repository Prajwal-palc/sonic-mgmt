      3845316 K total memory
      2974788 K used memory
       273920 K active memory
      2379312 K inactive memory
       325472 K free memory
        17548 K buffer memory
       527508 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7600106 non-nice user cpu ticks
        27403 nice user cpu ticks
      1322793 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4590 softirq cpu ticks
         1379 stolen cpu ticks
      2153020 pages paged in
      1646420 pages paged out
            0 pages swapped in
            0 pages swapped out
     50968965 interrupts
    115775438 CPU context switches
   1763451054 boot time
       234766 forks
