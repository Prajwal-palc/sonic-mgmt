      3845316 K total memory
      3013824 K used memory
       203084 K active memory
      2344804 K inactive memory
       390612 K free memory
         7616 K buffer memory
       433264 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7856013 non-nice user cpu ticks
        40120 nice user cpu ticks
      1377721 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4810 softirq cpu ticks
         1404 stolen cpu ticks
      2434628 pages paged in
      1808776 pages paged out
            0 pages swapped in
            0 pages swapped out
     52959854 interrupts
    120984737 CPU context switches
   1763451053 boot time
       267439 forks
