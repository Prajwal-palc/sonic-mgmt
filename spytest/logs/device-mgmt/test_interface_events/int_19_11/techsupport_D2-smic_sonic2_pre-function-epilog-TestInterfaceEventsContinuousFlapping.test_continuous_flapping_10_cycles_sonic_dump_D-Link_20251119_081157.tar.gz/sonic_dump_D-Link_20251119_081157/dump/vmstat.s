      3845328 K total memory
      2929200 K used memory
       257376 K active memory
      2393712 K inactive memory
       384260 K free memory
        36916 K buffer memory
       494952 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7577544 non-nice user cpu ticks
        24086 nice user cpu ticks
      1282908 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4501 softirq cpu ticks
         1559 stolen cpu ticks
      1923518 pages paged in
      1568448 pages paged out
            0 pages swapped in
            0 pages swapped out
     51966610 interrupts
    116256661 CPU context switches
   1763451063 boot time
       213582 forks
