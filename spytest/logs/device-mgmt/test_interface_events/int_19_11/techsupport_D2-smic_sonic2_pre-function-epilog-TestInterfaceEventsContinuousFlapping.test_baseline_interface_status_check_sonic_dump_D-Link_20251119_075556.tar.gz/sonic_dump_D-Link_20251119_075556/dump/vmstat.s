      3845328 K total memory
      2923028 K used memory
       277412 K active memory
      2450984 K inactive memory
       319180 K free memory
        59356 K buffer memory
       543764 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7503832 non-nice user cpu ticks
        18527 nice user cpu ticks
      1266175 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4436 softirq cpu ticks
         1553 stolen cpu ticks
      1857663 pages paged in
      1511896 pages paged out
            0 pages swapped in
            0 pages swapped out
     51376103 interrupts
    114729343 CPU context switches
   1763451063 boot time
       201236 forks
