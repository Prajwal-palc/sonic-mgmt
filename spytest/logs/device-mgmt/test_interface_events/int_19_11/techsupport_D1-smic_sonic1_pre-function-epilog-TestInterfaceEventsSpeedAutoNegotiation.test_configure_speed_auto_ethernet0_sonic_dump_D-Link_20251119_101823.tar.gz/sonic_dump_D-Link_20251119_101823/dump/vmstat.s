      3845316 K total memory
      2544012 K used memory
       396900 K active memory
      2507956 K inactive memory
       369020 K free memory
        66948 K buffer memory
       865336 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       217246 non-nice user cpu ticks
         5032 nice user cpu ticks
        44964 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
          202 softirq cpu ticks
           30 stolen cpu ticks
       993031 pages paged in
       160960 pages paged out
            0 pages swapped in
            0 pages swapped out
      1661453 interrupts
      5547531 CPU context switches
   1763544886 boot time
        29957 forks
