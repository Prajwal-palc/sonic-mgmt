      3845316 K total memory
      2946032 K used memory
       295704 K active memory
      2391768 K inactive memory
       313544 K free memory
        27184 K buffer memory
       558556 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7450258 non-nice user cpu ticks
        16555 nice user cpu ticks
      1288645 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4445 softirq cpu ticks
         1367 stolen cpu ticks
      2003886 pages paged in
      1520100 pages paged out
            0 pages swapped in
            0 pages swapped out
     49749027 interrupts
    112393556 CPU context switches
   1763451054 boot time
       208349 forks
