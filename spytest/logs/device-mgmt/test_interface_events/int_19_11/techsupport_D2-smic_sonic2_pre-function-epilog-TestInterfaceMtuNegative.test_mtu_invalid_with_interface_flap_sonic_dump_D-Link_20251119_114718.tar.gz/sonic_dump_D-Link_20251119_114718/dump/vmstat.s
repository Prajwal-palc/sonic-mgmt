      3845316 K total memory
      2568168 K used memory
       371440 K active memory
      2531100 K inactive memory
       350100 K free memory
        69292 K buffer memory
       857756 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       655561 non-nice user cpu ticks
        17537 nice user cpu ticks
       127635 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
          529 softirq cpu ticks
          183 stolen cpu ticks
      1016644 pages paged in
       351584 pages paged out
            0 pages swapped in
            0 pages swapped out
      4843145 interrupts
     13285139 CPU context switches
   1763544878 boot time
        67040 forks
