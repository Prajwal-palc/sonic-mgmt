      3845316 K total memory
      2519788 K used memory
       346976 K active memory
      2611948 K inactive memory
       319224 K free memory
        56332 K buffer memory
       949972 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       194065 non-nice user cpu ticks
         3105 nice user cpu ticks
        38966 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
          157 softirq cpu ticks
           36 stolen cpu ticks
       849477 pages paged in
       139304 pages paged out
            0 pages swapped in
            0 pages swapped out
      1457760 interrupts
      4901782 CPU context switches
   1763544879 boot time
        25335 forks
