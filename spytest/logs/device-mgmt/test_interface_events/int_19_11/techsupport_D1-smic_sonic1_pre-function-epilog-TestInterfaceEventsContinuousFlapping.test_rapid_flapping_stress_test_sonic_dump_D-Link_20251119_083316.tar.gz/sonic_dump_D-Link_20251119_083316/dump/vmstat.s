      3845316 K total memory
      2981504 K used memory
       268416 K active memory
      2376536 K inactive memory
       325400 K free memory
        18340 K buffer memory
       520072 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7648803 non-nice user cpu ticks
        31048 nice user cpu ticks
      1333958 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4630 softirq cpu ticks
         1380 stolen cpu ticks
      2188591 pages paged in
      1687424 pages paged out
            0 pages swapped in
            0 pages swapped out
     51364604 interrupts
    116877681 CPU context switches
   1763451054 boot time
       243488 forks
