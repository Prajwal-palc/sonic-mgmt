      3845328 K total memory
      2948560 K used memory
       291364 K active memory
      2501300 K inactive memory
       274176 K free memory
        69952 K buffer memory
       552640 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7367185 non-nice user cpu ticks
         9253 nice user cpu ticks
      1235443 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4303 softirq cpu ticks
         1539 stolen cpu ticks
      1794199 pages paged in
      1407100 pages paged out
            0 pages swapped in
            0 pages swapped out
     50290267 interrupts
    111848637 CPU context switches
   1763451063 boot time
       179406 forks
