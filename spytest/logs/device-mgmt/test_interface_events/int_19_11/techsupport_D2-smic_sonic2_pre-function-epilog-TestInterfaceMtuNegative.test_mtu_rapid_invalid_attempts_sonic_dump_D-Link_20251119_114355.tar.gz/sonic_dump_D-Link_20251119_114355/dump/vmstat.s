      3845316 K total memory
      2566692 K used memory
       370456 K active memory
      2527244 K inactive memory
       355288 K free memory
        68548 K buffer memory
       854788 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       640793 non-nice user cpu ticks
        15689 nice user cpu ticks
       124027 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
          513 softirq cpu ticks
          182 stolen cpu ticks
      1012413 pages paged in
       333804 pages paged out
            0 pages swapped in
            0 pages swapped out
      4710178 interrupts
     12911832 CPU context switches
   1763544878 boot time
        63027 forks
