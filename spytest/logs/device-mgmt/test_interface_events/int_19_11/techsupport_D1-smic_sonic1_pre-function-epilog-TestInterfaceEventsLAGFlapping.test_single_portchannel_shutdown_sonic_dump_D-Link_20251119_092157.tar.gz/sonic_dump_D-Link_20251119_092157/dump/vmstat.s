      3845316 K total memory
      3018528 K used memory
       261572 K active memory
      2351848 K inactive memory
       315372 K free memory
         9236 K buffer memory
       502180 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7880143 non-nice user cpu ticks
        41907 nice user cpu ticks
      1383316 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4831 softirq cpu ticks
         1406 stolen cpu ticks
      2506369 pages paged in
      1827876 pages paged out
            0 pages swapped in
            0 pages swapped out
     53162785 interrupts
    121509229 CPU context switches
   1763451053 boot time
       271583 forks
