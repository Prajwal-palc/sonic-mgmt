      3845316 K total memory
      2924236 K used memory
       288416 K active memory
      2404324 K inactive memory
       331248 K free memory
        41376 K buffer memory
       548456 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7316310 non-nice user cpu ticks
         7379 nice user cpu ticks
      1257602 system cpu ticks
          562 idle cpu ticks
           20 IO-wait cpu ticks
            0 IRQ cpu ticks
         4311 softirq cpu ticks
         1355 stolen cpu ticks
      1815191 pages paged in
      1410460 pages paged out
            0 pages swapped in
            0 pages swapped out
     48648558 interrupts
    109266576 CPU context switches
   1763451054 boot time
       185082 forks
