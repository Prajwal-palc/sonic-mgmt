      3845316 K total memory
      2532828 K used memory
       369040 K active memory
      2595424 K inactive memory
       314212 K free memory
        60460 K buffer memory
       937816 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       308648 non-nice user cpu ticks
        10390 nice user cpu ticks
        62975 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
          264 softirq cpu ticks
           67 stolen cpu ticks
       920381 pages paged in
       219756 pages paged out
            0 pages swapped in
            0 pages swapped out
      2364392 interrupts
      7179842 CPU context switches
   1763544879 boot time
        42097 forks
