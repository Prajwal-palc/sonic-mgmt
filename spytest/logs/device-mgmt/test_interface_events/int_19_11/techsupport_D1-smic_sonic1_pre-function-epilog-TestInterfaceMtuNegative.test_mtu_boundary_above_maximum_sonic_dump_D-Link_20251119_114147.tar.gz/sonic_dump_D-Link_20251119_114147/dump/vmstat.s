      3845316 K total memory
      2719356 K used memory
       413124 K active memory
      2363580 K inactive memory
       321168 K free memory
        53708 K buffer memory
       751084 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       627181 non-nice user cpu ticks
        14097 nice user cpu ticks
       125501 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
          597 softirq cpu ticks
           95 stolen cpu ticks
      1159328 pages paged in
       390856 pages paged out
            0 pages swapped in
            0 pages swapped out
      4657145 interrupts
     15525859 CPU context switches
   1763544886 boot time
        75810 forks
