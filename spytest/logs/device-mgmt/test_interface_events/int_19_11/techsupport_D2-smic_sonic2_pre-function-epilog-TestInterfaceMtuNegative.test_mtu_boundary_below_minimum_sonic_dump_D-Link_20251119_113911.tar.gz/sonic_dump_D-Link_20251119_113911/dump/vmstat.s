      3845316 K total memory
      2590340 K used memory
       349876 K active memory
      2557580 K inactive memory
       352544 K free memory
        67424 K buffer memory
       835008 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       621629 non-nice user cpu ticks
        12172 nice user cpu ticks
       118375 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
          486 softirq cpu ticks
          177 stolen cpu ticks
       989369 pages paged in
       298832 pages paged out
            0 pages swapped in
            0 pages swapped out
      4515117 interrupts
     12342003 CPU context switches
   1763544878 boot time
        55257 forks
