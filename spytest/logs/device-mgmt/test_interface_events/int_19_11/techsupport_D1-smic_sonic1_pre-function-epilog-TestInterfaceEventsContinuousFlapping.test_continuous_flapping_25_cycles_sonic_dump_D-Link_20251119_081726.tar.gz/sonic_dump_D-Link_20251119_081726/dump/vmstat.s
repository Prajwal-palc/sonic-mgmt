      3845316 K total memory
      3017472 K used memory
       288160 K active memory
      2427292 K inactive memory
       267372 K free memory
        22404 K buffer memory
       538068 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7575750 non-nice user cpu ticks
        25602 nice user cpu ticks
      1317198 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4571 softirq cpu ticks
         1376 stolen cpu ticks
      2132910 pages paged in
      1625404 pages paged out
            0 pages swapped in
            0 pages swapped out
     50770292 interrupts
    115208768 CPU context switches
   1763451054 boot time
       230293 forks
