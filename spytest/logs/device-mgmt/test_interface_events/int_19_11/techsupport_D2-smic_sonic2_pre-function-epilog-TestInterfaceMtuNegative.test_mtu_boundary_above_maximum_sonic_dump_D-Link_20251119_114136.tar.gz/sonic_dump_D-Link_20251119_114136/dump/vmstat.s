      3845316 K total memory
      2565892 K used memory
       368276 K active memory
      2526260 K inactive memory
       360012 K free memory
        68000 K buffer memory
       851412 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       631419 non-nice user cpu ticks
        13908 nice user cpu ticks
       121261 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
          501 softirq cpu ticks
          180 stolen cpu ticks
      1008666 pages paged in
       317332 pages paged out
            0 pages swapped in
            0 pages swapped out
      4614174 interrupts
     12632819 CPU context switches
   1763544878 boot time
        59233 forks
