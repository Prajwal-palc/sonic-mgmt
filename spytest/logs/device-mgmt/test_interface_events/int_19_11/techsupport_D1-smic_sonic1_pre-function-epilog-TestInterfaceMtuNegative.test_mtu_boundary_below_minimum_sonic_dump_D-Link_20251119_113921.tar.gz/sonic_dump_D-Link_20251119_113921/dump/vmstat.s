      3845316 K total memory
      2707484 K used memory
       368412 K active memory
      2382304 K inactive memory
       363892 K free memory
        53136 K buffer memory
       720804 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       617910 non-nice user cpu ticks
        12283 nice user cpu ticks
       122508 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
          577 softirq cpu ticks
           92 stolen cpu ticks
      1117143 pages paged in
       366708 pages paged out
            0 pages swapped in
            0 pages swapped out
      4556551 interrupts
     15019669 CPU context switches
   1763544886 boot time
        70645 forks
