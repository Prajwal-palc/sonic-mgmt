      3845316 K total memory
      2476376 K used memory
       336384 K active memory
      2568176 K inactive memory
       374668 K free memory
        54084 K buffer memory
       940188 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       166293 non-nice user cpu ticks
         1311 nice user cpu ticks
        33093 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
          137 softirq cpu ticks
           32 stolen cpu ticks
       823867 pages paged in
       116348 pages paged out
            0 pages swapped in
            0 pages swapped out
      1237074 interrupts
      4345033 CPU context switches
   1763544879 boot time
        21088 forks
