      3845328 K total memory
      2942308 K used memory
       266656 K active memory
      2419812 K inactive memory
       340156 K free memory
        41712 K buffer memory
       521152 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7682024 non-nice user cpu ticks
        33356 nice user cpu ticks
      1307588 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4606 softirq cpu ticks
         1580 stolen cpu ticks
      1954611 pages paged in
      1661820 pages paged out
            0 pages swapped in
            0 pages swapped out
     52835908 interrupts
    118531978 CPU context switches
   1763451063 boot time
       233747 forks
