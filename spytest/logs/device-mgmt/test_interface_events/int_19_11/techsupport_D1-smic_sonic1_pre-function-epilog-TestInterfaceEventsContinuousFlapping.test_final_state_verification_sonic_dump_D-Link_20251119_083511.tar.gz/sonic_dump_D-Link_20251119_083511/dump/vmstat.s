      3845316 K total memory
      2981384 K used memory
       264748 K active memory
      2377580 K inactive memory
       326680 K free memory
        18520 K buffer memory
       518732 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7655808 non-nice user cpu ticks
        32848 nice user cpu ticks
      1336300 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4643 softirq cpu ticks
         1381 stolen cpu ticks
      2196633 pages paged in
      1706976 pages paged out
            0 pages swapped in
            0 pages swapped out
     51444462 interrupts
    117136242 CPU context switches
   1763451054 boot time
       247297 forks
