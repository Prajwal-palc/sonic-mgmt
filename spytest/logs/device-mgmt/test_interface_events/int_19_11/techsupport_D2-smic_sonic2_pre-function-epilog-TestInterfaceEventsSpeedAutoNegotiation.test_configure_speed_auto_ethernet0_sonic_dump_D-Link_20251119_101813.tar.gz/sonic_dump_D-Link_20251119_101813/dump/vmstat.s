      3845316 K total memory
      2523152 K used memory
       357124 K active memory
      2605564 K inactive memory
       314180 K free memory
        56960 K buffer memory
       951024 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       217461 non-nice user cpu ticks
         4876 nice user cpu ticks
        44098 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
          180 softirq cpu ticks
           37 stolen cpu ticks
       866228 pages paged in
       157908 pages paged out
            0 pages swapped in
            0 pages swapped out
      1647982 interrupts
      5392880 CPU context switches
   1763544879 boot time
        29404 forks
