      3845328 K total memory
      2908736 K used memory
       290236 K active memory
      2454436 K inactive memory
       321408 K free memory
        66928 K buffer memory
       548256 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7373887 non-nice user cpu ticks
        11100 nice user cpu ticks
      1237856 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4319 softirq cpu ticks
         1540 stolen cpu ticks
      1810226 pages paged in
      1421852 pages paged out
            0 pages swapped in
            0 pages swapped out
     50369999 interrupts
    112108638 CPU context switches
   1763451063 boot time
       183256 forks
