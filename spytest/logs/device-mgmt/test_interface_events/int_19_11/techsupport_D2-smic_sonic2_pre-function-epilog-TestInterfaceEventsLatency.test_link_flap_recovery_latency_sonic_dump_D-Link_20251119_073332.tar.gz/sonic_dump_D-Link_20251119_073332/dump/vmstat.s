      3845328 K total memory
      2909976 K used memory
       290716 K active memory
      2456712 K inactive memory
       316932 K free memory
        65944 K buffer memory
       552476 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7398141 non-nice user cpu ticks
        12973 nice user cpu ticks
      1243451 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4342 softirq cpu ticks
         1542 stolen cpu ticks
      1822468 pages paged in
      1444884 pages paged out
            0 pages swapped in
            0 pages swapped out
     50566930 interrupts
    112613350 CPU context switches
   1763451063 boot time
       187384 forks
