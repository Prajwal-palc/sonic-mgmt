      3845316 K total memory
      2964252 K used memory
       296608 K active memory
      2376136 K inactive memory
       316500 K free memory
        23316 K buffer memory
       541248 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7551156 non-nice user cpu ticks
        23784 nice user cpu ticks
      1311628 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4544 softirq cpu ticks
         1375 stolen cpu ticks
      2121885 pages paged in
      1604296 pages paged out
            0 pages swapped in
            0 pages swapped out
     50570683 interrupts
    114647770 CPU context switches
   1763451054 boot time
       225905 forks
