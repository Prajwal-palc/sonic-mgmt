      3845316 K total memory
      2534184 K used memory
       365396 K active memory
      2593696 K inactive memory
       326272 K free memory
        59096 K buffer memory
       925764 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       279604 non-nice user cpu ticks
         8496 nice user cpu ticks
        57049 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
          231 softirq cpu ticks
           53 stolen cpu ticks
       906875 pages paged in
       199004 pages paged out
            0 pages swapped in
            0 pages swapped out
      2132279 interrupts
      6605570 CPU context switches
   1763544879 boot time
        37931 forks
