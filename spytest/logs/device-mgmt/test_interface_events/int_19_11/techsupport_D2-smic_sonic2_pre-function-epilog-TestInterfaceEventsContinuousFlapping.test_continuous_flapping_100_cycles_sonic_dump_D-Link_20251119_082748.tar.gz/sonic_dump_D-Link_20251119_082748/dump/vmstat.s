      3845328 K total memory
      2941940 K used memory
       263756 K active memory
      2413056 K inactive memory
       352164 K free memory
        40096 K buffer memory
       511128 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7650878 non-nice user cpu ticks
        29661 nice user cpu ticks
      1299595 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4571 softirq cpu ticks
         1570 stolen cpu ticks
      1942462 pages paged in
      1625176 pages paged out
            0 pages swapped in
            0 pages swapped out
     52557719 interrupts
    117770438 CPU context switches
   1763451063 boot time
       225913 forks
