      3845328 K total memory
      2940400 K used memory
       269356 K active memory
      2406984 K inactive memory
       353940 K free memory
        41244 K buffer memory
       509744 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7675177 non-nice user cpu ticks
        31532 nice user cpu ticks
      1305179 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4594 softirq cpu ticks
         1576 stolen cpu ticks
      1946943 pages paged in
      1643996 pages paged out
            0 pages swapped in
            0 pages swapped out
     52756342 interrupts
    118282084 CPU context switches
   1763451063 boot time
       229981 forks
