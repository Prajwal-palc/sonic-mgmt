      3845328 K total memory
      2903264 K used memory
       280064 K active memory
      2467936 K inactive memory
       319932 K free memory
        71832 K buffer memory
       550300 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7342106 non-nice user cpu ticks
         7382 nice user cpu ticks
      1229752 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4280 softirq cpu ticks
         1537 stolen cpu ticks
      1766814 pages paged in
      1386628 pages paged out
            0 pages swapped in
            0 pages swapped out
     50089260 interrupts
    111330251 CPU context switches
   1763451063 boot time
       175185 forks
