      3845316 K total memory
      2919948 K used memory
       300824 K active memory
      2393468 K inactive memory
       331088 K free memory
        32320 K buffer memory
       561960 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7372191 non-nice user cpu ticks
        12935 nice user cpu ticks
      1271603 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4375 softirq cpu ticks
         1363 stolen cpu ticks
      1937373 pages paged in
      1469928 pages paged out
            0 pages swapped in
            0 pages swapped out
     49140485 interrupts
    110642687 CPU context switches
   1763451054 boot time
       197776 forks
