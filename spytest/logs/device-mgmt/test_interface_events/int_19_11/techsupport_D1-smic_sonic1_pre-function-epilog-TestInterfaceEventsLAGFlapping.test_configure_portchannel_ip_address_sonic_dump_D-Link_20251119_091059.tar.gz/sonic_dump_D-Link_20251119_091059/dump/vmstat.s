      3845316 K total memory
      3013388 K used memory
       271464 K active memory
      2343016 K inactive memory
       324144 K free memory
        20116 K buffer memory
       487668 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7829789 non-nice user cpu ticks
        38294 nice user cpu ticks
      1371637 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4782 softirq cpu ticks
         1403 stolen cpu ticks
      2304161 pages paged in
      1789016 pages paged out
            0 pages swapped in
            0 pages swapped out
     52736819 interrupts
    120408465 CPU context switches
   1763451053 boot time
       263151 forks
