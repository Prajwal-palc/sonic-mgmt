      3845328 K total memory
      2906808 K used memory
       288316 K active memory
      2457236 K inactive memory
       316020 K free memory
        65696 K buffer memory
       556804 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7422579 non-nice user cpu ticks
        14824 nice user cpu ticks
      1249063 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4367 softirq cpu ticks
         1545 stolen cpu ticks
      1831592 pages paged in
      1464264 pages paged out
            0 pages swapped in
            0 pages swapped out
     50765091 interrupts
    113124415 CPU context switches
   1763451063 boot time
       191472 forks
