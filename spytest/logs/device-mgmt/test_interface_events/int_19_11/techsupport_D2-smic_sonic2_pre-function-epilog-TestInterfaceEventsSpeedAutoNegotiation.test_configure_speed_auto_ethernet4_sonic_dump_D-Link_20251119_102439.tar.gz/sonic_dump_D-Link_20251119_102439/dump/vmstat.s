      3845316 K total memory
      2533568 K used memory
       360520 K active memory
      2601620 K inactive memory
       322964 K free memory
        58044 K buffer memory
       930740 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       248418 non-nice user cpu ticks
         6632 nice user cpu ticks
        50578 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
          205 softirq cpu ticks
           40 stolen cpu ticks
       886974 pages paged in
       177232 pages paged out
            0 pages swapped in
            0 pages swapped out
      1889109 interrupts
      6002478 CPU context switches
   1763544879 boot time
        33701 forks
