      3845316 K total memory
      2551036 K used memory
       419400 K active memory
      2496132 K inactive memory
       360720 K free memory
        69668 K buffer memory
       863892 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       277699 non-nice user cpu ticks
         8668 nice user cpu ticks
        57793 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
          256 softirq cpu ticks
           39 stolen cpu ticks
      1009894 pages paged in
       203596 pages paged out
            0 pages swapped in
            0 pages swapped out
      2139422 interrupts
      6778880 CPU context switches
   1763544886 boot time
        38882 forks
