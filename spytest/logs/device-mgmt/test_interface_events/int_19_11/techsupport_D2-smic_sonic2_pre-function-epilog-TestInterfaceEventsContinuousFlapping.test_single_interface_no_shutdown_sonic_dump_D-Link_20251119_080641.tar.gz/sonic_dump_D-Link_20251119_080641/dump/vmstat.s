      3845328 K total memory
      2932404 K used memory
       228652 K active memory
      2413412 K inactive memory
       402600 K free memory
        35992 K buffer memory
       474332 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7553410 non-nice user cpu ticks
        22247 nice user cpu ticks
      1277567 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4482 softirq cpu ticks
         1557 stolen cpu ticks
      1908580 pages paged in
      1548736 pages paged out
            0 pages swapped in
            0 pages swapped out
     51775183 interrupts
    115756256 CPU context switches
   1763451063 boot time
       209504 forks
