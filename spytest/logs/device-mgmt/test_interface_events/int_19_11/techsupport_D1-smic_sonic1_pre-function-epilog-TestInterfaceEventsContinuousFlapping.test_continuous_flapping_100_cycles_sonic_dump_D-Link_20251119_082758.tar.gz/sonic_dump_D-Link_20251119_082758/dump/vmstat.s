      3845316 K total memory
      2976492 K used memory
       271644 K active memory
      2374840 K inactive memory
       323928 K free memory
        17276 K buffer memory
       527620 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7624325 non-nice user cpu ticks
        29217 nice user cpu ticks
      1328324 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4612 softirq cpu ticks
         1379 stolen cpu ticks
      2171947 pages paged in
      1667300 pages paged out
            0 pages swapped in
            0 pages swapped out
     51165127 interrupts
    116325644 CPU context switches
   1763451054 boot time
       239135 forks
