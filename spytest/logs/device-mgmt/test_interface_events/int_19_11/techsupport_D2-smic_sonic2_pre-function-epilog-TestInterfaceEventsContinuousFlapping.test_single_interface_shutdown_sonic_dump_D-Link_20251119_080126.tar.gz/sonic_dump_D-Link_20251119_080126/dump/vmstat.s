      3845328 K total memory
      2929936 K used memory
       273712 K active memory
      2440952 K inactive memory
       329556 K free memory
        50076 K buffer memory
       535760 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7529410 non-nice user cpu ticks
        20410 nice user cpu ticks
      1271950 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4460 softirq cpu ticks
         1556 stolen cpu ticks
      1872269 pages paged in
      1529292 pages paged out
            0 pages swapped in
            0 pages swapped out
     51580364 interrupts
    115253895 CPU context switches
   1763451063 boot time
       205404 forks
