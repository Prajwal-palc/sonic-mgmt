      3845328 K total memory
      2958412 K used memory
       277104 K active memory
      2410300 K inactive memory
       320648 K free memory
        47052 K buffer memory
       519216 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7807842 non-nice user cpu ticks
        35205 nice user cpu ticks
      1331555 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4689 softirq cpu ticks
         1592 stolen cpu ticks
      1975851 pages paged in
      1699532 pages paged out
            0 pages swapped in
            0 pages swapped out
     53711188 interrupts
    120621484 CPU context switches
   1763451063 boot time
       240536 forks
