      3845316 K total memory
      2492444 K used memory
       353076 K active memory
      2588620 K inactive memory
       331152 K free memory
        63760 K buffer memory
       957960 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       166305 non-nice user cpu ticks
         1319 nice user cpu ticks
        33664 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
          159 softirq cpu ticks
           24 stolen cpu ticks
       858456 pages paged in
       116864 pages paged out
            0 pages swapped in
            0 pages swapped out
      1247133 interrupts
      4461364 CPU context switches
   1763544886 boot time
        21392 forks
