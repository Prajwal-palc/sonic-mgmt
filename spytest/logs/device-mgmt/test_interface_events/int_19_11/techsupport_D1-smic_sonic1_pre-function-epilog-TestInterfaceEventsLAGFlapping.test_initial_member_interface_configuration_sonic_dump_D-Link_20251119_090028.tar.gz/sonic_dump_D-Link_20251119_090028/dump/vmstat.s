      3845316 K total memory
      3036984 K used memory
       242848 K active memory
      2410936 K inactive memory
       289828 K free memory
        19284 K buffer memory
       499220 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7781478 non-nice user cpu ticks
        34665 nice user cpu ticks
      1360519 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4735 softirq cpu ticks
         1395 stolen cpu ticks
      2250360 pages paged in
      1749816 pages paged out
            0 pages swapped in
            0 pages swapped out
     52332727 interrupts
    119356137 CPU context switches
   1763451053 boot time
       254709 forks
