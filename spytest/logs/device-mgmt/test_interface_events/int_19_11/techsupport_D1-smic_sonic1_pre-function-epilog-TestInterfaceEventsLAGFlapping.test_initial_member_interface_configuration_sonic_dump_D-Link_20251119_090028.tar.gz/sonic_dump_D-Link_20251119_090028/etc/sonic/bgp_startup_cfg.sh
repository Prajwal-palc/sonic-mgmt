#!/bin/bash

# Set BGP ASN and enable FRR management framework config
redis-cli -n 4 hset "DEVICE_METADATA|localhost" "bgp_asn" "1"
redis-cli -n 4 hset "DEVICE_METADATA|localhost" "frr_mgmt_framework_config" "true"
