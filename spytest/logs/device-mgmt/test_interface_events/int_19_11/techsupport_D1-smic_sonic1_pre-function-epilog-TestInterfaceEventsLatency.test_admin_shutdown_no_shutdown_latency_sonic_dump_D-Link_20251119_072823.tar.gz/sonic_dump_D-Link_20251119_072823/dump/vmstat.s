      3845316 K total memory
      2919928 K used memory
       276752 K active memory
      2437672 K inactive memory
       313668 K free memory
        32424 K buffer memory
       579296 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7347743 non-nice user cpu ticks
        11079 nice user cpu ticks
      1265812 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4347 softirq cpu ticks
         1357 stolen cpu ticks
      1913960 pages paged in
      1449672 pages paged out
            0 pages swapped in
            0 pages swapped out
     48935449 interrupts
    110071101 CPU context switches
   1763451054 boot time
       193383 forks
