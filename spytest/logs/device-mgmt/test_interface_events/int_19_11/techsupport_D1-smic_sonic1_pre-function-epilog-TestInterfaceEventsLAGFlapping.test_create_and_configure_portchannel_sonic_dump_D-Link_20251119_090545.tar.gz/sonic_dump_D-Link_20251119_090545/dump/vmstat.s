      3845316 K total memory
      3009264 K used memory
       259880 K active memory
      2355052 K inactive memory
       327352 K free memory
        19220 K buffer memory
       489480 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7805709 non-nice user cpu ticks
        36493 nice user cpu ticks
      1366144 system cpu ticks
          562 idle cpu ticks
           23 IO-wait cpu ticks
            0 IRQ cpu ticks
         4760 softirq cpu ticks
         1400 stolen cpu ticks
      2282695 pages paged in
      1770192 pages paged out
            0 pages swapped in
            0 pages swapped out
     52536269 interrupts
    119890843 CPU context switches
   1763451053 boot time
       259007 forks
