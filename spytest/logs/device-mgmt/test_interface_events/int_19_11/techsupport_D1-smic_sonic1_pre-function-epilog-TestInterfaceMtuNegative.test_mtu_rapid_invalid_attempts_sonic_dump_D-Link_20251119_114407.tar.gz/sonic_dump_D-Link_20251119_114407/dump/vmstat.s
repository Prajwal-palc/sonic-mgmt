      3845316 K total memory
      2782176 K used memory
       400276 K active memory
      2417592 K inactive memory
       272748 K free memory
        50348 K buffer memory
       740044 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       636459 non-nice user cpu ticks
        15949 nice user cpu ticks
       128587 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
          618 softirq cpu ticks
           98 stolen cpu ticks
      1177108 pages paged in
       416552 pages paged out
            0 pages swapped in
            0 pages swapped out
      4759754 interrupts
     15986040 CPU context switches
   1763544886 boot time
        80637 forks
