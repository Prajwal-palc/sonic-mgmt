      3845328 K total memory
      2965324 K used memory
       257292 K active memory
      2394288 K inactive memory
       352980 K free memory
        34312 K buffer memory
       492712 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7906905 non-nice user cpu ticks
        42484 nice user cpu ticks
      1354105 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4789 softirq cpu ticks
         1607 stolen cpu ticks
      2049178 pages paged in
      1777152 pages paged out
            0 pages swapped in
            0 pages swapped out
     54513489 interrupts
    122677761 CPU context switches
   1763451063 boot time
       256988 forks
