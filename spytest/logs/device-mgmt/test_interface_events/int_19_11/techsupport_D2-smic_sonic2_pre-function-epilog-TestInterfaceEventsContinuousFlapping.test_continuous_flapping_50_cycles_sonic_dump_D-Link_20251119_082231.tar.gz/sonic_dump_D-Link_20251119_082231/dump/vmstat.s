      3845328 K total memory
      2941672 K used memory
       261716 K active memory
      2410044 K inactive memory
       359908 K free memory
        39000 K buffer memory
       504748 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7626223 non-nice user cpu ticks
        27801 nice user cpu ticks
      1293982 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4550 softirq cpu ticks
         1567 stolen cpu ticks
      1935383 pages paged in
      1606864 pages paged out
            0 pages swapped in
            0 pages swapped out
     52358234 interrupts
    117257201 CPU context switches
   1763451063 boot time
       221701 forks
