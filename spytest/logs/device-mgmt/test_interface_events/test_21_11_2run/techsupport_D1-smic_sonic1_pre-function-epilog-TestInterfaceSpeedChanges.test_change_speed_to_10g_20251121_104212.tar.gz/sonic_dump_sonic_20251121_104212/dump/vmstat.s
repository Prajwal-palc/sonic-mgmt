      3840620 K total memory
      2602032 K used memory
       404552 K active memory
      2612544 K inactive memory
       329476 K free memory
        42392 K buffer memory
      1139832 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        37815 non-nice user cpu ticks
         6044 nice user cpu ticks
        16668 system cpu ticks
       113105 idle cpu ticks
           96 IO-wait cpu ticks
            0 IRQ cpu ticks
          167 softirq cpu ticks
           26 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       883994 K paged in
       309484 K paged out
            0 pages swapped in
            0 pages swapped out
      1022139 interrupts
      4310325 CPU context switches
   1763720011 boot time
        29048 forks
