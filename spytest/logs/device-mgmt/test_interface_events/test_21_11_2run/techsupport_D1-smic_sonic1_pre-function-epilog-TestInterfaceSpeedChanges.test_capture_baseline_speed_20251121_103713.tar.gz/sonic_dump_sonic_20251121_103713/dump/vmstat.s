      3840620 K total memory
      2602940 K used memory
       397748 K active memory
      2620696 K inactive memory
       308512 K free memory
        41364 K buffer memory
      1162716 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        33269 non-nice user cpu ticks
         3786 nice user cpu ticks
        13756 system cpu ticks
        93266 idle cpu ticks
           86 IO-wait cpu ticks
            0 IRQ cpu ticks
          121 softirq cpu ticks
           22 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       868409 K paged in
       286232 K paged out
            0 pages swapped in
            0 pages swapped out
       836138 interrupts
      3553073 CPU context switches
   1763720011 boot time
        22725 forks
