      3840620 K total memory
      2637684 K used memory
       408116 K active memory
      2586836 K inactive memory
       327640 K free memory
        42244 K buffer memory
      1106424 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        44062 non-nice user cpu ticks
        10486 nice user cpu ticks
        21488 system cpu ticks
       136472 idle cpu ticks
          107 IO-wait cpu ticks
            0 IRQ cpu ticks
          248 softirq cpu ticks
           33 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       924732 K paged in
       349212 K paged out
            0 pages swapped in
            0 pages swapped out
      1302656 interrupts
      5490463 CPU context switches
   1763720011 boot time
        41306 forks
