      3840620 K total memory
      2662276 K used memory
       400160 K active memory
      2595856 K inactive memory
       297992 K free memory
        43108 K buffer memory
      1110912 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        49649 non-nice user cpu ticks
        15240 nice user cpu ticks
        28642 system cpu ticks
       133751 idle cpu ticks
          440 IO-wait cpu ticks
            0 IRQ cpu ticks
          307 softirq cpu ticks
           26 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       949374 K paged in
       391492 K paged out
            0 pages swapped in
            0 pages swapped out
      1493299 interrupts
      6226601 CPU context switches
   1763720484 boot time
        53222 forks
