      3845316 K total memory
      2654728 K used memory
       388568 K active memory
      2446056 K inactive memory
       355408 K free memory
       104732 K buffer memory
       730448 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5616081 non-nice user cpu ticks
        17959 nice user cpu ticks
       987270 system cpu ticks
          291 idle cpu ticks
           33 IO-wait cpu ticks
            0 IRQ cpu ticks
         3428 softirq cpu ticks
          822 stolen cpu ticks
      1589069 pages paged in
      1069784 pages paged out
            0 pages swapped in
            0 pages swapped out
     37860922 interrupts
     85591827 CPU context switches
   1763649154 boot time
       150819 forks
