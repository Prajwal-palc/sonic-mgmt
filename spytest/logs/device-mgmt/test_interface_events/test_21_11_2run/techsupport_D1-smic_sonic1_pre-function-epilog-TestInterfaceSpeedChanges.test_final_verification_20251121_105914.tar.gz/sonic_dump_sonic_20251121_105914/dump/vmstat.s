      3840620 K total memory
      2641008 K used memory
       371852 K active memory
      2528536 K inactive memory
       431108 K free memory
        42824 K buffer memory
       997856 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        53765 non-nice user cpu ticks
        14905 nice user cpu ticks
        27437 system cpu ticks
       178390 idle cpu ticks
          128 IO-wait cpu ticks
            0 IRQ cpu ticks
          341 softirq cpu ticks
           41 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       985105 K paged in
       394840 K paged out
            0 pages swapped in
            0 pages swapped out
      1699870 interrupts
      7108427 CPU context switches
   1763720011 boot time
        54098 forks
