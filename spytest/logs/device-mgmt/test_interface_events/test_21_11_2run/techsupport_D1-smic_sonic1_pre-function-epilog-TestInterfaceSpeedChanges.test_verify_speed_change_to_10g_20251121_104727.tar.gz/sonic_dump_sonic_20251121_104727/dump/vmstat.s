      3840620 K total memory
      2666416 K used memory
       409620 K active memory
      2600036 K inactive memory
       283608 K free memory
        42728 K buffer memory
      1121108 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        42457 non-nice user cpu ticks
         8277 nice user cpu ticks
        19509 system cpu ticks
       134145 idle cpu ticks
          105 IO-wait cpu ticks
            0 IRQ cpu ticks
          210 softirq cpu ticks
           30 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       903799 K paged in
       330928 K paged out
            0 pages swapped in
            0 pages swapped out
      1215286 interrupts
      5101493 CPU context switches
   1763720011 boot time
        35370 forks
