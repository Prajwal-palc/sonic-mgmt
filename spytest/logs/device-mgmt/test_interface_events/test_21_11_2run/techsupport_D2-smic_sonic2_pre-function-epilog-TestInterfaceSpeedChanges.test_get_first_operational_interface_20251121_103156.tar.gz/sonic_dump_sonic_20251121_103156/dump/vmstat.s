      3840620 K total memory
      2589348 K used memory
       380484 K active memory
      2608692 K inactive memory
       338668 K free memory
        36820 K buffer memory
      1147124 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        24855 non-nice user cpu ticks
         1627 nice user cpu ticks
        11164 system cpu ticks
        28624 idle cpu ticks
          394 IO-wait cpu ticks
            0 IRQ cpu ticks
           67 softirq cpu ticks
           11 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       857196 K paged in
       259496 K paged out
            0 pages swapped in
            0 pages swapped out
       461951 interrupts
      2030108 CPU context switches
   1763720484 boot time
        15521 forks
