      3840620 K total memory
      2631732 K used memory
       410920 K active memory
      2589096 K inactive memory
       305664 K free memory
        42376 K buffer memory
      1136092 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        40392 non-nice user cpu ticks
        10724 nice user cpu ticks
        22620 system cpu ticks
        91511 idle cpu ticks
          422 IO-wait cpu ticks
            0 IRQ cpu ticks
          228 softirq cpu ticks
           21 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       914610 K paged in
       346200 K paged out
            0 pages swapped in
            0 pages swapped out
      1114150 interrupts
      4692407 CPU context switches
   1763720484 boot time
        40596 forks
