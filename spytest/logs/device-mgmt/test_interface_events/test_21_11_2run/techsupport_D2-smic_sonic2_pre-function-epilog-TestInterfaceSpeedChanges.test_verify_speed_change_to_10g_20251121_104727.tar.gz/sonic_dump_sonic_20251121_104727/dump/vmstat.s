      3840620 K total memory
      2601364 K used memory
       405668 K active memory
      2578692 K inactive memory
       343132 K free memory
        41864 K buffer memory
      1128748 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        38925 non-nice user cpu ticks
         8522 nice user cpu ticks
        20605 system cpu ticks
        89769 idle cpu ticks
          419 IO-wait cpu ticks
            0 IRQ cpu ticks
          199 softirq cpu ticks
           20 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       899477 K paged in
       331404 K paged out
            0 pages swapped in
            0 pages swapped out
      1031040 interrupts
      4317066 CPU context switches
   1763720484 boot time
        34696 forks
