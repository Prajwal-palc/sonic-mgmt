      3845316 K total memory
      2653592 K used memory
       384252 K active memory
      2444308 K inactive memory
       367028 K free memory
       103780 K buffer memory
       720916 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5588423 non-nice user cpu ticks
        16108 nice user cpu ticks
       981167 system cpu ticks
          291 idle cpu ticks
           33 IO-wait cpu ticks
            0 IRQ cpu ticks
         3393 softirq cpu ticks
          818 stolen cpu ticks
      1581742 pages paged in
      1047268 pages paged out
            0 pages swapped in
            0 pages swapped out
     37636409 interrupts
     84955199 CPU context switches
   1763649154 boot time
       146138 forks
