      3840620 K total memory
      2667008 K used memory
       403116 K active memory
      2597548 K inactive memory
       286636 K free memory
        42384 K buffer memory
      1118784 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        44880 non-nice user cpu ticks
        12956 nice user cpu ticks
        25614 system cpu ticks
       112616 idle cpu ticks
          431 IO-wait cpu ticks
            0 IRQ cpu ticks
          265 softirq cpu ticks
           24 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       929782 K paged in
       370164 K paged out
            0 pages swapped in
            0 pages swapped out
      1300192 interrupts
      5447094 CPU context switches
   1763720484 boot time
        46862 forks
