      3840620 K total memory
      2666536 K used memory
       413156 K active memory
      2588432 K inactive memory
       293304 K free memory
        43280 K buffer memory
      1111780 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        48821 non-nice user cpu ticks
        12661 nice user cpu ticks
        24486 system cpu ticks
       157080 idle cpu ticks
          118 IO-wait cpu ticks
            0 IRQ cpu ticks
          291 softirq cpu ticks
           37 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       943773 K paged in
       371240 K paged out
            0 pages swapped in
            0 pages swapped out
      1498075 interrupts
      6282576 CPU context switches
   1763720011 boot time
        47624 forks
