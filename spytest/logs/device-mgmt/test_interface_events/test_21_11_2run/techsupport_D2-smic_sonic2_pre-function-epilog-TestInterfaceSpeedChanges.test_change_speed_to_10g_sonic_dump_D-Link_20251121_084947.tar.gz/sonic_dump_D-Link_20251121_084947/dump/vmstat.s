      3845316 K total memory
      2835176 K used memory
       292244 K active memory
      2358308 K inactive memory
       330848 K free memory
       107276 K buffer memory
       572016 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     14425945 non-nice user cpu ticks
        40656 nice user cpu ticks
      2540553 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         8500 softirq cpu ticks
         1504 stolen cpu ticks
      2145939 pages paged in
      2440168 pages paged out
            0 pages swapped in
            0 pages swapped out
     97187756 interrupts
    214966577 CPU context switches
   1763544873 boot time
       362729 forks
