      3840620 K total memory
      2767180 K used memory
       409668 K active memory
      2752776 K inactive memory
       142424 K free memory
        41292 K buffer memory
      1164972 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        34345 non-nice user cpu ticks
         6233 nice user cpu ticks
        17553 system cpu ticks
        67971 idle cpu ticks
          412 IO-wait cpu ticks
            0 IRQ cpu ticks
          158 softirq cpu ticks
           17 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       880140 K paged in
       311148 K paged out
            0 pages swapped in
            0 pages swapped out
       836129 interrupts
      3542786 CPU context switches
   1763720484 boot time
        28357 forks
