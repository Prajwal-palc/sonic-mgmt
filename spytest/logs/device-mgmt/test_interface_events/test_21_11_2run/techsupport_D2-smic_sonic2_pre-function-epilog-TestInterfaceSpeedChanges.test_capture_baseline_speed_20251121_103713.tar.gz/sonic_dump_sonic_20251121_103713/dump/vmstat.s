      3840620 K total memory
      2591572 K used memory
       398224 K active memory
      2582176 K inactive memory
       316304 K free memory
        40032 K buffer memory
      1167868 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        29926 non-nice user cpu ticks
         3936 nice user cpu ticks
        14446 system cpu ticks
        49353 idle cpu ticks
          405 IO-wait cpu ticks
            0 IRQ cpu ticks
          119 softirq cpu ticks
           15 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       870808 K paged in
       290508 K paged out
            0 pages swapped in
            0 pages swapped out
       657575 interrupts
      2810407 CPU context switches
   1763720484 boot time
        22135 forks
