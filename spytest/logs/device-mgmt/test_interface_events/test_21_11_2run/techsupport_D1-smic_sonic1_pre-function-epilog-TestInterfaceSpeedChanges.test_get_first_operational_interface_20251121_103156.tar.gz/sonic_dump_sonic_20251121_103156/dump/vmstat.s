      3840620 K total memory
      2584860 K used memory
       376780 K active memory
      2588656 K inactive memory
       341184 K free memory
        38164 K buffer memory
      1147552 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        28376 non-nice user cpu ticks
         1560 nice user cpu ticks
        10847 system cpu ticks
        72005 idle cpu ticks
           74 IO-wait cpu ticks
            0 IRQ cpu ticks
           78 softirq cpu ticks
           16 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       852551 K paged in
       259788 K paged out
            0 pages swapped in
            0 pages swapped out
       634725 interrupts
      2740658 CPU context switches
   1763720011 boot time
        16213 forks
