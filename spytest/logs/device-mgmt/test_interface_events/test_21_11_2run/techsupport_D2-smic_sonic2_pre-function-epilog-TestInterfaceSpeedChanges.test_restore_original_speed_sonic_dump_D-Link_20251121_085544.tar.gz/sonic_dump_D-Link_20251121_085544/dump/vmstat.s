      3845316 K total memory
      2835052 K used memory
       299292 K active memory
      2351708 K inactive memory
       328556 K free memory
       107388 K buffer memory
       574320 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     14453775 non-nice user cpu ticks
        42551 nice user cpu ticks
      2546621 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         8525 softirq cpu ticks
         1508 stolen cpu ticks
      2156469 pages paged in
      2459532 pages paged out
            0 pages swapped in
            0 pages swapped out
     97413197 interrupts
    215534448 CPU context switches
   1763544873 boot time
       366950 forks
