      3845316 K total memory
      2636516 K used memory
       382848 K active memory
      2433384 K inactive memory
       389212 K free memory
        91180 K buffer memory
       728408 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5183259 non-nice user cpu ticks
        14307 nice user cpu ticks
       908314 system cpu ticks
          291 idle cpu ticks
           33 IO-wait cpu ticks
            0 IRQ cpu ticks
         3136 softirq cpu ticks
          778 stolen cpu ticks
      1550954 pages paged in
       964240 pages paged out
            0 pages swapped in
            0 pages swapped out
     34838416 interrupts
     78451652 CPU context switches
   1763649154 boot time
       133425 forks
