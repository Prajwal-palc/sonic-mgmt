      3845316 K total memory
      2841884 K used memory
       301512 K active memory
      2398832 K inactive memory
       328812 K free memory
       135220 K buffer memory
       539400 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     13934053 non-nice user cpu ticks
        35055 nice user cpu ticks
      2450064 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         8189 softirq cpu ticks
         1440 stolen cpu ticks
      2018941 pages paged in
      2311976 pages paged out
            0 pages swapped in
            0 pages swapped out
     93748861 interrupts
    206973421 CPU context switches
   1763544873 boot time
       340746 forks
