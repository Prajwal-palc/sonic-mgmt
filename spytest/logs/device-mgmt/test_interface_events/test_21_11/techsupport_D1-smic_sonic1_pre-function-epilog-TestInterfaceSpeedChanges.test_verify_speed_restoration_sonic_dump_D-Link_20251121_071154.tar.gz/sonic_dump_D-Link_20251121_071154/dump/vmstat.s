      3845316 K total memory
      2609092 K used memory
       426520 K active memory
      2455836 K inactive memory
       339148 K free memory
       122428 K buffer memory
       774648 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5096605 non-nice user cpu ticks
        10663 nice user cpu ticks
       890267 system cpu ticks
          291 idle cpu ticks
           33 IO-wait cpu ticks
            0 IRQ cpu ticks
         3056 softirq cpu ticks
          761 stolen cpu ticks
      1487704 pages paged in
       903844 pages paged out
            0 pages swapped in
            0 pages swapped out
     34148092 interrupts
     76417839 CPU context switches
   1763649154 boot time
       121579 forks
