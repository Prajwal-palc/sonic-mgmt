      3845316 K total memory
      2603316 K used memory
       443952 K active memory
      2455744 K inactive memory
       328652 K free memory
       155488 K buffer memory
       757860 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5046105 non-nice user cpu ticks
         1705 nice user cpu ticks
       875497 system cpu ticks
          291 idle cpu ticks
           33 IO-wait cpu ticks
            0 IRQ cpu ticks
         2983 softirq cpu ticks
          750 stolen cpu ticks
      1358624 pages paged in
       813420 pages paged out
            0 pages swapped in
            0 pages swapped out
     33634588 interrupts
     74841252 CPU context switches
   1763649154 boot time
       101653 forks
