      3845316 K total memory
      2677456 K used memory
       397696 K active memory
      2466968 K inactive memory
       341356 K free memory
        92488 K buffer memory
       734016 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5155677 non-nice user cpu ticks
        12492 nice user cpu ticks
       902208 system cpu ticks
          291 idle cpu ticks
           33 IO-wait cpu ticks
            0 IRQ cpu ticks
         3112 softirq cpu ticks
          770 stolen cpu ticks
      1539056 pages paged in
       942208 pages paged out
            0 pages swapped in
            0 pages swapped out
     34612902 interrupts
     77814367 CPU context switches
   1763649154 boot time
       128688 forks
