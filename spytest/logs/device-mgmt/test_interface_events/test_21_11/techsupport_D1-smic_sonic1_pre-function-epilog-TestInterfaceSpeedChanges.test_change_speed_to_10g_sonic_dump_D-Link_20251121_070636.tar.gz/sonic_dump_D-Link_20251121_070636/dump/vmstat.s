      3845316 K total memory
      2620100 K used memory
       421848 K active memory
      2462272 K inactive memory
       338920 K free memory
       121900 K buffer memory
       764396 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5077141 non-nice user cpu ticks
         5311 nice user cpu ticks
       883354 system cpu ticks
          291 idle cpu ticks
           33 IO-wait cpu ticks
            0 IRQ cpu ticks
         3022 softirq cpu ticks
          756 stolen cpu ticks
      1473590 pages paged in
       855176 pages paged out
            0 pages swapped in
            0 pages swapped out
     33914359 interrupts
     75657232 CPU context switches
   1763649154 boot time
       110151 forks
