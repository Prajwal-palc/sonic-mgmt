      3845316 K total memory
      2827492 K used memory
       306740 K active memory
      2382360 K inactive memory
       342088 K free memory
       141100 K buffer memory
       534636 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     13922071 non-nice user cpu ticks
        31348 nice user cpu ticks
      2445481 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         8168 softirq cpu ticks
         1439 stolen cpu ticks
      2004590 pages paged in
      2275420 pages paged out
            0 pages swapped in
            0 pages swapped out
     93596809 interrupts
    206494155 CPU context switches
   1763544873 boot time
       333215 forks
