      3845316 K total memory
      2898864 K used memory
       311120 K active memory
      2452312 K inactive memory
       258676 K free memory
       141304 K buffer memory
       546472 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     13928180 non-nice user cpu ticks
        33190 nice user cpu ticks
      2447814 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         8179 softirq cpu ticks
         1440 stolen cpu ticks
      2012596 pages paged in
      2293232 pages paged out
            0 pages swapped in
            0 pages swapped out
     93673015 interrupts
    206735358 CPU context switches
   1763544873 boot time
       336971 forks
