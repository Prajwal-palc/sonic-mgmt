      3845316 K total memory
      2635352 K used memory
       423780 K active memory
      2477028 K inactive memory
       325060 K free memory
       121752 K buffer memory
       763152 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5084019 non-nice user cpu ticks
         7113 nice user cpu ticks
       885756 system cpu ticks
          291 idle cpu ticks
           33 IO-wait cpu ticks
            0 IRQ cpu ticks
         3035 softirq cpu ticks
          759 stolen cpu ticks
      1478120 pages paged in
       872148 pages paged out
            0 pages swapped in
            0 pages swapped out
     33995179 interrupts
     75923539 CPU context switches
   1763649154 boot time
       113977 forks
