      3845316 K total memory
      2608828 K used memory
       391696 K active memory
      2467416 K inactive memory
       373472 K free memory
       121032 K buffer memory
       741984 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5053374 non-nice user cpu ticks
         3551 nice user cpu ticks
       877959 system cpu ticks
          291 idle cpu ticks
           33 IO-wait cpu ticks
            0 IRQ cpu ticks
         2994 softirq cpu ticks
          753 stolen cpu ticks
      1446264 pages paged in
       834888 pages paged out
            0 pages swapped in
            0 pages swapped out
     33719410 interrupts
     75108907 CPU context switches
   1763649154 boot time
       105803 forks
