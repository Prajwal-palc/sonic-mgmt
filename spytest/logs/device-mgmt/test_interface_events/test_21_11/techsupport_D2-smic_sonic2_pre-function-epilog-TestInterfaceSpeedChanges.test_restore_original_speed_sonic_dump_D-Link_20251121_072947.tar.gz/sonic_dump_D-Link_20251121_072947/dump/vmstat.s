      3845316 K total memory
      2811068 K used memory
       306160 K active memory
      2361528 K inactive memory
       335552 K free memory
       122020 K buffer memory
       576676 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     14020639 non-nice user cpu ticks
        38770 nice user cpu ticks
      2468062 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         8261 softirq cpu ticks
         1448 stolen cpu ticks
      2101310 pages paged in
      2366364 pages paged out
            0 pages swapped in
            0 pages swapped out
     94421570 interrupts
    208745050 CPU context switches
   1763544873 boot time
       351002 forks
