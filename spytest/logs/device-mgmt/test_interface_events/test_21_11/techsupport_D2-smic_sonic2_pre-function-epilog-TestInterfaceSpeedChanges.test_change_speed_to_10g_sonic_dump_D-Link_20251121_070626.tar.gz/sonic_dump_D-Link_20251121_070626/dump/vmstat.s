      3845316 K total memory
      2827284 K used memory
       309216 K active memory
      2402268 K inactive memory
       320912 K free memory
       151864 K buffer memory
       545256 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     13915012 non-nice user cpu ticks
        29482 nice user cpu ticks
      2443005 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         8158 softirq cpu ticks
         1435 stolen cpu ticks
      1994456 pages paged in
      2257180 pages paged out
            0 pages swapped in
            0 pages swapped out
     93512233 interrupts
    206224906 CPU context switches
   1763544873 boot time
       329317 forks
