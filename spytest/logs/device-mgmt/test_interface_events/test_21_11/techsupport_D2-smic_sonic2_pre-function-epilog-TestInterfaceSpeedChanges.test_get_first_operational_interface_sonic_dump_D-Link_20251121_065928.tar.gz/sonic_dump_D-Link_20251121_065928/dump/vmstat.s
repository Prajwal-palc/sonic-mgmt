      3845316 K total memory
      2788136 K used memory
       321104 K active memory
      2396788 K inactive memory
       315396 K free memory
       175036 K buffer memory
       566748 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     13884789 non-nice user cpu ticks
        25745 nice user cpu ticks
      2435332 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         8121 softirq cpu ticks
         1430 stolen cpu ticks
      1885991 pages paged in
      2218140 pages paged out
            0 pages swapped in
            0 pages swapped out
     93231377 interrupts
    205454566 CPU context switches
   1763544873 boot time
       321071 forks
