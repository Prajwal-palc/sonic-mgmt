      3845316 K total memory
      2788404 K used memory
       323264 K active memory
      2396164 K inactive memory
       315120 K free memory
       168296 K buffer memory
       573496 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     13891069 non-nice user cpu ticks
        27652 nice user cpu ticks
      2437643 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         8135 softirq cpu ticks
         1431 stolen cpu ticks
      1961748 pages paged in
      2237912 pages paged out
            0 pages swapped in
            0 pages swapped out
     93309581 interrupts
    205697738 CPU context switches
   1763544873 boot time
       325162 forks
