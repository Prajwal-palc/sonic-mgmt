      3845316 K total memory
      2610332 K used memory
       425496 K active memory
      2454152 K inactive memory
       340908 K free memory
       122012 K buffer memory
       772064 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5089556 non-nice user cpu ticks
         8883 nice user cpu ticks
       887894 system cpu ticks
          291 idle cpu ticks
           33 IO-wait cpu ticks
            0 IRQ cpu ticks
         3046 softirq cpu ticks
          760 stolen cpu ticks
      1484128 pages paged in
       887192 pages paged out
            0 pages swapped in
            0 pages swapped out
     34066883 interrupts
     76160739 CPU context switches
   1763649154 boot time
       117786 forks
