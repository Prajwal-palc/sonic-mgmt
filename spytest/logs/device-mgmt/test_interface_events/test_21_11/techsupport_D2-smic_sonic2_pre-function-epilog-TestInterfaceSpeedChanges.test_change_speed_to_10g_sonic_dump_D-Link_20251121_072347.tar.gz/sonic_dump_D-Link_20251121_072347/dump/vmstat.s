      3845316 K total memory
      2847328 K used memory
       292476 K active memory
      2406204 K inactive memory
       313616 K free memory
       121504 K buffer memory
       562868 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     13992898 non-nice user cpu ticks
        36901 nice user cpu ticks
      2461955 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         8239 softirq cpu ticks
         1442 stolen cpu ticks
      2092811 pages paged in
      2343636 pages paged out
            0 pages swapped in
            0 pages swapped out
     94201136 interrupts
    208180969 CPU context switches
   1763544873 boot time
       346731 forks
