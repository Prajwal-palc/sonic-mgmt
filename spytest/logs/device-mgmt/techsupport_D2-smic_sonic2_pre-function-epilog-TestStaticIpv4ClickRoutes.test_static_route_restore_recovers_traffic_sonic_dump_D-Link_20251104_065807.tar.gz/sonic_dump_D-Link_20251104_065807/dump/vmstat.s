      3845316 K total memory
      2808304 K used memory
       328876 K active memory
      2521488 K inactive memory
       313648 K free memory
       130316 K buffer memory
       593048 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5830850 non-nice user cpu ticks
        13757 nice user cpu ticks
      2554475 system cpu ticks
     40171363 idle cpu ticks
        13233 IO-wait cpu ticks
            0 IRQ cpu ticks
        75249 softirq cpu ticks
        42548 stolen cpu ticks
      3351681 pages paged in
      8472012 pages paged out
            0 pages swapped in
            0 pages swapped out
    622548206 interrupts
   1466950959 CPU context switches
   1761727777 boot time
       847707 forks
