      3845316 K total memory
      2619388 K used memory
       395356 K active memory
      2562044 K inactive memory
       312676 K free memory
        59460 K buffer memory
       853792 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        85023 non-nice user cpu ticks
         5286 nice user cpu ticks
        41910 system cpu ticks
       379350 idle cpu ticks
          223 IO-wait cpu ticks
            0 IRQ cpu ticks
          773 softirq cpu ticks
          369 stolen cpu ticks
      1009086 pages paged in
       215676 pages paged out
            0 pages swapped in
            0 pages swapped out
      6783126 interrupts
     18318205 CPU context switches
   1762341341 boot time
        38534 forks
