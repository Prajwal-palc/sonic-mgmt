      3845316 K total memory
      2608872 K used memory
       398360 K active memory
      2519700 K inactive memory
       319972 K free memory
        53856 K buffer memory
       862616 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        81336 non-nice user cpu ticks
        10518 nice user cpu ticks
        42810 system cpu ticks
       387557 idle cpu ticks
          354 IO-wait cpu ticks
            0 IRQ cpu ticks
          738 softirq cpu ticks
          378 stolen cpu ticks
       970785 pages paged in
       274744 pages paged out
            0 pages swapped in
            0 pages swapped out
      6931250 interrupts
     19296418 CPU context switches
   1763011705 boot time
        51509 forks
