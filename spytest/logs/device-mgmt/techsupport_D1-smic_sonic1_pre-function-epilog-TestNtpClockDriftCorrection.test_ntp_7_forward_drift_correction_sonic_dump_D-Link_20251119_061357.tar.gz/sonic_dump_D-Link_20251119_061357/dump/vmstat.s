      3845316 K total memory
      2814040 K used memory
       300224 K active memory
      2503972 K inactive memory
       321464 K free memory
       132456 K buffer memory
       577356 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6956990 non-nice user cpu ticks
         3697 nice user cpu ticks
      1187727 system cpu ticks
          562 idle cpu ticks
           20 IO-wait cpu ticks
            0 IRQ cpu ticks
         4026 softirq cpu ticks
         1295 stolen cpu ticks
      1545108 pages paged in
      1287264 pages paged out
            0 pages swapped in
            0 pages swapped out
     46027926 interrupts
    102289571 CPU context switches
   1763451354 boot time
       162425 forks
