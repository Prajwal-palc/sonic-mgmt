      3845316 K total memory
      2675356 K used memory
       416024 K active memory
      2544540 K inactive memory
       267172 K free memory
        57280 K buffer memory
       845508 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        95960 non-nice user cpu ticks
        13010 nice user cpu ticks
        50696 system cpu ticks
       417183 idle cpu ticks
          340 IO-wait cpu ticks
            0 IRQ cpu ticks
          774 softirq cpu ticks
          377 stolen cpu ticks
      1011325 pages paged in
       310612 pages paged out
            0 pages swapped in
            0 pages swapped out
      7709902 interrupts
     21272317 CPU context switches
   1763011717 boot time
        59556 forks
