      3845316 K total memory
      2615240 K used memory
       411240 K active memory
      2498728 K inactive memory
       328884 K free memory
        54872 K buffer memory
       846320 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        87027 non-nice user cpu ticks
        11088 nice user cpu ticks
        45552 system cpu ticks
       379015 idle cpu ticks
          327 IO-wait cpu ticks
            0 IRQ cpu ticks
          695 softirq cpu ticks
          343 stolen cpu ticks
       996184 pages paged in
       281676 pages paged out
            0 pages swapped in
            0 pages swapped out
      6963076 interrupts
     19276511 CPU context switches
   1763011716 boot time
        53255 forks
