      3845316 K total memory
      2639216 K used memory
       397132 K active memory
      2594520 K inactive memory
       276564 K free memory
        78968 K buffer memory
       850568 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       102327 non-nice user cpu ticks
         5426 nice user cpu ticks
        49165 system cpu ticks
       548827 idle cpu ticks
          474 IO-wait cpu ticks
            0 IRQ cpu ticks
         1020 softirq cpu ticks
          522 stolen cpu ticks
       997601 pages paged in
       255824 pages paged out
            0 pages swapped in
            0 pages swapped out
      9271061 interrupts
     24083136 CPU context switches
   1762339297 boot time
        40123 forks
