      3845316 K total memory
      2803880 K used memory
       314964 K active memory
      2539208 K inactive memory
       317264 K free memory
       148144 K buffer memory
       576028 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5819472 non-nice user cpu ticks
         6866 nice user cpu ticks
      2544970 system cpu ticks
     40128238 idle cpu ticks
        13211 IO-wait cpu ticks
            0 IRQ cpu ticks
        75081 softirq cpu ticks
        42492 stolen cpu ticks
      3289949 pages paged in
      8413888 pages paged out
            0 pages swapped in
            0 pages swapped out
    621554000 interrupts
   1464270655 CPU context switches
   1761727776 boot time
       831490 forks
