      3845316 K total memory
      2192240 K used memory
       325744 K active memory
      2303748 K inactive memory
       658432 K free memory
        36552 K buffer memory
       958092 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        18473 non-nice user cpu ticks
         1417 nice user cpu ticks
         9812 system cpu ticks
        15734 idle cpu ticks
           31 IO-wait cpu ticks
            0 IRQ cpu ticks
          112 softirq cpu ticks
           23 stolen cpu ticks
       820407 pages paged in
        92352 pages paged out
            0 pages swapped in
            0 pages swapped out
       559243 interrupts
      3016792 CPU context switches
   1762371910 boot time
        17458 forks
