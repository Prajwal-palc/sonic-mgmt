      3845316 K total memory
      2609156 K used memory
       335040 K active memory
      2622168 K inactive memory
       318844 K free memory
        57060 K buffer memory
       860256 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        74743 non-nice user cpu ticks
         3366 nice user cpu ticks
        36388 system cpu ticks
       350248 idle cpu ticks
          209 IO-wait cpu ticks
            0 IRQ cpu ticks
          681 softirq cpu ticks
          338 stolen cpu ticks
       959586 pages paged in
       189132 pages paged out
            0 pages swapped in
            0 pages swapped out
      6109437 interrupts
     16474394 CPU context switches
   1762341340 boot time
        31434 forks
