      3845316 K total memory
      2571664 K used memory
       351976 K active memory
      2607740 K inactive memory
       309304 K free memory
        43744 K buffer memory
       920604 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        49581 non-nice user cpu ticks
         3133 nice user cpu ticks
        24219 system cpu ticks
       225865 idle cpu ticks
          284 IO-wait cpu ticks
            0 IRQ cpu ticks
          427 softirq cpu ticks
          218 stolen cpu ticks
       874198 pages paged in
       164176 pages paged out
            0 pages swapped in
            0 pages swapped out
      3962840 interrupts
     11402515 CPU context switches
   1763011706 boot time
        28335 forks
