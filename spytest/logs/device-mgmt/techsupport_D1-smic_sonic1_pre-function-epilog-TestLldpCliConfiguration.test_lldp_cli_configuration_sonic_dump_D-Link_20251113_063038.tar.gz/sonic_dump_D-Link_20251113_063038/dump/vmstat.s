      3845316 K total memory
      2588296 K used memory
       388924 K active memory
      2554672 K inactive memory
       322552 K free memory
        47760 K buffer memory
       886708 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        59952 non-nice user cpu ticks
         5307 nice user cpu ticks
        30180 system cpu ticks
       264565 idle cpu ticks
          289 IO-wait cpu ticks
            0 IRQ cpu ticks
          459 softirq cpu ticks
          240 stolen cpu ticks
       948871 pages paged in
       192084 pages paged out
            0 pages swapped in
            0 pages swapped out
      4715165 interrupts
     13274289 CPU context switches
   1763011716 boot time
        34231 forks
