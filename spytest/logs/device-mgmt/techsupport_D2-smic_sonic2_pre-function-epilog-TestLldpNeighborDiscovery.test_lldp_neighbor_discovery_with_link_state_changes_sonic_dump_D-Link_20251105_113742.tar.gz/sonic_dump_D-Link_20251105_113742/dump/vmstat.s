      3845316 K total memory
      2565336 K used memory
       344512 K active memory
      2640540 K inactive memory
       307136 K free memory
        63180 K buffer memory
       909664 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        51538 non-nice user cpu ticks
         1483 nice user cpu ticks
        24367 system cpu ticks
       247761 idle cpu ticks
          365 IO-wait cpu ticks
            0 IRQ cpu ticks
          463 softirq cpu ticks
          246 stolen cpu ticks
       869587 pages paged in
       146496 pages paged out
            0 pages swapped in
            0 pages swapped out
      4234993 interrupts
     11647701 CPU context switches
   1762339296 boot time
        23347 forks
