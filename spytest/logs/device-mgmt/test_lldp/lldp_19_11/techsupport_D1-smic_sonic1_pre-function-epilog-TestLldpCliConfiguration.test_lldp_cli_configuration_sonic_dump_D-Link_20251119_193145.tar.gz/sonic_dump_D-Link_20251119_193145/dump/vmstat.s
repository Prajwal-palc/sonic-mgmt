      3845316 K total memory
      2839056 K used memory
       308608 K active memory
      2365496 K inactive memory
       304164 K free memory
        97048 K buffer memory
       605048 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      3022157 non-nice user cpu ticks
        19841 nice user cpu ticks
       543440 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
         1970 softirq cpu ticks
          344 stolen cpu ticks
      1433519 pages paged in
       829968 pages paged out
            0 pages swapped in
            0 pages swapped out
     20660610 interrupts
     52597302 CPU context switches
   1763544885 boot time
       137880 forks
