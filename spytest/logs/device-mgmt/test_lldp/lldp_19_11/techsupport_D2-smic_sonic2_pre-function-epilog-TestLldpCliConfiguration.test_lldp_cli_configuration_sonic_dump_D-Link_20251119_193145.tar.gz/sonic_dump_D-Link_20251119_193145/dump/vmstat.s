      3845316 K total memory
      2622316 K used memory
       416004 K active memory
      2489760 K inactive memory
       301660 K free memory
       129120 K buffer memory
       792220 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      3025562 non-nice user cpu ticks
        19497 nice user cpu ticks
       540699 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         1850 softirq cpu ticks
          357 stolen cpu ticks
      1183512 pages paged in
       677816 pages paged out
            0 pages swapped in
            0 pages swapped out
     20641715 interrupts
     47564691 CPU context switches
   1763544877 boot time
       112974 forks
