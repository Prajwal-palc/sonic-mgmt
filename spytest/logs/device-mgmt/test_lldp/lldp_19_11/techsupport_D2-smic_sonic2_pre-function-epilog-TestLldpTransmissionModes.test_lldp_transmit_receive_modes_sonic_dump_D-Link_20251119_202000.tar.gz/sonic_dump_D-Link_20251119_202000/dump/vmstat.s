      3845316 K total memory
      2687052 K used memory
       359968 K active memory
      2453596 K inactive memory
       362724 K free memory
       124732 K buffer memory
       670808 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      3266704 non-nice user cpu ticks
        23071 nice user cpu ticks
       585831 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         2026 softirq cpu ticks
          371 stolen cpu ticks
      1274345 pages paged in
       758732 pages paged out
            0 pages swapped in
            0 pages swapped out
     22360234 interrupts
     51785864 CPU context switches
   1763544877 boot time
       127344 forks
