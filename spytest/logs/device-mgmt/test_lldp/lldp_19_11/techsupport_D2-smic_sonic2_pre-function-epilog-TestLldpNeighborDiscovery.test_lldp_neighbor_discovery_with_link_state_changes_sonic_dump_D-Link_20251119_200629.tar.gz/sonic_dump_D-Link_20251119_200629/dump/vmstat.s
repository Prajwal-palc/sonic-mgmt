      3845316 K total memory
      2621536 K used memory
       428832 K active memory
      2448660 K inactive memory
       316900 K free memory
       128644 K buffer memory
       778236 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      3200173 non-nice user cpu ticks
        21264 nice user cpu ticks
       572753 system cpu ticks
          264 idle cpu ticks
           10 IO-wait cpu ticks
            0 IRQ cpu ticks
         1974 softirq cpu ticks
          371 stolen cpu ticks
      1225062 pages paged in
       725748 pages paged out
            0 pages swapped in
            0 pages swapped out
     21870924 interrupts
     50469173 CPU context switches
   1763544878 boot time
       121142 forks
