      3845316 K total memory
      2840712 K used memory
       315964 K active memory
      2348868 K inactive memory
       310448 K free memory
        93072 K buffer memory
       601084 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      3195759 non-nice user cpu ticks
        21715 nice user cpu ticks
       575095 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
         2084 softirq cpu ticks
          398 stolen cpu ticks
      1506956 pages paged in
       880900 pages paged out
            0 pages swapped in
            0 pages swapped out
     21879787 interrupts
     55576801 CPU context switches
   1763544885 boot time
       146683 forks
