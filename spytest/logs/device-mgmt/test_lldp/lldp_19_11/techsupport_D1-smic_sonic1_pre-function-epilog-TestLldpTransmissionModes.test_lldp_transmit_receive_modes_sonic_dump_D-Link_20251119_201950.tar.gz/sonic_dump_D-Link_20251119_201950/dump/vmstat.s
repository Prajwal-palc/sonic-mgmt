      3845316 K total memory
      2841052 K used memory
       306764 K active memory
      2343232 K inactive memory
       326592 K free memory
        90628 K buffer memory
       587044 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      3262146 non-nice user cpu ticks
        23535 nice user cpu ticks
       587981 system cpu ticks
          272 idle cpu ticks
           40 IO-wait cpu ticks
            0 IRQ cpu ticks
         2136 softirq cpu ticks
          427 stolen cpu ticks
      1538701 pages paged in
       912804 pages paged out
            0 pages swapped in
            0 pages swapped out
     22363324 interrupts
     56861584 CPU context switches
   1763544885 boot time
       152120 forks
