      3845316 K total memory
      2670400 K used memory
       387148 K active memory
      2451608 K inactive memory
       326748 K free memory
        71968 K buffer memory
       776200 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       152085 non-nice user cpu ticks
        17965 nice user cpu ticks
        78463 system cpu ticks
       808623 idle cpu ticks
          852 IO-wait cpu ticks
            0 IRQ cpu ticks
         1412 softirq cpu ticks
          780 stolen cpu ticks
      1048273 pages paged in
       461140 pages paged out
            0 pages swapped in
            0 pages swapped out
     14022326 interrupts
     36955990 CPU context switches
   1763011705 boot time
        81760 forks
