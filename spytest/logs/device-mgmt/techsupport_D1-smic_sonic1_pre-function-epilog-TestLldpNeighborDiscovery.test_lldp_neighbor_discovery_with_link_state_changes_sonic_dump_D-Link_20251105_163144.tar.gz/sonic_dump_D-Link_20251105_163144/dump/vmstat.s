      3845316 K total memory
      2681464 K used memory
       401800 K active memory
      2536452 K inactive memory
       299568 K free memory
        88420 K buffer memory
       775864 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       251440 non-nice user cpu ticks
         7265 nice user cpu ticks
       115666 system cpu ticks
      1437273 idle cpu ticks
          534 IO-wait cpu ticks
            0 IRQ cpu ticks
         2552 softirq cpu ticks
         1465 stolen cpu ticks
      1093006 pages paged in
       444464 pages paged out
            0 pages swapped in
            0 pages swapped out
     23592171 interrupts
     58174039 CPU context switches
   1762341341 boot time
        68066 forks
