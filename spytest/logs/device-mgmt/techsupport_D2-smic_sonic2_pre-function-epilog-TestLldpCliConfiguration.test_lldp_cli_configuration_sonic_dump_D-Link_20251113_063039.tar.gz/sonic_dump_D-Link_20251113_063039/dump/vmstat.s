      3845316 K total memory
      2576736 K used memory
       369712 K active memory
      2568284 K inactive memory
       324120 K free memory
        46616 K buffer memory
       897844 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        57734 non-nice user cpu ticks
         4987 nice user cpu ticks
        28904 system cpu ticks
       268588 idle cpu ticks
          306 IO-wait cpu ticks
            0 IRQ cpu ticks
          506 softirq cpu ticks
          261 stolen cpu ticks
       921040 pages paged in
       192332 pages paged out
            0 pages swapped in
            0 pages swapped out
      4739086 interrupts
     13455024 CPU context switches
   1763011705 boot time
        34192 forks
