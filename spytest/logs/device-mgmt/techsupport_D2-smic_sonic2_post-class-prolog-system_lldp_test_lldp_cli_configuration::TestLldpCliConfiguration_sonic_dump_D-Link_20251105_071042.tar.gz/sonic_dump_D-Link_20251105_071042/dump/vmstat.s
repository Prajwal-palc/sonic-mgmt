      3845328 K total memory
      2796828 K used memory
       313772 K active memory
      2550836 K inactive memory
       320320 K free memory
       152396 K buffer memory
       575784 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      1753373 non-nice user cpu ticks
         4658 nice user cpu ticks
       750648 system cpu ticks
     13070017 idle cpu ticks
         4523 IO-wait cpu ticks
            0 IRQ cpu ticks
        16407 softirq cpu ticks
        12643 stolen cpu ticks
      1833190 pages paged in
      2742044 pages paged out
            0 pages swapped in
            0 pages swapped out
    200326508 interrupts
    476052719 CPU context switches
   1762163201 boot time
       290042 forks
