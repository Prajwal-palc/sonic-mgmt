      3845316 K total memory
      2800332 K used memory
       323412 K active memory
      2529136 K inactive memory
       320212 K free memory
       188456 K buffer memory
       536316 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5817612 non-nice user cpu ticks
         5010 nice user cpu ticks
      2542849 system cpu ticks
     40122048 idle cpu ticks
        13161 IO-wait cpu ticks
            0 IRQ cpu ticks
        75043 softirq cpu ticks
        42484 stolen cpu ticks
      3169207 pages paged in
      8391680 pages paged out
            0 pages swapped in
            0 pages swapped out
    621375895 interrupts
   1463783428 CPU context switches
   1761727776 boot time
       827349 forks
