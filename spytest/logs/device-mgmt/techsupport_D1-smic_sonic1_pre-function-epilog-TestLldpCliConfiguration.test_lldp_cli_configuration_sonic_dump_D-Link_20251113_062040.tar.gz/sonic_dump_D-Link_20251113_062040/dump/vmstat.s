      3845316 K total memory
      2583148 K used memory
       350204 K active memory
      2599804 K inactive memory
       325264 K free memory
        44904 K buffer memory
       892000 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        51146 non-nice user cpu ticks
         3400 nice user cpu ticks
        25156 system cpu ticks
       222920 idle cpu ticks
          266 IO-wait cpu ticks
            0 IRQ cpu ticks
          386 softirq cpu ticks
          202 stolen cpu ticks
       903658 pages paged in
       163328 pages paged out
            0 pages swapped in
            0 pages swapped out
      3935071 interrupts
     11221711 CPU context switches
   1763011717 boot time
        27932 forks
