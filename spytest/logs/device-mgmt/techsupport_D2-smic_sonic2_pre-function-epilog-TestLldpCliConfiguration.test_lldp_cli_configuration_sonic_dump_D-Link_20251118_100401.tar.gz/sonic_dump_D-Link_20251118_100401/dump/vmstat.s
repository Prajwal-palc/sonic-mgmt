      3845328 K total memory
      2683512 K used memory
       351520 K active memory
      2612288 K inactive memory
       315192 K free memory
        73568 K buffer memory
       773056 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       792035 non-nice user cpu ticks
         1409 nice user cpu ticks
       128792 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
          475 softirq cpu ticks
          188 stolen cpu ticks
      1005897 pages paged in
       364404 pages paged out
            0 pages swapped in
            0 pages swapped out
      5357727 interrupts
     13653710 CPU context switches
   1763451066 boot time
        42779 forks
