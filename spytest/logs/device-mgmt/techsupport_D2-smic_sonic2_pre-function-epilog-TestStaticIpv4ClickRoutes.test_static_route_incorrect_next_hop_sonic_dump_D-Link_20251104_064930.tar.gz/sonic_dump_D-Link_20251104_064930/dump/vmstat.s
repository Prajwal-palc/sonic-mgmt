      3845316 K total memory
      2804996 K used memory
       327560 K active memory
      2524852 K inactive memory
       311344 K free memory
       137288 K buffer memory
       591688 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5822971 non-nice user cpu ticks
        10414 nice user cpu ticks
      2548970 system cpu ticks
     40139012 idle cpu ticks
        13217 IO-wait cpu ticks
            0 IRQ cpu ticks
        75146 softirq cpu ticks
        42508 stolen cpu ticks
      3323484 pages paged in
      8442524 pages paged out
            0 pages swapped in
            0 pages swapped out
    621874126 interrupts
   1465162440 CPU context switches
   1761727776 boot time
       839222 forks
