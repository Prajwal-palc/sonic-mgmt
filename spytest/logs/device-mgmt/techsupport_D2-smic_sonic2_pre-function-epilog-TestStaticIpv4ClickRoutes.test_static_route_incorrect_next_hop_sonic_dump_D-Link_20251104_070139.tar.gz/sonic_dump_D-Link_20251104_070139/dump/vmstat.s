      3845316 K total memory
      2812372 K used memory
       318872 K active memory
      2526720 K inactive memory
       315488 K free memory
       126964 K buffer memory
       590492 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5834172 non-nice user cpu ticks
        17312 nice user cpu ticks
      2558131 system cpu ticks
     40181836 idle cpu ticks
        13238 IO-wait cpu ticks
            0 IRQ cpu ticks
        75298 softirq cpu ticks
        42563 stolen cpu ticks
      3363734 pages paged in
      8513460 pages paged out
            0 pages swapped in
            0 pages swapped out
    622858141 interrupts
   1467824753 CPU context switches
   1761727777 boot time
       855458 forks
