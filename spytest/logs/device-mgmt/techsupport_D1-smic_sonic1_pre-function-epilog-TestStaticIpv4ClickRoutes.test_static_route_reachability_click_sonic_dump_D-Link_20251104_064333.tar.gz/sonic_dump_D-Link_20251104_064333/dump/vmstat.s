      3845328 K total memory
      2850288 K used memory
       298408 K active memory
      2527188 K inactive memory
       318108 K free memory
       171876 K buffer memory
       505056 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5859019 non-nice user cpu ticks
         5001 nice user cpu ticks
      2530385 system cpu ticks
     40055151 idle cpu ticks
        13514 IO-wait cpu ticks
            0 IRQ cpu ticks
        73832 softirq cpu ticks
        42091 stolen cpu ticks
      3262624 pages paged in
      8383432 pages paged out
            0 pages swapped in
            0 pages swapped out
    623535545 interrupts
   1473582809 CPU context switches
   1761727863 boot time
       830186 forks
