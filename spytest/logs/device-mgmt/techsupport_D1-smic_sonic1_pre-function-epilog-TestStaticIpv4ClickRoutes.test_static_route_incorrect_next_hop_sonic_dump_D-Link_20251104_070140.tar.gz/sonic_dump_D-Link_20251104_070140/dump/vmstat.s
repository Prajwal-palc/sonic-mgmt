      3845328 K total memory
      2855832 K used memory
       290952 K active memory
      2518528 K inactive memory
       317984 K free memory
        98364 K buffer memory
       573148 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5877172 non-nice user cpu ticks
        18708 nice user cpu ticks
      2547527 system cpu ticks
     40110805 idle cpu ticks
        13591 IO-wait cpu ticks
            0 IRQ cpu ticks
        74107 softirq cpu ticks
        42153 stolen cpu ticks
      3485118 pages paged in
      8513824 pages paged out
            0 pages swapped in
            0 pages swapped out
    625085191 interrupts
   1477919018 CPU context switches
   1761727864 boot time
       858781 forks
