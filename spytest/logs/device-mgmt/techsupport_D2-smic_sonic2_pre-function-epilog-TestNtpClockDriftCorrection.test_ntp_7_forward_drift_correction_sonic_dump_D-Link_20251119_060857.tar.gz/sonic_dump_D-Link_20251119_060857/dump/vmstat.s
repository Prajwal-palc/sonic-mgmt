      3845328 K total memory
      2840564 K used memory
       292716 K active memory
      2521344 K inactive memory
       315300 K free memory
       143684 K buffer memory
       545780 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6981842 non-nice user cpu ticks
         3694 nice user cpu ticks
      1161629 system cpu ticks
          563 idle cpu ticks
           22 IO-wait cpu ticks
            0 IRQ cpu ticks
         4020 softirq cpu ticks
         1483 stolen cpu ticks
      1521811 pages paged in
      1283104 pages paged out
            0 pages swapped in
            0 pages swapped out
     47515411 interrupts
    105020538 CPU context switches
   1763451064 boot time
       156680 forks
