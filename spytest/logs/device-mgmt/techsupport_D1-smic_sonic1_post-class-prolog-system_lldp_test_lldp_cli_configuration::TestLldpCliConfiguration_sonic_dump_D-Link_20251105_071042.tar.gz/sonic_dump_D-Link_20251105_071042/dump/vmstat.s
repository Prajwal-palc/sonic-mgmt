      3845316 K total memory
      2813996 K used memory
       306084 K active memory
      2558312 K inactive memory
       316208 K free memory
       146668 K buffer memory
       568444 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      1770744 non-nice user cpu ticks
         4664 nice user cpu ticks
       764047 system cpu ticks
     13016083 idle cpu ticks
         4448 IO-wait cpu ticks
            0 IRQ cpu ticks
        16977 softirq cpu ticks
        12323 stolen cpu ticks
      1894756 pages paged in
      2734588 pages paged out
            0 pages swapped in
            0 pages swapped out
    200691504 interrupts
    476293077 CPU context switches
   1762163196 boot time
       293976 forks
