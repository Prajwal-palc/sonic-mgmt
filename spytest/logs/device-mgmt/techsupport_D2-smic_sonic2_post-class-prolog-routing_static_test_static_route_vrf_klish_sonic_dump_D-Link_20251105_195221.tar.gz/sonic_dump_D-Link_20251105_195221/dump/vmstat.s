      3845316 K total memory
      2198884 K used memory
       323552 K active memory
      2306424 K inactive memory
       657424 K free memory
        37436 K buffer memory
       951572 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        18932 non-nice user cpu ticks
         1414 nice user cpu ticks
         9965 system cpu ticks
        15836 idle cpu ticks
           29 IO-wait cpu ticks
            0 IRQ cpu ticks
          119 softirq cpu ticks
           23 stolen cpu ticks
       823369 pages paged in
        92352 pages paged out
            0 pages swapped in
            0 pages swapped out
       567211 interrupts
      3035602 CPU context switches
   1762371902 boot time
        17348 forks
