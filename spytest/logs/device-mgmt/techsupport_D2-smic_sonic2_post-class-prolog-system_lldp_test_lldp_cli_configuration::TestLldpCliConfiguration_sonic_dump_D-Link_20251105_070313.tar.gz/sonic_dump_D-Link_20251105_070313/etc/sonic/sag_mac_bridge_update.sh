#!/usr/bin/bash

write_bcm_tcam_entry() {

    local count=0
    sag_mac=$(redis-cli -n 4 HGET "SAG|GLOBAL" "gateway_mac" | tr -d ":")
    hex_vlanId=$(printf "0x%x" "$1")

    while [ $count -lt 12 ]; do

        redis-cli -n 4 HSET "VLAN_INTERFACE|Vlan${1}" "admin_status" "up" >/dev/null

        if bcmcmd "dump chg my_station_tcam" | grep "$sag_mac" | grep "VLAN_ID=$hex_vlanId"; then
            #echo "####### BCM TCAM Entry for SAG-Vlan${1} ########" >> /var/log/sag_vlan.log
            #bcmcmd "dump chg my_station_tcam" | grep "$sag_mac" | grep "VLAN_ID=$hex_vlanId" >>/var/log/sag_vlan.log
            #echo "############################################" >> /var/log/sag_vlan.log
            return
        fi
        count=$((count+1))
        sleep 5

    done

    #echo "Timeout writing BCM L2 TCAM" >> /var/log/sag_vlan.log
}

#Config enable commands
/usr/bin/docker exec mgmt-framework /sbin/setcap cap_net_admin+ep /sbin/bridge
/usr/bin/docker exec mgmt-framework /sbin/setcap cap_sys_admin,cap_net_admin+ep /usr/bin/nsenter
/usr/bin/docker exec mgmt-framework /usr/bin/nsenter --target 1 --mount --uts --ipc --net --pid mount -o remount,rw /etc/sonic

while ! ip link show Bridge >/dev/null 2>&1; do
	sleep 2
done

SOURCE_FILE="/host/sag_vlan_list"
DEST_FILE="/etc/sonic/sag_vlan_list"

if [ -f "$SOURCE_FILE" ]; then
    cp "$SOURCE_FILE" "$DEST_FILE"
fi

#echo "SAG-VLAN Mapping:" > /var/log/sag_vlan.log
#Kernel Entries
if [ -s "/etc/sonic/sag_vlan_list" ]; then
	while IFS=' ' read -r smac vlanId
	do
		#echo "Line: $smac $vlanId"
		while [ "$(redis-cli -n 6 EXISTS "VLAN_TABLE|Vlan${vlanId}" </dev/null)" -eq 0 ]; do
			echo "Waiting for Vlan${vlanId} to be ready in STATE_DB..."
			sleep 1
		done
		/sbin/bridge fdb add "$smac" dev Bridge vlan "$vlanId" self permanent

		#echo "SAG for VLAN ${vlanId}" >> /var/log/sag_vlan.log
		write_bcm_tcam_entry ${vlanId} </dev/null
		#echo "Done for VLAN ${vlanId}" >> /var/log/sag_vlan.log

	done < "/etc/sonic/sag_vlan_list"
fi
