      3845328 K total memory
      2790936 K used memory
       324368 K active memory
      2559864 K inactive memory
       310104 K free memory
       173260 K buffer memory
       571028 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      1747154 non-nice user cpu ticks
         2662 nice user cpu ticks
       746437 system cpu ticks
     13039901 idle cpu ticks
         4423 IO-wait cpu ticks
            0 IRQ cpu ticks
        16342 softirq cpu ticks
        12610 stolen cpu ticks
      1742865 pages paged in
      2713128 pages paged out
            0 pages swapped in
            0 pages swapped out
    199752222 interrupts
    474558163 CPU context switches
   1762163202 boot time
       284851 forks
