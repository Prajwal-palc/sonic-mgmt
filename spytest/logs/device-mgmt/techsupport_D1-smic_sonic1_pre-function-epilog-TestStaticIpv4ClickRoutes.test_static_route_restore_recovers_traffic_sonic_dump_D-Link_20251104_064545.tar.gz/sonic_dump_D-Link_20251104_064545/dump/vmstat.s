      3845328 K total memory
      2850848 K used memory
       292476 K active memory
      2531356 K inactive memory
       318000 K free memory
       130528 K buffer memory
       545952 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5861076 non-nice user cpu ticks
         7140 nice user cpu ticks
      2532808 system cpu ticks
     40061281 idle cpu ticks
        13556 IO-wait cpu ticks
            0 IRQ cpu ticks
        73865 softirq cpu ticks
        42099 stolen cpu ticks
      3392920 pages paged in
      8409612 pages paged out
            0 pages swapped in
            0 pages swapped out
    623728804 interrupts
   1474113146 CPU context switches
   1761727863 boot time
       834430 forks
