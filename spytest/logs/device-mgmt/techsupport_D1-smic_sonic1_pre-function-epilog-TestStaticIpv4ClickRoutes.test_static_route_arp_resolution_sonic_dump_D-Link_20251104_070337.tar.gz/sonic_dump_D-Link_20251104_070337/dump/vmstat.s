      3845328 K total memory
      2857816 K used memory
       282400 K active memory
      2520020 K inactive memory
       333668 K free memory
        90988 K buffer memory
       562856 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5879143 non-nice user cpu ticks
        20701 nice user cpu ticks
      2549622 system cpu ticks
     40116233 idle cpu ticks
        13593 IO-wait cpu ticks
            0 IRQ cpu ticks
        74138 softirq cpu ticks
        42159 stolen cpu ticks
      3492705 pages paged in
      8529956 pages paged out
            0 pages swapped in
            0 pages swapped out
    625262071 interrupts
   1478421799 CPU context switches
   1761727864 boot time
       862781 forks
