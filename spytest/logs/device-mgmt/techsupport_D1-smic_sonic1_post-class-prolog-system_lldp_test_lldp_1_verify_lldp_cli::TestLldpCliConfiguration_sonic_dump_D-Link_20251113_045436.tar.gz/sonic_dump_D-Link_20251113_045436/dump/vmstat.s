      3845316 K total memory
      3023272 K used memory
       208332 K active memory
      2340056 K inactive memory
       315364 K free memory
        67532 K buffer memory
       439148 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7556071 non-nice user cpu ticks
        36262 nice user cpu ticks
      3392022 system cpu ticks
     52719754 idle cpu ticks
        17529 IO-wait cpu ticks
            0 IRQ cpu ticks
        81784 softirq cpu ticks
        48753 stolen cpu ticks
      4940111 pages paged in
     11175428 pages paged out
            0 pages swapped in
            0 pages swapped out
    832481496 interrupts
   1967622839 CPU context switches
   1762341318 boot time
      1155440 forks
