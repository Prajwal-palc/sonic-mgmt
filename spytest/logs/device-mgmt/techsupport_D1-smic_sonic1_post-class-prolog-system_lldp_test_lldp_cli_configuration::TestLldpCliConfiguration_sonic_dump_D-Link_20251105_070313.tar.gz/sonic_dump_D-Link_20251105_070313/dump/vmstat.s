      3845316 K total memory
      2807820 K used memory
       316092 K active memory
      2558804 K inactive memory
       313624 K free memory
       173780 K buffer memory
       550092 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      1763145 non-nice user cpu ticks
         2650 nice user cpu ticks
       759468 system cpu ticks
     12987609 idle cpu ticks
         4390 IO-wait cpu ticks
            0 IRQ cpu ticks
        16899 softirq cpu ticks
        12294 stolen cpu ticks
      1793153 pages paged in
      2704668 pages paged out
            0 pages swapped in
            0 pages swapped out
    200098822 interrupts
    474736485 CPU context switches
   1762163197 boot time
       288089 forks
