      3845328 K total memory
      2858588 K used memory
       296348 K active memory
      2520808 K inactive memory
       318860 K free memory
       105740 K buffer memory
       562140 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5873981 non-nice user cpu ticks
        14680 nice user cpu ticks
      2543543 system cpu ticks
     40101439 idle cpu ticks
        13586 IO-wait cpu ticks
            0 IRQ cpu ticks
        74050 softirq cpu ticks
        42142 stolen cpu ticks
      3470506 pages paged in
      8480880 pages paged out
            0 pages swapped in
            0 pages swapped out
    624766939 interrupts
   1477010593 CPU context switches
   1761727864 boot time
       851054 forks
