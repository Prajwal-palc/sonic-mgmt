      3845316 K total memory
      2657824 K used memory
       363008 K active memory
      2595124 K inactive memory
       318236 K free memory
        72976 K buffer memory
       796280 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       790910 non-nice user cpu ticks
         1391 nice user cpu ticks
       131598 system cpu ticks
          562 idle cpu ticks
           20 IO-wait cpu ticks
            0 IRQ cpu ticks
          428 softirq cpu ticks
          112 stolen cpu ticks
      1006733 pages paged in
       360132 pages paged out
            0 pages swapped in
            0 pages swapped out
      5338286 interrupts
     13512327 CPU context switches
   1763451056 boot time
        43128 forks
