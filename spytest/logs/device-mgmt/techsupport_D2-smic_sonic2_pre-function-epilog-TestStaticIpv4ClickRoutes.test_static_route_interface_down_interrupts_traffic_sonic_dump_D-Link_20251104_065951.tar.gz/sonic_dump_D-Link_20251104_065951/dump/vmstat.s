      3845316 K total memory
      2806980 K used memory
       314068 K active memory
      2523316 K inactive memory
       331620 K free memory
       126760 K buffer memory
       579956 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5832395 non-nice user cpu ticks
        15533 nice user cpu ticks
      2556244 system cpu ticks
     40176347 idle cpu ticks
        13236 IO-wait cpu ticks
            0 IRQ cpu ticks
        75274 softirq cpu ticks
        42555 stolen cpu ticks
      3358669 pages paged in
      8499208 pages paged out
            0 pages swapped in
            0 pages swapped out
    622697331 interrupts
   1467368690 CPU context switches
   1761727777 boot time
       851555 forks
