      3845316 K total memory
      2589444 K used memory
       357204 K active memory
      2598300 K inactive memory
       318500 K free memory
        76708 K buffer memory
       860664 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        94884 non-nice user cpu ticks
         3468 nice user cpu ticks
        44616 system cpu ticks
       515865 idle cpu ticks
          454 IO-wait cpu ticks
            0 IRQ cpu ticks
          935 softirq cpu ticks
          490 stolen cpu ticks
       966518 pages paged in
       228460 pages paged out
            0 pages swapped in
            0 pages swapped out
      8635528 interrupts
     22395210 CPU context switches
   1762339296 boot time
        34607 forks
