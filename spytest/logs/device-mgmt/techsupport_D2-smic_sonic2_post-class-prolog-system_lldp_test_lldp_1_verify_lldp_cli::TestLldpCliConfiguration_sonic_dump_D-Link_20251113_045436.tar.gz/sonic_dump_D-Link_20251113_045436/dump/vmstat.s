      3845316 K total memory
      3057896 K used memory
       206728 K active memory
      2379776 K inactive memory
       304216 K free memory
        59208 K buffer memory
       423996 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      7515036 non-nice user cpu ticks
        33651 nice user cpu ticks
      3330134 system cpu ticks
     52940147 idle cpu ticks
        18571 IO-wait cpu ticks
            0 IRQ cpu ticks
        81034 softirq cpu ticks
        49661 stolen cpu ticks
      4646360 pages paged in
     11274252 pages paged out
            0 pages swapped in
            0 pages swapped out
    823821792 interrupts
   1947002383 CPU context switches
   1762339274 boot time
      1138110 forks
