      3845316 K total memory
      2597600 K used memory
       375524 K active memory
      2546844 K inactive memory
       324692 K free memory
        51352 K buffer memory
       871672 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        73112 non-nice user cpu ticks
         8654 nice user cpu ticks
        37940 system cpu ticks
       344645 idle cpu ticks
          337 IO-wait cpu ticks
            0 IRQ cpu ticks
          659 softirq cpu ticks
          335 stolen cpu ticks
       955992 pages paged in
       252440 pages paged out
            0 pages swapped in
            0 pages swapped out
      6146951 interrupts
     17236113 CPU context switches
   1763011705 boot time
        45686 forks
