      3845328 K total memory
      2858056 K used memory
       295484 K active memory
      2518608 K inactive memory
       325800 K free memory
       108980 K buffer memory
       552492 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      5865730 non-nice user cpu ticks
        11143 nice user cpu ticks
      2537463 system cpu ticks
     40069921 idle cpu ticks
        13573 IO-wait cpu ticks
            0 IRQ cpu ticks
        73935 softirq cpu ticks
        42109 stolen cpu ticks
      3444812 pages paged in
      8443476 pages paged out
            0 pages swapped in
            0 pages swapped out
    624062374 interrupts
   1475126223 CPU context switches
   1761727863 boot time
       842672 forks
