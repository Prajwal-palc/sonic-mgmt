      3845316 K total memory
      2899676 K used memory
       314328 K active memory
      2569636 K inactive memory
       237044 K free memory
       120608 K buffer memory
       587988 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6996567 non-nice user cpu ticks
         5557 nice user cpu ticks
      1196155 system cpu ticks
          562 idle cpu ticks
           20 IO-wait cpu ticks
            0 IRQ cpu ticks
         4068 softirq cpu ticks
         1298 stolen cpu ticks
      1593840 pages paged in
      1310112 pages paged out
            0 pages swapped in
            0 pages swapped out
     46340624 interrupts
    103055281 CPU context switches
   1763451054 boot time
       167230 forks
