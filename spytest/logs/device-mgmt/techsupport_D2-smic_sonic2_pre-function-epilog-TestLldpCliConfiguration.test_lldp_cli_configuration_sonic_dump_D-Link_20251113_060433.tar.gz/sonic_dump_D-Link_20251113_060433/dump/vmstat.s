      3845316 K total memory
      2540824 K used memory
       319764 K active memory
      2620244 K inactive memory
       331576 K free memory
        39764 K buffer memory
       933152 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        36954 non-nice user cpu ticks
         1327 nice user cpu ticks
        17601 system cpu ticks
       154786 idle cpu ticks
          222 IO-wait cpu ticks
            0 IRQ cpu ticks
          299 softirq cpu ticks
          151 stolen cpu ticks
       813691 pages paged in
       125144 pages paged out
            0 pages swapped in
            0 pages swapped out
      2730709 interrupts
      8275291 CPU context switches
   1763011705 boot time
        21495 forks
