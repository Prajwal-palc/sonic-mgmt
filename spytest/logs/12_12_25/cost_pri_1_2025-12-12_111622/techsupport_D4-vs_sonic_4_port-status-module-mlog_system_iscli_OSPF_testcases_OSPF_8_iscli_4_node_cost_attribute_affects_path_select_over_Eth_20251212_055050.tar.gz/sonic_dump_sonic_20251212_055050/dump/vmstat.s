      3840620 K total memory
      2562420 K used memory
       375548 K active memory
      2585660 K inactive memory
       377116 K free memory
        37484 K buffer memory
      1136256 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        37042 non-nice user cpu ticks
         2026 nice user cpu ticks
        14961 system cpu ticks
        77285 idle cpu ticks
           51 IO-wait cpu ticks
            0 IRQ cpu ticks
          117 softirq cpu ticks
           26 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       868214 K paged in
       270052 K paged out
            0 pages swapped in
            0 pages swapped out
       756838 interrupts
      3093688 CPU context switches
   1765517371 boot time
        20013 forks
