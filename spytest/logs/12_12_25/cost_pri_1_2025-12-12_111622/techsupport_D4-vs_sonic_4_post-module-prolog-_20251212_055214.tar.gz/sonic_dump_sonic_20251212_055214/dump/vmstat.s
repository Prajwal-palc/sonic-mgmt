      3840620 K total memory
      2606216 K used memory
       390936 K active memory
      2605296 K inactive memory
       313496 K free memory
        39880 K buffer memory
      1157524 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        38836 non-nice user cpu ticks
         4544 nice user cpu ticks
        17341 system cpu ticks
        78227 idle cpu ticks
           52 IO-wait cpu ticks
            0 IRQ cpu ticks
          154 softirq cpu ticks
           28 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       880663 K paged in
       294232 K paged out
            0 pages swapped in
            0 pages swapped out
       846292 interrupts
      3470169 CPU context switches
   1765517371 boot time
        26097 forks
