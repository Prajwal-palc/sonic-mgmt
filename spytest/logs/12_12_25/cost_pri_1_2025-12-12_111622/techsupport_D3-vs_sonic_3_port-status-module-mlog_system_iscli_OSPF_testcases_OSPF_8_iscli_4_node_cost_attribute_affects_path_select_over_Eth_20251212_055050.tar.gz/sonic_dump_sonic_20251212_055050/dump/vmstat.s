      3840620 K total memory
      2574264 K used memory
       382512 K active memory
      2583520 K inactive memory
       363668 K free memory
        37756 K buffer memory
      1138064 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        39190 non-nice user cpu ticks
         1897 nice user cpu ticks
        15437 system cpu ticks
        75013 idle cpu ticks
           45 IO-wait cpu ticks
            0 IRQ cpu ticks
          109 softirq cpu ticks
           19 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       867756 K paged in
       273080 K paged out
            0 pages swapped in
            0 pages swapped out
       757616 interrupts
      3085969 CPU context switches
   1765517368 boot time
        20015 forks
