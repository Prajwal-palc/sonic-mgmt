      3840620 K total memory
      2609976 K used memory
       369296 K active memory
      2619628 K inactive memory
       329000 K free memory
        37312 K buffer memory
      1136948 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        36279 non-nice user cpu ticks
         1953 nice user cpu ticks
        13991 system cpu ticks
        79360 idle cpu ticks
           80 IO-wait cpu ticks
            0 IRQ cpu ticks
          110 softirq cpu ticks
           15 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       871609 K paged in
       264900 K paged out
            0 pages swapped in
            0 pages swapped out
       718039 interrupts
      2978151 CPU context switches
   1765517365 boot time
        19159 forks
