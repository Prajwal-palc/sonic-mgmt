      3840620 K total memory
      2575276 K used memory
       397604 K active memory
      2585596 K inactive memory
       342804 K free memory
        40160 K buffer memory
      1159364 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        40992 non-nice user cpu ticks
         4375 nice user cpu ticks
        17662 system cpu ticks
        76480 idle cpu ticks
           51 IO-wait cpu ticks
            0 IRQ cpu ticks
          136 softirq cpu ticks
           20 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       880412 K paged in
       297736 K paged out
            0 pages swapped in
            0 pages swapped out
       847645 interrupts
      3474610 CPU context switches
   1765517368 boot time
        26083 forks
