      3840620 K total memory
      2604384 K used memory
       384424 K active memory
      2596440 K inactive memory
       314740 K free memory
        39676 K buffer memory
      1158316 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        37956 non-nice user cpu ticks
         4441 nice user cpu ticks
        16207 system cpu ticks
        80873 idle cpu ticks
           84 IO-wait cpu ticks
            0 IRQ cpu ticks
          143 softirq cpu ticks
           16 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       883917 K paged in
       287500 K paged out
            0 pages swapped in
            0 pages swapped out
       806126 interrupts
      3354855 CPU context switches
   1765517365 boot time
        25202 forks
