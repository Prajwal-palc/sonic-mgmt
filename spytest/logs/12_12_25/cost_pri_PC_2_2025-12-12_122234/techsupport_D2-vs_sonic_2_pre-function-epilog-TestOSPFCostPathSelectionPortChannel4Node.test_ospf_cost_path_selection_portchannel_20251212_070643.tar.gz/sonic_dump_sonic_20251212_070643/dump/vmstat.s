      3840620 K total memory
      2443712 K used memory
       357144 K active memory
      2451684 K inactive memory
       553012 K free memory
        34924 K buffer memory
      1076864 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        25633 non-nice user cpu ticks
         1653 nice user cpu ticks
        10561 system cpu ticks
        75241 idle cpu ticks
          387 IO-wait cpu ticks
            0 IRQ cpu ticks
          110 softirq cpu ticks
           13 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       891488 K paged in
        57529 K paged out
            0 pages swapped in
            0 pages swapped out
       649661 interrupts
      2578805 CPU context switches
   1765522097 boot time
        13778 forks
