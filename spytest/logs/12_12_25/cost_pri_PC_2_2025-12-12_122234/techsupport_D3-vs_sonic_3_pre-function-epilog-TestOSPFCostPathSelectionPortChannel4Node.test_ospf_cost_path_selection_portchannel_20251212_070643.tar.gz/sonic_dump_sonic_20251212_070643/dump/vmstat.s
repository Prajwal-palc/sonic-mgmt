      3840620 K total memory
      2473236 K used memory
       359552 K active memory
      2455740 K inactive memory
       520712 K free memory
        34456 K buffer memory
      1079388 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        23460 non-nice user cpu ticks
         1709 nice user cpu ticks
        10166 system cpu ticks
        71372 idle cpu ticks
          357 IO-wait cpu ticks
            0 IRQ cpu ticks
           80 softirq cpu ticks
           12 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       895797 K paged in
        56937 K paged out
            0 pages swapped in
            0 pages swapped out
       602744 interrupts
      2360022 CPU context switches
   1765522162 boot time
        12694 forks
