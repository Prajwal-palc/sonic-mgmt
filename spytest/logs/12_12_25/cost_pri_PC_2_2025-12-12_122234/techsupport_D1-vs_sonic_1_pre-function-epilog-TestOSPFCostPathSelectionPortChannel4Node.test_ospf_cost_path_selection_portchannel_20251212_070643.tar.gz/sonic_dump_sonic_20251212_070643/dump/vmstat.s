      3840620 K total memory
      2491504 K used memory
       359312 K active memory
      2473304 K inactive memory
       499508 K free memory
        34928 K buffer memory
      1082392 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        24440 non-nice user cpu ticks
         1780 nice user cpu ticks
        10454 system cpu ticks
        77493 idle cpu ticks
          349 IO-wait cpu ticks
            0 IRQ cpu ticks
           92 softirq cpu ticks
           11 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       891397 K paged in
        61573 K paged out
            0 pages swapped in
            0 pages swapped out
       665054 interrupts
      2589414 CPU context switches
   1765522092 boot time
        13409 forks
