      3840620 K total memory
      2483308 K used memory
       356432 K active memory
      2460108 K inactive memory
       514412 K free memory
        34912 K buffer memory
      1075672 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        25623 non-nice user cpu ticks
         1656 nice user cpu ticks
        10929 system cpu ticks
        72951 idle cpu ticks
          171 IO-wait cpu ticks
            0 IRQ cpu ticks
           97 softirq cpu ticks
           14 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       893423 K paged in
        57777 K paged out
            0 pages swapped in
            0 pages swapped out
       642406 interrupts
      2524463 CPU context switches
   1765522121 boot time
        13653 forks
