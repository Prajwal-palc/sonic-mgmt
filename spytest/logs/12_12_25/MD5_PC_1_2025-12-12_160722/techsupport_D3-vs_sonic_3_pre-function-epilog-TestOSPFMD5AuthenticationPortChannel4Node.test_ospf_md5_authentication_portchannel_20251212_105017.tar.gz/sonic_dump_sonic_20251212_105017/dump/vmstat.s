      3840620 K total memory
      2600472 K used memory
       362300 K active memory
      2580596 K inactive memory
       391284 K free memory
        37464 K buffer memory
      1079692 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        45261 non-nice user cpu ticks
         1671 nice user cpu ticks
        16504 system cpu ticks
       198678 idle cpu ticks
          101 IO-wait cpu ticks
            0 IRQ cpu ticks
          168 softirq cpu ticks
           29 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       914123 K paged in
        70821 K paged out
            0 pages swapped in
            0 pages swapped out
      1299384 interrupts
      4770846 CPU context switches
   1765534001 boot time
        16371 forks
