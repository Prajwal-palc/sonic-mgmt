      3840620 K total memory
      2587724 K used memory
       364664 K active memory
      2568172 K inactive memory
       398540 K free memory
        38000 K buffer memory
      1084832 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        48726 non-nice user cpu ticks
         1653 nice user cpu ticks
        17362 system cpu ticks
       196468 idle cpu ticks
          100 IO-wait cpu ticks
            0 IRQ cpu ticks
          181 softirq cpu ticks
           28 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       917098 K paged in
        73633 K paged out
            0 pages swapped in
            0 pages swapped out
      1328444 interrupts
      4974337 CPU context switches
   1765533981 boot time
        18000 forks
