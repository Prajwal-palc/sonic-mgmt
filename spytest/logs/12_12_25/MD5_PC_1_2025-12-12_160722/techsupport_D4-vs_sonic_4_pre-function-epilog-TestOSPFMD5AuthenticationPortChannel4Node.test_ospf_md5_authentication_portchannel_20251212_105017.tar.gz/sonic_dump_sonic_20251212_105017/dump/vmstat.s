      3840620 K total memory
      2591704 K used memory
       363312 K active memory
      2567648 K inactive memory
       401808 K free memory
        37720 K buffer memory
      1081864 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        49750 non-nice user cpu ticks
         1775 nice user cpu ticks
        18091 system cpu ticks
       193404 idle cpu ticks
          167 IO-wait cpu ticks
            0 IRQ cpu ticks
          193 softirq cpu ticks
           31 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       922356 K paged in
        75429 K paged out
            0 pages swapped in
            0 pages swapped out
      1360998 interrupts
      4994172 CPU context switches
   1765533995 boot time
        17983 forks
