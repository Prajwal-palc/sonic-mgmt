      3840620 K total memory
      2607372 K used memory
       363364 K active memory
      2581572 K inactive memory
       377328 K free memory
        38784 K buffer memory
      1084924 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        46246 non-nice user cpu ticks
         1733 nice user cpu ticks
        16832 system cpu ticks
       200831 idle cpu ticks
          110 IO-wait cpu ticks
            0 IRQ cpu ticks
          195 softirq cpu ticks
           29 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       921966 K paged in
        75097 K paged out
            0 pages swapped in
            0 pages swapped out
      1395507 interrupts
      5049146 CPU context switches
   1765533966 boot time
        16610 forks
