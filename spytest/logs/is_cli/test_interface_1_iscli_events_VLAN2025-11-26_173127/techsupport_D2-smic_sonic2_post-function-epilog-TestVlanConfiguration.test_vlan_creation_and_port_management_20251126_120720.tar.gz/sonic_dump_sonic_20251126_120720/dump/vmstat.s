      3840620 K total memory
      2572980 K used memory
       462304 K active memory
      2399136 K inactive memory
       464372 K free memory
       112188 K buffer memory
       982312 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       369068 non-nice user cpu ticks
        42172 nice user cpu ticks
       138455 system cpu ticks
      1911731 idle cpu ticks
          898 IO-wait cpu ticks
            0 IRQ cpu ticks
         1587 softirq cpu ticks
          302 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1253730 K paged in
       970520 K paged out
            0 pages swapped in
            0 pages swapped out
     11985992 interrupts
     46324543 CPU context switches
   1764133843 boot time
       172063 forks
