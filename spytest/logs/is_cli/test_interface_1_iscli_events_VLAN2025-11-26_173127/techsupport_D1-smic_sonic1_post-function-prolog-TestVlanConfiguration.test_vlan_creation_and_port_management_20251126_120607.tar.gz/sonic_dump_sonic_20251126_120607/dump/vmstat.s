      3840620 K total memory
      2864688 K used memory
       380844 K active memory
      2547176 K inactive memory
       409592 K free memory
       104588 K buffer memory
       750468 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       388051 non-nice user cpu ticks
        39550 nice user cpu ticks
       137299 system cpu ticks
      1895560 idle cpu ticks
          933 IO-wait cpu ticks
            0 IRQ cpu ticks
         1610 softirq cpu ticks
          276 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1428788 K paged in
       888732 K paged out
            0 pages swapped in
            0 pages swapped out
     12101898 interrupts
     43786548 CPU context switches
   1764133838 boot time
       180093 forks
