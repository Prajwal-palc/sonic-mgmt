      3840620 K total memory
      2574612 K used memory
       486996 K active memory
      2485468 K inactive memory
       368164 K free memory
       113208 K buffer memory
      1075860 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       367432 non-nice user cpu ticks
        39905 nice user cpu ticks
       136418 system cpu ticks
      1909310 idle cpu ticks
          895 IO-wait cpu ticks
            0 IRQ cpu ticks
         1554 softirq cpu ticks
          300 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1216867 K paged in
       947176 K paged out
            0 pages swapped in
            0 pages swapped out
     11900127 interrupts
     45930643 CPU context switches
   1764133843 boot time
       165834 forks
