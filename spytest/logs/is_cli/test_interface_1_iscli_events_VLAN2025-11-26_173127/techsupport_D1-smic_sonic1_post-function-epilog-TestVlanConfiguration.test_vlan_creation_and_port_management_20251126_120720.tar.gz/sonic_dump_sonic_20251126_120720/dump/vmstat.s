      3840620 K total memory
      2896900 K used memory
       394712 K active memory
      2538092 K inactive memory
       370312 K free memory
       105004 K buffer memory
       758796 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       389590 non-nice user cpu ticks
        41866 nice user cpu ticks
       139443 system cpu ticks
      1896992 idle cpu ticks
          936 IO-wait cpu ticks
            0 IRQ cpu ticks
         1641 softirq cpu ticks
          276 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1444726 K paged in
       905548 K paged out
            0 pages swapped in
            0 pages swapped out
     12184216 interrupts
     44151669 CPU context switches
   1764133838 boot time
       186372 forks
