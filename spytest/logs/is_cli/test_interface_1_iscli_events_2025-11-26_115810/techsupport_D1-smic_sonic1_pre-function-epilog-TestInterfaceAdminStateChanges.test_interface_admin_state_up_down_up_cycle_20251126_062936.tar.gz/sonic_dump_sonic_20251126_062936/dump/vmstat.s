      3840620 K total memory
      2524384 K used memory
       412476 K active memory
      2513784 K inactive memory
       389160 K free memory
        44552 K buffer memory
      1156096 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        81596 non-nice user cpu ticks
         1670 nice user cpu ticks
        25214 system cpu ticks
       362726 idle cpu ticks
          122 IO-wait cpu ticks
            0 IRQ cpu ticks
          212 softirq cpu ticks
           54 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       890406 K paged in
       302384 K paged out
            0 pages swapped in
            0 pages swapped out
      2218500 interrupts
      8080509 CPU context switches
   1764133839 boot time
        26000 forks
