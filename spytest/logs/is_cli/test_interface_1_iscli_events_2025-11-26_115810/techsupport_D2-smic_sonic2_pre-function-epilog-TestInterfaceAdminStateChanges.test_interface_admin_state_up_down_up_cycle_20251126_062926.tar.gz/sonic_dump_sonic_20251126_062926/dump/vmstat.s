      3840620 K total memory
      2554404 K used memory
       417832 K active memory
      2552692 K inactive memory
       343128 K free memory
        49796 K buffer memory
      1167288 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        85393 non-nice user cpu ticks
         1668 nice user cpu ticks
        27115 system cpu ticks
       354871 idle cpu ticks
          183 IO-wait cpu ticks
            0 IRQ cpu ticks
          217 softirq cpu ticks
           55 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       894900 K paged in
       319684 K paged out
            0 pages swapped in
            0 pages swapped out
      2246775 interrupts
      8655612 CPU context switches
   1764133845 boot time
        25622 forks
