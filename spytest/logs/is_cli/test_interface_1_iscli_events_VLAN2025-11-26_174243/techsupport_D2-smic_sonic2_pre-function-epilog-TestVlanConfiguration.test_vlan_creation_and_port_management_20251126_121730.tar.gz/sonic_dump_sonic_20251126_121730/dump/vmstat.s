      3840620 K total memory
      2615916 K used memory
       478664 K active memory
      2405272 K inactive memory
       413412 K free memory
       114048 K buffer memory
       989864 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       377861 non-nice user cpu ticks
        44477 nice user cpu ticks
       142599 system cpu ticks
      1956260 idle cpu ticks
          919 IO-wait cpu ticks
            0 IRQ cpu ticks
         1642 softirq cpu ticks
          310 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1275197 K paged in
       996496 K paged out
            0 pages swapped in
            0 pages swapped out
     12306053 interrupts
     47577543 CPU context switches
   1764133844 boot time
       179200 forks
