      3840620 K total memory
      2945256 K used memory
       406240 K active memory
      2555476 K inactive memory
       319200 K free memory
       107376 K buffer memory
       759456 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       398483 non-nice user cpu ticks
        44161 nice user cpu ticks
       143788 system cpu ticks
      1942006 idle cpu ticks
          960 IO-wait cpu ticks
            0 IRQ cpu ticks
         1699 softirq cpu ticks
          283 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1456985 K paged in
       933788 K paged out
            0 pages swapped in
            0 pages swapped out
     12513496 interrupts
     45360884 CPU context switches
   1764133839 boot time
       193720 forks
