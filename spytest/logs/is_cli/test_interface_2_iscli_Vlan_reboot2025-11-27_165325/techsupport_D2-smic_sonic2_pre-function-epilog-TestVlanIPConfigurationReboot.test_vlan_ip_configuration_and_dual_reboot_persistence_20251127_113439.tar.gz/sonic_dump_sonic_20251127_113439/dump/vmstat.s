      3840620 K total memory
      2551152 K used memory
       384372 K active memory
      2533908 K inactive memory
       404892 K free memory
        55048 K buffer memory
      1100180 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       200074 non-nice user cpu ticks
         1714 nice user cpu ticks
        56717 system cpu ticks
      1380349 idle cpu ticks
          366 IO-wait cpu ticks
            0 IRQ cpu ticks
          564 softirq cpu ticks
          173 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       969695 K paged in
       131893 K paged out
            0 pages swapped in
            0 pages swapped out
      7060137 interrupts
     24637619 CPU context switches
   1764226694 boot time
        35024 forks
