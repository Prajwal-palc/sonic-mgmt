      3840620 K total memory
      2373596 K used memory
       333828 K active memory
      2363024 K inactive memory
       645148 K free memory
        32296 K buffer memory
      1051204 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        13376 non-nice user cpu ticks
         1647 nice user cpu ticks
         6268 system cpu ticks
        37100 idle cpu ticks
           60 IO-wait cpu ticks
            0 IRQ cpu ticks
           33 softirq cpu ticks
            7 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       881039 K paged in
        46725 K paged out
            0 pages swapped in
            0 pages swapped out
       356172 interrupts
      1457915 CPU context switches
   1764242745 boot time
        10738 forks
