      3840620 K total memory
      2554240 K used memory
       445484 K active memory
      2546660 K inactive memory
       330108 K free memory
        58008 K buffer memory
      1177492 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       109383 non-nice user cpu ticks
         6241 nice user cpu ticks
        37453 system cpu ticks
       472939 idle cpu ticks
          238 IO-wait cpu ticks
            0 IRQ cpu ticks
          350 softirq cpu ticks
           72 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       930532 K paged in
       385448 K paged out
            0 pages swapped in
            0 pages swapped out
      3042249 interrupts
     11805625 CPU context switches
   1764133844 boot time
        41562 forks
