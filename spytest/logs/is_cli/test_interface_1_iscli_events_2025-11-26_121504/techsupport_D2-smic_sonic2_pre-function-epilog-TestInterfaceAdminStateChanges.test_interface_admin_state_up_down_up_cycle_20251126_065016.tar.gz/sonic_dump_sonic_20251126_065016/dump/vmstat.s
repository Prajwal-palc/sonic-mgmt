      3840620 K total memory
      2543184 K used memory
       439916 K active memory
      2550936 K inactive memory
       340120 K free memory
        56780 K buffer memory
      1179592 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       104342 non-nice user cpu ticks
         3994 nice user cpu ticks
        34421 system cpu ticks
       449084 idle cpu ticks
          227 IO-wait cpu ticks
            0 IRQ cpu ticks
          307 softirq cpu ticks
           68 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       920999 K paged in
       367652 K paged out
            0 pages swapped in
            0 pages swapped out
      2844236 interrupts
     10998715 CPU context switches
   1764133844 boot time
        35101 forks
