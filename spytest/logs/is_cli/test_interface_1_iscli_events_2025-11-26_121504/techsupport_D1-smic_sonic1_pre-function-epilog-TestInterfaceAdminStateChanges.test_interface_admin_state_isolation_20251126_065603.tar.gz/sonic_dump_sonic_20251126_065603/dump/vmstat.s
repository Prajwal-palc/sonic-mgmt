      3840620 K total memory
      2659628 K used memory
       443012 K active memory
      2571576 K inactive memory
       286080 K free memory
        51680 K buffer memory
      1120212 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       109405 non-nice user cpu ticks
         6206 nice user cpu ticks
        36226 system cpu ticks
       475549 idle cpu ticks
          201 IO-wait cpu ticks
            0 IRQ cpu ticks
          366 softirq cpu ticks
           73 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       957001 K paged in
       366624 K paged out
            0 pages swapped in
            0 pages swapped out
      3054379 interrupts
     11170337 CPU context switches
   1764133839 boot time
        43723 forks
