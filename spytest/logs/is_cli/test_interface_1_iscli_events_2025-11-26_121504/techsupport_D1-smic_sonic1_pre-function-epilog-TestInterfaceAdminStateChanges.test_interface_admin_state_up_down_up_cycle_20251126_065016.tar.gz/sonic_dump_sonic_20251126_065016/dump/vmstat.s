      3840620 K total memory
      2620820 K used memory
       436732 K active memory
      2592780 K inactive memory
       306584 K free memory
        51316 K buffer memory
      1138752 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       103557 non-nice user cpu ticks
         3921 nice user cpu ticks
        33023 system cpu ticks
       452677 idle cpu ticks
          165 IO-wait cpu ticks
            0 IRQ cpu ticks
          327 softirq cpu ticks
           69 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       930072 K paged in
       346384 K paged out
            0 pages swapped in
            0 pages swapped out
      2846137 interrupts
     10373197 CPU context switches
   1764133839 boot time
        36841 forks
