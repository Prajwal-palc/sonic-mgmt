      3840620 K total memory
      2595716 K used memory
       446468 K active memory
      2529896 K inactive memory
       311008 K free memory
        66756 K buffer memory
      1149248 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       147422 non-nice user cpu ticks
        20069 nice user cpu ticks
        58258 system cpu ticks
       646079 idle cpu ticks
          344 IO-wait cpu ticks
            0 IRQ cpu ticks
          653 softirq cpu ticks
          107 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1023898 K paged in
       528064 K paged out
            0 pages swapped in
            0 pages swapped out
      4443757 interrupts
     17404035 CPU context switches
   1764133844 boot time
        81850 forks
