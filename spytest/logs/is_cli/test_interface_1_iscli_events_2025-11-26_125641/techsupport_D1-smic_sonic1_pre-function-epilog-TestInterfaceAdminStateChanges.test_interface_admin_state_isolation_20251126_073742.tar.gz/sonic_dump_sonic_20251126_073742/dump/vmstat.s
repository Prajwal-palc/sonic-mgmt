      3840620 K total memory
      2663448 K used memory
       446516 K active memory
      2553772 K inactive memory
       300724 K free memory
        59828 K buffer memory
      1096528 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       154379 non-nice user cpu ticks
        19542 nice user cpu ticks
        57509 system cpu ticks
       642442 idle cpu ticks
          326 IO-wait cpu ticks
            0 IRQ cpu ticks
          660 softirq cpu ticks
          101 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1052281 K paged in
       501716 K paged out
            0 pages swapped in
            0 pages swapped out
      4488466 interrupts
     16650758 CPU context switches
   1764133839 boot time
        87240 forks
