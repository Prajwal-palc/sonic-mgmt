      3840620 K total memory
      2579952 K used memory
       444908 K active memory
      2529716 K inactive memory
       331596 K free memory
        65504 K buffer memory
      1145524 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       142472 non-nice user cpu ticks
        17882 nice user cpu ticks
        55363 system cpu ticks
       622191 idle cpu ticks
          336 IO-wait cpu ticks
            0 IRQ cpu ticks
          608 softirq cpu ticks
          102 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1016456 K paged in
       505140 K paged out
            0 pages swapped in
            0 pages swapped out
      4248541 interrupts
     16611929 CPU context switches
   1764133844 boot time
        75391 forks
