      3840620 K total memory
      2667128 K used memory
       443944 K active memory
      2567436 K inactive memory
       284912 K free memory
        58948 K buffer memory
      1111064 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       148309 non-nice user cpu ticks
        17333 nice user cpu ticks
        54372 system cpu ticks
       619697 idle cpu ticks
          318 IO-wait cpu ticks
            0 IRQ cpu ticks
          619 softirq cpu ticks
           97 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1041699 K paged in
       480016 K paged out
            0 pages swapped in
            0 pages swapped out
      4280393 interrupts
     15858813 CPU context switches
   1764133839 boot time
        80369 forks
