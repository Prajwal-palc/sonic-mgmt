      3840620 K total memory
      2648408 K used memory
       443064 K active memory
      2567376 K inactive memory
       301356 K free memory
        53500 K buffer memory
      1114532 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       118211 non-nice user cpu ticks
         8483 nice user cpu ticks
        40245 system cpu ticks
       506729 idle cpu ticks
          225 IO-wait cpu ticks
            0 IRQ cpu ticks
          421 softirq cpu ticks
           77 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       985049 K paged in
       391032 K paged out
            0 pages swapped in
            0 pages swapped out
      3321988 interrupts
     12182178 CPU context switches
   1764133839 boot time
        51334 forks
