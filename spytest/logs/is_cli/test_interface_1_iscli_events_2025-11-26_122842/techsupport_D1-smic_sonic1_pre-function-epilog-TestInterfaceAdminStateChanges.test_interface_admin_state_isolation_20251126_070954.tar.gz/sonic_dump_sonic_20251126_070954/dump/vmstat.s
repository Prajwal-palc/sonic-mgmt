      3840620 K total memory
      2628084 K used memory
       438704 K active memory
      2567180 K inactive memory
       326644 K free memory
        54200 K buffer memory
      1109036 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       124376 non-nice user cpu ticks
        10800 nice user cpu ticks
        43441 system cpu ticks
       530858 idle cpu ticks
          254 IO-wait cpu ticks
            0 IRQ cpu ticks
          477 softirq cpu ticks
           81 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1003517 K paged in
       410984 K paged out
            0 pages swapped in
            0 pages swapped out
      3531433 interrupts
     12989963 CPU context switches
   1764133839 boot time
        58193 forks
