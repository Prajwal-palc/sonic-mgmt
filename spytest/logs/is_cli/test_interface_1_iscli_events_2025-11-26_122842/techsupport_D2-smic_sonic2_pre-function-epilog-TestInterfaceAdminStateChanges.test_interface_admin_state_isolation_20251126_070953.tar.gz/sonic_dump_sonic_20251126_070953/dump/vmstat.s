      3840620 K total memory
      2584292 K used memory
       448924 K active memory
      2548688 K inactive memory
       299348 K free memory
        61232 K buffer memory
      1175948 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       122265 non-nice user cpu ticks
        11226 nice user cpu ticks
        44820 system cpu ticks
       529894 idle cpu ticks
          274 IO-wait cpu ticks
            0 IRQ cpu ticks
          457 softirq cpu ticks
           84 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       955884 K paged in
       431548 K paged out
            0 pages swapped in
            0 pages swapped out
      3525834 interrupts
     13712152 CPU context switches
   1764133844 boot time
        54918 forks
