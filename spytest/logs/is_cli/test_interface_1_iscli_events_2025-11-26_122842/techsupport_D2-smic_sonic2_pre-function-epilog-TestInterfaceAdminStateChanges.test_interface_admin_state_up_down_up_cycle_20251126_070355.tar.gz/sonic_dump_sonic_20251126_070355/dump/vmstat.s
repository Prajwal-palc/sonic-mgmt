      3840620 K total memory
      2607088 K used memory
       445504 K active memory
      2548920 K inactive memory
       281524 K free memory
        59936 K buffer memory
      1172180 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       116888 non-nice user cpu ticks
         8751 nice user cpu ticks
        41483 system cpu ticks
       506166 idle cpu ticks
          251 IO-wait cpu ticks
            0 IRQ cpu ticks
          407 softirq cpu ticks
           79 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       946414 K paged in
       412112 K paged out
            0 pages swapped in
            0 pages swapped out
      3311456 interrupts
     12870757 CPU context switches
   1764133844 boot time
        48563 forks
