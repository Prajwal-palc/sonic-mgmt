      3840620 K total memory
      2610116 K used memory
       449700 K active memory
      2535172 K inactive memory
       295548 K free memory
        71328 K buffer memory
      1147464 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       167128 non-nice user cpu ticks
        24477 nice user cpu ticks
        67048 system cpu ticks
       750051 idle cpu ticks
          390 IO-wait cpu ticks
            0 IRQ cpu ticks
          766 softirq cpu ticks
          124 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1044574 K paged in
       591116 K paged out
            0 pages swapped in
            0 pages swapped out
      5141923 interrupts
     20165768 CPU context switches
   1764133844 boot time
        96362 forks
