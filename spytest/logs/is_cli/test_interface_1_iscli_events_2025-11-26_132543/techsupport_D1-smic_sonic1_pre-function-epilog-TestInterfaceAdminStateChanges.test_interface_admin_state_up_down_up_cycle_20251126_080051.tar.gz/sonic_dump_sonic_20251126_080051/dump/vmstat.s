      3840620 K total memory
      2728440 K used memory
       444968 K active memory
      2580132 K inactive memory
       265956 K free memory
        64616 K buffer memory
      1063080 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       177379 non-nice user cpu ticks
        24074 nice user cpu ticks
        66882 system cpu ticks
       742657 idle cpu ticks
          363 IO-wait cpu ticks
            0 IRQ cpu ticks
          773 softirq cpu ticks
          116 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1091112 K paged in
       556352 K paged out
            0 pages swapped in
            0 pages swapped out
      5215378 interrupts
     19333570 CPU context switches
   1764133839 boot time
       103236 forks
