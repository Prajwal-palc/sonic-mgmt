      3840620 K total memory
      2766600 K used memory
       464084 K active memory
      2566468 K inactive memory
       298064 K free memory
        67544 K buffer memory
       991004 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       197206 non-nice user cpu ticks
        28568 nice user cpu ticks
        75377 system cpu ticks
       808413 idle cpu ticks
          404 IO-wait cpu ticks
            0 IRQ cpu ticks
          879 softirq cpu ticks
          127 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1150736 K paged in
       608912 K paged out
            0 pages swapped in
            0 pages swapped out
      5795978 interrupts
     21530448 CPU context switches
   1764133839 boot time
       119608 forks
