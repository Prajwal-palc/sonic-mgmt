      3840620 K total memory
      2609676 K used memory
       453620 K active memory
      2538696 K inactive memory
       290364 K free memory
        73924 K buffer memory
      1151284 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       177814 non-nice user cpu ticks
        26759 nice user cpu ticks
        71979 system cpu ticks
       796439 idle cpu ticks
          415 IO-wait cpu ticks
            0 IRQ cpu ticks
          831 softirq cpu ticks
          133 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1059373 K paged in
       622508 K paged out
            0 pages swapped in
            0 pages swapped out
      5490704 interrupts
     21544873 CPU context switches
   1764133844 boot time
       104228 forks
