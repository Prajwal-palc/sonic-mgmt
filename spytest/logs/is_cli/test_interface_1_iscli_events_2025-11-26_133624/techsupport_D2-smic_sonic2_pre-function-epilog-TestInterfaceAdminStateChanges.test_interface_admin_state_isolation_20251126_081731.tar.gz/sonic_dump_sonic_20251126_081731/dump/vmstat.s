      3840620 K total memory
      2659068 K used memory
       452172 K active memory
      2618200 K inactive memory
       238572 K free memory
        74940 K buffer memory
      1152884 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       182705 non-nice user cpu ticks
        29071 nice user cpu ticks
        74886 system cpu ticks
       820330 idle cpu ticks
          425 IO-wait cpu ticks
            0 IRQ cpu ticks
          874 softirq cpu ticks
          138 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1067328 K paged in
       644928 K paged out
            0 pages swapped in
            0 pages swapped out
      5689126 interrupts
     22347039 CPU context switches
   1764133844 boot time
       110610 forks
