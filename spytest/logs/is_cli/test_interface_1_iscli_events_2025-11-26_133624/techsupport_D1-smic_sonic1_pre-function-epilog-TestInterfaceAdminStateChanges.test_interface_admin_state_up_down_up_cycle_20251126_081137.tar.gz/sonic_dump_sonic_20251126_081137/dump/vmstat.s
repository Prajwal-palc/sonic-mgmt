      3840620 K total memory
      2762916 K used memory
       452384 K active memory
      2582424 K inactive memory
       292252 K free memory
        66576 K buffer memory
      1001384 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       191054 non-nice user cpu ticks
        26309 nice user cpu ticks
        72217 system cpu ticks
       784923 idle cpu ticks
          387 IO-wait cpu ticks
            0 IRQ cpu ticks
          845 softirq cpu ticks
          124 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1136658 K paged in
       586360 K paged out
            0 pages swapped in
            0 pages swapped out
      5590072 interrupts
     20733693 CPU context switches
   1764133839 boot time
       112628 forks
