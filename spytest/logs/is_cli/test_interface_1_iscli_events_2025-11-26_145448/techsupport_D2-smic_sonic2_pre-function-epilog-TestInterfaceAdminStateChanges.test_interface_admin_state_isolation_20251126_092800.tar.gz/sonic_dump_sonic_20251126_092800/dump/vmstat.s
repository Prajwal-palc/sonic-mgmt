      3840620 K total memory
      2603372 K used memory
       470232 K active memory
      2492444 K inactive memory
       359764 K free memory
        85348 K buffer memory
      1077084 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       238616 non-nice user cpu ticks
        33559 nice user cpu ticks
        94218 system cpu ticks
      1156786 idle cpu ticks
          548 IO-wait cpu ticks
            0 IRQ cpu ticks
         1081 softirq cpu ticks
          189 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1131638 K paged in
       737088 K paged out
            0 pages swapped in
            0 pages swapped out
      7636347 interrupts
     29730369 CPU context switches
   1764133843 boot time
       129490 forks
