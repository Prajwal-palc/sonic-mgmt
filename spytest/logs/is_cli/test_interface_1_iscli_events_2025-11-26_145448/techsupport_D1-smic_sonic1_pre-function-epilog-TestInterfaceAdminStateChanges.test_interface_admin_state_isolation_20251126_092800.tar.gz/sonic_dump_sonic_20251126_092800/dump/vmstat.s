      3840620 K total memory
      2793576 K used memory
       460192 K active memory
      2546164 K inactive memory
       297396 K free memory
        79672 K buffer memory
       954308 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       253672 non-nice user cpu ticks
        33112 nice user cpu ticks
        94619 system cpu ticks
      1144844 idle cpu ticks
          541 IO-wait cpu ticks
            0 IRQ cpu ticks
         1100 softirq cpu ticks
          172 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1207577 K paged in
       694448 K paged out
            0 pages swapped in
            0 pages swapped out
      7750090 interrupts
     28437920 CPU context switches
   1764133838 boot time
       139527 forks
