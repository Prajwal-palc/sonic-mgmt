      3840620 K total memory
      2602752 K used memory
       463936 K active memory
      2540376 K inactive memory
       317264 K free memory
        85316 K buffer memory
      1120860 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       236452 non-nice user cpu ticks
        31346 nice user cpu ticks
        91977 system cpu ticks
      1152042 idle cpu ticks
          546 IO-wait cpu ticks
            0 IRQ cpu ticks
         1044 softirq cpu ticks
          188 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1101832 K paged in
       718084 K paged out
            0 pages swapped in
            0 pages swapped out
      7536639 interrupts
     29289128 CPU context switches
   1764133843 boot time
       123338 forks
