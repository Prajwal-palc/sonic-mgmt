      3840620 K total memory
      2760124 K used memory
       467052 K active memory
      2553420 K inactive memory
       316928 K free memory
        79760 K buffer memory
       968012 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       250892 non-nice user cpu ticks
        30881 nice user cpu ticks
        92245 system cpu ticks
      1140865 idle cpu ticks
          537 IO-wait cpu ticks
            0 IRQ cpu ticks
         1067 softirq cpu ticks
          171 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1186912 K paged in
       673696 K paged out
            0 pages swapped in
            0 pages swapped out
      7642241 interrupts
     27985390 CPU context switches
   1764133838 boot time
       133016 forks
