      3840620 K total memory
      2661984 K used memory
       449308 K active memory
      2545352 K inactive memory
       304444 K free memory
        62300 K buffer memory
      1091824 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       165276 non-nice user cpu ticks
        21772 nice user cpu ticks
        62044 system cpu ticks
       690023 idle cpu ticks
          345 IO-wait cpu ticks
            0 IRQ cpu ticks
          715 softirq cpu ticks
          108 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1068025 K paged in
       527308 K paged out
            0 pages swapped in
            0 pages swapped out
      4833700 interrupts
     17929926 CPU context switches
   1764133839 boot time
        95109 forks
