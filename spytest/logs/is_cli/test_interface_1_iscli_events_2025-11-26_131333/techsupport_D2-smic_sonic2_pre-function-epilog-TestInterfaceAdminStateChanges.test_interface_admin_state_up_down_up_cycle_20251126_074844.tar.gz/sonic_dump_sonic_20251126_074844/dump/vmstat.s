      3840620 K total memory
      2593212 K used memory
       449324 K active memory
      2532564 K inactive memory
       311256 K free memory
        69208 K buffer memory
      1149988 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       156917 non-nice user cpu ticks
        22263 nice user cpu ticks
        62509 system cpu ticks
       695314 idle cpu ticks
          368 IO-wait cpu ticks
            0 IRQ cpu ticks
          707 softirq cpu ticks
          115 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1033867 K paged in
       557148 K paged out
            0 pages swapped in
            0 pages swapped out
      4781088 interrupts
     18739061 CPU context switches
   1764133844 boot time
        89052 forks
