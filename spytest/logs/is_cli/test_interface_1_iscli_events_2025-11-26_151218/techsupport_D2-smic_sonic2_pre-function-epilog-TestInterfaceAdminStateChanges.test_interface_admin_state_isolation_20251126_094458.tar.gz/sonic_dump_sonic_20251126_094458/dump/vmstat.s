      3840620 K total memory
      2607684 K used memory
       478088 K active memory
      2469144 K inactive memory
       336496 K free memory
        89608 K buffer memory
      1094796 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       254692 non-nice user cpu ticks
        37603 nice user cpu ticks
       101942 system cpu ticks
      1228632 idle cpu ticks
          597 IO-wait cpu ticks
            0 IRQ cpu ticks
         1183 softirq cpu ticks
          203 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1159513 K paged in
       793528 K paged out
            0 pages swapped in
            0 pages swapped out
      8181228 interrupts
     31896558 CPU context switches
   1764133844 boot time
       143251 forks
