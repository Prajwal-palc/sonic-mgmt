      3840620 K total memory
      2829404 K used memory
       433688 K active memory
      2531708 K inactive memory
       365800 K free memory
        81688 K buffer memory
       848888 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       273984 non-nice user cpu ticks
        37173 nice user cpu ticks
       103364 system cpu ticks
      1212941 idle cpu ticks
          601 IO-wait cpu ticks
            0 IRQ cpu ticks
         1213 softirq cpu ticks
          184 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1309849 K paged in
       748268 K paged out
            0 pages swapped in
            0 pages swapped out
      8334976 interrupts
     30634808 CPU context switches
   1764133839 boot time
       155062 forks
