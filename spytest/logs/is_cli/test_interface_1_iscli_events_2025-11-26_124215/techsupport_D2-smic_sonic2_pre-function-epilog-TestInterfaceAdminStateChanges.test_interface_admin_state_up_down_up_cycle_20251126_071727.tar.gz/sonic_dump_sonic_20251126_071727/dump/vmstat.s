      3840620 K total memory
      2597292 K used memory
       422344 K active memory
      2535024 K inactive memory
       334720 K free memory
        61912 K buffer memory
      1123340 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       129622 non-nice user cpu ticks
        13531 nice user cpu ticks
        48613 system cpu ticks
       560632 idle cpu ticks
          289 IO-wait cpu ticks
            0 IRQ cpu ticks
          515 softirq cpu ticks
           92 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       975652 K paged in
       459588 K paged out
            0 pages swapped in
            0 pages swapped out
      3774703 interrupts
     14714549 CPU context switches
   1764133844 boot time
        61948 forks
