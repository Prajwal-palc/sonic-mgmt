      3840620 K total memory
      2661116 K used memory
       443156 K active memory
      2567264 K inactive memory
       291240 K free memory
        56688 K buffer memory
      1110776 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       138839 non-nice user cpu ticks
        15151 nice user cpu ticks
        50245 system cpu ticks
       583624 idle cpu ticks
          279 IO-wait cpu ticks
            0 IRQ cpu ticks
          562 softirq cpu ticks
           90 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1029609 K paged in
       457016 K paged out
            0 pages swapped in
            0 pages swapped out
      3991534 interrupts
     14751775 CPU context switches
   1764133840 boot time
        72662 forks
