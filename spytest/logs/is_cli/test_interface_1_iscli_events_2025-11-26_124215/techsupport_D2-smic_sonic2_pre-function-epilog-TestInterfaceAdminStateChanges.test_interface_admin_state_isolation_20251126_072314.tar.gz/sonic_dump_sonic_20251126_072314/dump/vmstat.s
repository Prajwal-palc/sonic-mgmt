      3840620 K total memory
      2586072 K used memory
       438140 K active memory
      2534804 K inactive memory
       328656 K free memory
        63420 K buffer memory
      1142876 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       134348 non-nice user cpu ticks
        15656 nice user cpu ticks
        51452 system cpu ticks
       584585 idle cpu ticks
          309 IO-wait cpu ticks
            0 IRQ cpu ticks
          555 softirq cpu ticks
           95 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       997798 K paged in
       476532 K paged out
            0 pages swapped in
            0 pages swapped out
      3968201 interrupts
     15495570 CPU context switches
   1764133844 boot time
        68286 forks
