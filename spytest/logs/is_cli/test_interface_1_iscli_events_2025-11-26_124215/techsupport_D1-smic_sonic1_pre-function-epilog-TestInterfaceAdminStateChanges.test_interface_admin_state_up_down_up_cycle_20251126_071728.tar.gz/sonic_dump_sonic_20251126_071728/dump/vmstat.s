      3840620 K total memory
      2651620 K used memory
       442180 K active memory
      2562712 K inactive memory
       299856 K free memory
        55988 K buffer memory
      1112328 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       132977 non-nice user cpu ticks
        13016 nice user cpu ticks
        47210 system cpu ticks
       560788 idle cpu ticks
          269 IO-wait cpu ticks
            0 IRQ cpu ticks
          525 softirq cpu ticks
           86 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1017864 K paged in
       435060 K paged out
            0 pages swapped in
            0 pages swapped out
      3791966 interrupts
     13981074 CPU context switches
   1764133840 boot time
        65880 forks
