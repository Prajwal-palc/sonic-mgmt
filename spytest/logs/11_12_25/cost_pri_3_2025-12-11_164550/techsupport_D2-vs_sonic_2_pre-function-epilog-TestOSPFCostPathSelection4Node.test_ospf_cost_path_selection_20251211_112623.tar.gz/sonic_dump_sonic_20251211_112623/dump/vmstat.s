      3840620 K total memory
      2556408 K used memory
       354672 K active memory
      2534232 K inactive memory
       429568 K free memory
        34248 K buffer memory
      1087512 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        30399 non-nice user cpu ticks
         1600 nice user cpu ticks
        11422 system cpu ticks
       108478 idle cpu ticks
           87 IO-wait cpu ticks
            0 IRQ cpu ticks
          114 softirq cpu ticks
           20 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       926151 K paged in
        58685 K paged out
            0 pages swapped in
            0 pages swapped out
       795100 interrupts
      3025436 CPU context switches
   1765450889 boot time
        13459 forks
