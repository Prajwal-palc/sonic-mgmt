      3840620 K total memory
      2548016 K used memory
       355048 K active memory
      2535144 K inactive memory
       439992 K free memory
        34252 K buffer memory
      1085444 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        29238 non-nice user cpu ticks
         1609 nice user cpu ticks
        11162 system cpu ticks
       109559 idle cpu ticks
           73 IO-wait cpu ticks
            0 IRQ cpu ticks
          104 softirq cpu ticks
           17 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       926006 K paged in
        58201 K paged out
            0 pages swapped in
            0 pages swapped out
       809048 interrupts
      3045863 CPU context switches
   1765450893 boot time
        13470 forks
