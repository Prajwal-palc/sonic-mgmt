      3840620 K total memory
      2567892 K used memory
       356344 K active memory
      2557372 K inactive memory
       419516 K free memory
        34308 K buffer memory
      1085980 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        27491 non-nice user cpu ticks
         1682 nice user cpu ticks
        10692 system cpu ticks
       111239 idle cpu ticks
           81 IO-wait cpu ticks
            0 IRQ cpu ticks
           94 softirq cpu ticks
           16 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       924040 K paged in
        58005 K paged out
            0 pages swapped in
            0 pages swapped out
       785808 interrupts
      2956153 CPU context switches
   1765450897 boot time
        12971 forks
