      3840620 K total memory
      2551400 K used memory
       357600 K active memory
      2539188 K inactive memory
       439260 K free memory
        34628 K buffer memory
      1082224 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        29177 non-nice user cpu ticks
         1750 nice user cpu ticks
        11369 system cpu ticks
       110280 idle cpu ticks
           83 IO-wait cpu ticks
            0 IRQ cpu ticks
           91 softirq cpu ticks
           19 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       927944 K paged in
        59073 K paged out
            0 pages swapped in
            0 pages swapped out
       806051 interrupts
      3021865 CPU context switches
   1765450886 boot time
        13365 forks
