      3840620 K total memory
      2611556 K used memory
       377680 K active memory
      2582972 K inactive memory
       362180 K free memory
        39416 K buffer memory
      1097120 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        51605 non-nice user cpu ticks
         4209 nice user cpu ticks
        19621 system cpu ticks
       222954 idle cpu ticks
          106 IO-wait cpu ticks
            0 IRQ cpu ticks
          196 softirq cpu ticks
           35 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       955909 K paged in
        89893 K paged out
            0 pages swapped in
            0 pages swapped out
      1528342 interrupts
      5590896 CPU context switches
   1765450887 boot time
        22944 forks
