      3840620 K total memory
      2689888 K used memory
       378244 K active memory
      2664384 K inactive memory
       272536 K free memory
        39740 K buffer memory
      1109520 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        52148 non-nice user cpu ticks
         3964 nice user cpu ticks
        19459 system cpu ticks
       221885 idle cpu ticks
           99 IO-wait cpu ticks
            0 IRQ cpu ticks
          203 softirq cpu ticks
           32 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       949762 K paged in
        89497 K paged out
            0 pages swapped in
            0 pages swapped out
      1521186 interrupts
      5599609 CPU context switches
   1765450894 boot time
        23070 forks
