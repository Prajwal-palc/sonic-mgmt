      3840620 K total memory
      2617524 K used memory
       377508 K active memory
      2600584 K inactive memory
       346088 K free memory
        39008 K buffer memory
      1108988 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        48545 non-nice user cpu ticks
         4154 nice user cpu ticks
        18544 system cpu ticks
       225469 idle cpu ticks
          105 IO-wait cpu ticks
            0 IRQ cpu ticks
          187 softirq cpu ticks
           32 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       946737 K paged in
        84829 K paged out
            0 pages swapped in
            0 pages swapped out
      1492096 interrupts
      5462603 CPU context switches
   1765450897 boot time
        22008 forks
