      3840620 K total memory
      2601232 K used memory
       371648 K active memory
      2563580 K inactive memory
       382524 K free memory
        39112 K buffer memory
      1084500 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        53787 non-nice user cpu ticks
         4056 nice user cpu ticks
        19759 system cpu ticks
       220542 idle cpu ticks
          116 IO-wait cpu ticks
            0 IRQ cpu ticks
          218 softirq cpu ticks
           35 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       954744 K paged in
        90637 K paged out
            0 pages swapped in
            0 pages swapped out
      1519076 interrupts
      5623627 CPU context switches
   1765450890 boot time
        23173 forks
