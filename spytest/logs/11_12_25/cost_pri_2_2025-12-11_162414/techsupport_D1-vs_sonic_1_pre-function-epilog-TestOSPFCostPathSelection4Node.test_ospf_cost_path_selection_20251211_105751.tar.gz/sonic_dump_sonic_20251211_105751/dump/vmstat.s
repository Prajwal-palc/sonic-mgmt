      3840620 K total memory
      2452092 K used memory
       352148 K active memory
      2436032 K inactive memory
       552124 K free memory
        33088 K buffer memory
      1070076 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        19551 non-nice user cpu ticks
         1620 nice user cpu ticks
         8276 system cpu ticks
        61654 idle cpu ticks
           75 IO-wait cpu ticks
            0 IRQ cpu ticks
           68 softirq cpu ticks
           11 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       906934 K paged in
        50481 K paged out
            0 pages swapped in
            0 pages swapped out
       518029 interrupts
      2043709 CPU context switches
   1765449798 boot time
        11933 forks
