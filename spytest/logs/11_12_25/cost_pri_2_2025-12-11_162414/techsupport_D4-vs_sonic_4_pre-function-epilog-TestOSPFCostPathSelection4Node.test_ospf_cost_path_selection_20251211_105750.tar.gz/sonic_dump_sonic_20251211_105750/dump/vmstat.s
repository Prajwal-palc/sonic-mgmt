      3840620 K total memory
      2465128 K used memory
       352104 K active memory
      2422940 K inactive memory
       542220 K free memory
        32968 K buffer memory
      1075368 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        19034 non-nice user cpu ticks
         1675 nice user cpu ticks
         8161 system cpu ticks
        60171 idle cpu ticks
           61 IO-wait cpu ticks
            0 IRQ cpu ticks
           54 softirq cpu ticks
           10 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       902908 K paged in
        47137 K paged out
            0 pages swapped in
            0 pages swapped out
       502143 interrupts
      2010154 CPU context switches
   1765449812 boot time
        11929 forks
