      3840620 K total memory
      2458628 K used memory
       353364 K active memory
      2425888 K inactive memory
       540300 K free memory
        33088 K buffer memory
      1075388 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        18813 non-nice user cpu ticks
         1711 nice user cpu ticks
         8406 system cpu ticks
        58905 idle cpu ticks
           91 IO-wait cpu ticks
            0 IRQ cpu ticks
           67 softirq cpu ticks
            9 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       907190 K paged in
        47501 K paged out
            0 pages swapped in
            0 pages swapped out
       502201 interrupts
      1969708 CPU context switches
   1765449827 boot time
        11795 forks
