      3840620 K total memory
      2524464 K used memory
       355084 K active memory
      2524888 K inactive memory
       474648 K free memory
        32964 K buffer memory
      1075656 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        20231 non-nice user cpu ticks
         1686 nice user cpu ticks
         8790 system cpu ticks
        59119 idle cpu ticks
          119 IO-wait cpu ticks
            0 IRQ cpu ticks
           72 softirq cpu ticks
           11 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       905977 K paged in
        47749 K paged out
            0 pages swapped in
            0 pages swapped out
       518223 interrupts
      2059282 CPU context switches
   1765449805 boot time
        12057 forks
