      3840620 K total memory
      2615752 K used memory
       405040 K active memory
      2588536 K inactive memory
       346688 K free memory
        56764 K buffer memory
      1094144 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       240431 non-nice user cpu ticks
        18380 nice user cpu ticks
        92248 system cpu ticks
       874805 idle cpu ticks
          301 IO-wait cpu ticks
            0 IRQ cpu ticks
         8565 softirq cpu ticks
          131 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1014378 K paged in
       265905 K paged out
            0 pages swapped in
            0 pages swapped out
      6200904 interrupts
     28113744 CPU context switches
   1766067252 boot time
        73501 forks
