      3840632 K total memory
      2660300 K used memory
       430920 K active memory
      2581316 K inactive memory
       296384 K free memory
        66856 K buffer memory
      1094128 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       267776 non-nice user cpu ticks
        23327 nice user cpu ticks
       103582 system cpu ticks
       926911 idle cpu ticks
          378 IO-wait cpu ticks
            0 IRQ cpu ticks
         9679 softirq cpu ticks
          137 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1076038 K paged in
       339053 K paged out
            0 pages swapped in
            0 pages swapped out
      6753027 interrupts
     30848659 CPU context switches
   1766067245 boot time
        90167 forks
