      3840620 K total memory
      2686892 K used memory
       411736 K active memory
      2643888 K inactive memory
       271452 K free memory
        60356 K buffer memory
      1097256 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       262681 non-nice user cpu ticks
        20672 nice user cpu ticks
       104699 system cpu ticks
       900645 idle cpu ticks
          291 IO-wait cpu ticks
            0 IRQ cpu ticks
         9950 softirq cpu ticks
          166 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1055568 K paged in
       293521 K paged out
            0 pages swapped in
            0 pages swapped out
      6572347 interrupts
     30056346 CPU context switches
   1766067245 boot time
        83734 forks
