      3840620 K total memory
      2730700 K used memory
       451928 K active memory
      2629576 K inactive memory
       228868 K free memory
        78584 K buffer memory
      1082552 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       374687 non-nice user cpu ticks
        37342 nice user cpu ticks
       152382 system cpu ticks
      1207231 idle cpu ticks
          421 IO-wait cpu ticks
            0 IRQ cpu ticks
        13674 softirq cpu ticks
          226 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1173974 K paged in
       502345 K paged out
            0 pages swapped in
            0 pages swapped out
      9356118 interrupts
     42680402 CPU context switches
   1766067245 boot time
       138937 forks
