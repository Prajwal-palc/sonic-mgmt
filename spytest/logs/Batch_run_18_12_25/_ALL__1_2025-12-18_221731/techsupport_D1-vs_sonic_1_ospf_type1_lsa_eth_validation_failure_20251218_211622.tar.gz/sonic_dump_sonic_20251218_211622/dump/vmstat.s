      3840620 K total memory
      2650848 K used memory
       468388 K active memory
      2514336 K inactive memory
       357888 K free memory
        99120 K buffer memory
      1015868 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       523909 non-nice user cpu ticks
        53927 nice user cpu ticks
       215215 system cpu ticks
      1690586 idle cpu ticks
          650 IO-wait cpu ticks
            0 IRQ cpu ticks
        19267 softirq cpu ticks
          320 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1334286 K paged in
       742377 K paged out
            0 pages swapped in
            0 pages swapped out
     13206607 interrupts
     60197341 CPU context switches
   1766067245 boot time
       198481 forks
