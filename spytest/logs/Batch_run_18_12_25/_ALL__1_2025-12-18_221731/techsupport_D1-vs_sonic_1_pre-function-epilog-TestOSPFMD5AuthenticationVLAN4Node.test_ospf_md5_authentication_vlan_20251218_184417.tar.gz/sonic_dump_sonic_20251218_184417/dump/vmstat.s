      3840620 K total memory
      2675156 K used memory
       431096 K active memory
      2588236 K inactive memory
       278724 K free memory
        71544 K buffer memory
      1094380 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       329432 non-nice user cpu ticks
        30229 nice user cpu ticks
       133484 system cpu ticks
      1097974 idle cpu ticks
          374 IO-wait cpu ticks
            0 IRQ cpu ticks
        12295 softirq cpu ticks
          205 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1124837 K paged in
       418709 K paged out
            0 pages swapped in
            0 pages swapped out
      8285297 interrupts
     37842943 CPU context switches
   1766067245 boot time
       115798 forks
