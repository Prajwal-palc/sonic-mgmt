      3840620 K total memory
      2711384 K used memory
       471092 K active memory
      2517340 K inactive memory
       286372 K free memory
        97236 K buffer memory
      1031740 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       512126 non-nice user cpu ticks
        51568 nice user cpu ticks
       209690 system cpu ticks
      1663756 idle cpu ticks
          630 IO-wait cpu ticks
            0 IRQ cpu ticks
        18919 softirq cpu ticks
          314 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1318135 K paged in
       713005 K paged out
            0 pages swapped in
            0 pages swapped out
     12909078 interrupts
     58854818 CPU context switches
   1766067245 boot time
       190906 forks
