      3840632 K total memory
      2651388 K used memory
       495004 K active memory
      2496192 K inactive memory
       314016 K free memory
       106568 K buffer memory
      1055808 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       543927 non-nice user cpu ticks
        60471 nice user cpu ticks
       222391 system cpu ticks
      1664576 idle cpu ticks
          754 IO-wait cpu ticks
            0 IRQ cpu ticks
        19573 softirq cpu ticks
          310 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1304405 K paged in
       820361 K paged out
            0 pages swapped in
            0 pages swapped out
     13827482 interrupts
     62232071 CPU context switches
   1766067251 boot time
       214589 forks
