      3840632 K total memory
      2654092 K used memory
       462824 K active memory
      2556048 K inactive memory
       301884 K free memory
        84580 K buffer memory
      1079880 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       373106 non-nice user cpu ticks
        35502 nice user cpu ticks
       144908 system cpu ticks
      1212712 idle cpu ticks
          521 IO-wait cpu ticks
            0 IRQ cpu ticks
        13189 softirq cpu ticks
          188 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1187326 K paged in
       505625 K paged out
            0 pages swapped in
            0 pages swapped out
      9248373 interrupts
     42180135 CPU context switches
   1766067245 boot time
       133363 forks
