      3840632 K total memory
      2615604 K used memory
       406548 K active memory
      2592048 K inactive memory
       332600 K free memory
        53044 K buffer memory
      1112420 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       192354 non-nice user cpu ticks
         9228 nice user cpu ticks
        72697 system cpu ticks
       705016 idle cpu ticks
          262 IO-wait cpu ticks
            0 IRQ cpu ticks
         7416 softirq cpu ticks
          127 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       963685 K paged in
       171021 K paged out
            0 pages swapped in
            0 pages swapped out
      4936742 interrupts
     22046522 CPU context switches
   1766067251 boot time
        44938 forks
