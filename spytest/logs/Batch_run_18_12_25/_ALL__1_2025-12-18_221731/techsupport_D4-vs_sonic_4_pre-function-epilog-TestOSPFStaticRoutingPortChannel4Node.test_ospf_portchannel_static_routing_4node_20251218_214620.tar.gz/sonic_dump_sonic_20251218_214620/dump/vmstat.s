      3840632 K total memory
      2791812 K used memory
       489440 K active memory
      2569004 K inactive memory
       246320 K free memory
       114396 K buffer memory
       977520 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       575916 non-nice user cpu ticks
        66384 nice user cpu ticks
       232035 system cpu ticks
      1788115 idle cpu ticks
          857 IO-wait cpu ticks
            0 IRQ cpu ticks
        20341 softirq cpu ticks
          293 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1426181 K paged in
       919917 K paged out
            0 pages swapped in
            0 pages swapped out
     14378231 interrupts
     65834022 CPU context switches
   1766067245 boot time
       235287 forks
