      3840620 K total memory
      2636128 K used memory
       476708 K active memory
      2511428 K inactive memory
       338696 K free memory
        93720 K buffer memory
      1057620 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       498700 non-nice user cpu ticks
        52459 nice user cpu ticks
       200420 system cpu ticks
      1686648 idle cpu ticks
          640 IO-wait cpu ticks
            0 IRQ cpu ticks
        17383 softirq cpu ticks
          276 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1246342 K paged in
       702633 K paged out
            0 pages swapped in
            0 pages swapped out
     12896890 interrupts
     58412379 CPU context switches
   1766067252 boot time
       184235 forks
