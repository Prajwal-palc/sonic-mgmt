      3840620 K total memory
      2595800 K used memory
       497612 K active memory
      2449896 K inactive memory
       351748 K free memory
       100696 K buffer memory
      1078480 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       542383 non-nice user cpu ticks
        59636 nice user cpu ticks
       219993 system cpu ticks
      1822542 idle cpu ticks
          717 IO-wait cpu ticks
            0 IRQ cpu ticks
        18888 softirq cpu ticks
          309 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1286681 K paged in
       797053 K paged out
            0 pages swapped in
            0 pages swapped out
     14080316 interrupts
     63775288 CPU context switches
   1766067252 boot time
       207023 forks
