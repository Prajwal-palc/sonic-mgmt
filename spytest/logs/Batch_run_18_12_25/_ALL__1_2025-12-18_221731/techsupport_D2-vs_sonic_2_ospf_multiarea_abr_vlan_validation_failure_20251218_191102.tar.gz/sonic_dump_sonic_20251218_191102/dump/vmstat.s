      3840632 K total memory
      2613980 K used memory
       450612 K active memory
      2562208 K inactive memory
       321760 K free memory
        82684 K buffer memory
      1102064 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       373900 non-nice user cpu ticks
        36060 nice user cpu ticks
       149253 system cpu ticks
      1188312 idle cpu ticks
          513 IO-wait cpu ticks
            0 IRQ cpu ticks
        13507 softirq cpu ticks
          218 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1156930 K paged in
       502833 K paged out
            0 pages swapped in
            0 pages swapped out
      9496811 interrupts
     42534627 CPU context switches
   1766067251 boot time
       133819 forks
