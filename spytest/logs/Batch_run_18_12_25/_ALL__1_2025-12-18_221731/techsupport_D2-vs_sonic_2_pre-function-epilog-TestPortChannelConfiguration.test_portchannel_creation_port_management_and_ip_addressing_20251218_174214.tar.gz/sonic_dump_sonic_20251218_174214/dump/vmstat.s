      3840632 K total memory
      2645540 K used memory
       419268 K active memory
      2588032 K inactive memory
       295036 K free memory
        61376 K buffer memory
      1113748 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       249491 non-nice user cpu ticks
        18927 nice user cpu ticks
        97896 system cpu ticks
       859201 idle cpu ticks
          340 IO-wait cpu ticks
            0 IRQ cpu ticks
         9339 softirq cpu ticks
          155 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1019212 K paged in
       284181 K paged out
            0 pages swapped in
            0 pages swapped out
      6425170 interrupts
     28713680 CPU context switches
   1766067251 boot time
        76336 forks
