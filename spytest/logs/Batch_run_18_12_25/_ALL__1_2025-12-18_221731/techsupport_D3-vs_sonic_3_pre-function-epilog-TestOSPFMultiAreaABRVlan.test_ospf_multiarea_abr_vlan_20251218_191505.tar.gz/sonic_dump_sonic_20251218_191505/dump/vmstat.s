      3840620 K total memory
      2673260 K used memory
       442412 K active memory
      2571516 K inactive memory
       270648 K free memory
        75272 K buffer memory
      1102876 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       359920 non-nice user cpu ticks
        37796 nice user cpu ticks
       143787 system cpu ticks
      1230629 idle cpu ticks
          448 IO-wait cpu ticks
            0 IRQ cpu ticks
        12510 softirq cpu ticks
          192 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1136501 K paged in
       489841 K paged out
            0 pages swapped in
            0 pages swapped out
      9327061 interrupts
     42234815 CPU context switches
   1766067252 boot time
       133862 forks
