      3840620 K total memory
      2626792 K used memory
       403484 K active memory
      2589020 K inactive memory
       327968 K free memory
        49848 K buffer memory
      1109100 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       188038 non-nice user cpu ticks
         8929 nice user cpu ticks
        68863 system cpu ticks
       714783 idle cpu ticks
          241 IO-wait cpu ticks
            0 IRQ cpu ticks
         6778 softirq cpu ticks
          104 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       961709 K paged in
       162917 K paged out
            0 pages swapped in
            0 pages swapped out
      4794990 interrupts
     21744741 CPU context switches
   1766067252 boot time
        44184 forks
