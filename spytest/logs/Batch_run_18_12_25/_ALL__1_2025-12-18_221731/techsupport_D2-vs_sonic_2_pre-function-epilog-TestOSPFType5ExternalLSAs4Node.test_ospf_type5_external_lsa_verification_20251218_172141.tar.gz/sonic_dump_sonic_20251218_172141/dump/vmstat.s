      3840632 K total memory
      2643284 K used memory
       410444 K active memory
      2594848 K inactive memory
       298780 K free memory
        57232 K buffer memory
      1117100 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       219826 non-nice user cpu ticks
        16514 nice user cpu ticks
        86762 system cpu ticks
       781789 idle cpu ticks
          301 IO-wait cpu ticks
            0 IRQ cpu ticks
         8394 softirq cpu ticks
          142 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       996136 K paged in
       241677 K paged out
            0 pages swapped in
            0 pages swapped out
      5733880 interrupts
     25639409 CPU context switches
   1766067251 boot time
        65711 forks
