      3840632 K total memory
      2643664 K used memory
       410676 K active memory
      2597680 K inactive memory
       319564 K free memory
        56720 K buffer memory
      1092300 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       208974 non-nice user cpu ticks
        13785 nice user cpu ticks
        78883 system cpu ticks
       770119 idle cpu ticks
          293 IO-wait cpu ticks
            0 IRQ cpu ticks
         7736 softirq cpu ticks
          112 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1007398 K paged in
       222657 K paged out
            0 pages swapped in
            0 pages swapped out
      5307547 interrupts
     24235171 CPU context switches
   1766067245 boot time
        59091 forks
