      3840620 K total memory
      2661132 K used memory
       404824 K active memory
      2603452 K inactive memory
       298816 K free memory
        54660 K buffer memory
      1100744 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       220118 non-nice user cpu ticks
        15961 nice user cpu ticks
        87507 system cpu ticks
       781754 idle cpu ticks
          250 IO-wait cpu ticks
            0 IRQ cpu ticks
         8518 softirq cpu ticks
          143 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1001058 K paged in
       231277 K paged out
            0 pages swapped in
            0 pages swapped out
      5538332 interrupts
     25414349 CPU context switches
   1766067245 boot time
        66062 forks
