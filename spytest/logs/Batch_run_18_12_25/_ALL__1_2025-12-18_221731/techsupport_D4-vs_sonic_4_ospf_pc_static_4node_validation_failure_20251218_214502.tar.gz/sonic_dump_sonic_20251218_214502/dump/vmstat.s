      3840632 K total memory
      2666532 K used memory
       487684 K active memory
      2449172 K inactive memory
       376536 K free memory
       114016 K buffer memory
       972744 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       573939 non-nice user cpu ticks
        63960 nice user cpu ticks
       229691 system cpu ticks
      1787295 idle cpu ticks
          856 IO-wait cpu ticks
            0 IRQ cpu ticks
        20276 softirq cpu ticks
          291 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1420052 K paged in
       897589 K paged out
            0 pages swapped in
            0 pages swapped out
     14288403 interrupts
     65410919 CPU context switches
   1766067245 boot time
       229377 forks
