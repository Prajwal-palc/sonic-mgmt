      3840620 K total memory
      2686620 K used memory
       486192 K active memory
      2512020 K inactive memory
       276636 K free memory
        96300 K buffer memory
      1066108 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       514749 non-nice user cpu ticks
        57168 nice user cpu ticks
       209013 system cpu ticks
      1735365 idle cpu ticks
          672 IO-wait cpu ticks
            0 IRQ cpu ticks
        17941 softirq cpu ticks
          288 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1269236 K paged in
       753689 K paged out
            0 pages swapped in
            0 pages swapped out
     13379425 interrupts
     60626365 CPU context switches
   1766067252 boot time
       197581 forks
