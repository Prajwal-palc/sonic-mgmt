      3840620 K total memory
      2627432 K used memory
       480328 K active memory
      2535348 K inactive memory
       316988 K free memory
        90684 K buffer memory
      1089252 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       475998 non-nice user cpu ticks
        47546 nice user cpu ticks
       189288 system cpu ticks
      1611898 idle cpu ticks
          609 IO-wait cpu ticks
            0 IRQ cpu ticks
        16519 softirq cpu ticks
          260 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1200627 K paged in
       647249 K paged out
            0 pages swapped in
            0 pages swapped out
     12249150 interrupts
     55473629 CPU context switches
   1766067252 boot time
       170719 forks
