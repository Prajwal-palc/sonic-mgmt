      3840620 K total memory
      2620980 K used memory
       407848 K active memory
      2599292 K inactive memory
       322964 K free memory
        52672 K buffer memory
      1117460 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       206914 non-nice user cpu ticks
        13550 nice user cpu ticks
        78237 system cpu ticks
       772147 idle cpu ticks
          264 IO-wait cpu ticks
            0 IRQ cpu ticks
         7437 softirq cpu ticks
          115 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       981072 K paged in
       204493 K paged out
            0 pages swapped in
            0 pages swapped out
      5337067 interrupts
     24204931 CPU context switches
   1766067252 boot time
        57868 forks
