      3840632 K total memory
      2648100 K used memory
       429264 K active memory
      2581992 K inactive memory
       290264 K free memory
        68808 K buffer memory
      1110976 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       290274 non-nice user cpu ticks
        26186 nice user cpu ticks
       115677 system cpu ticks
       966870 idle cpu ticks
          406 IO-wait cpu ticks
            0 IRQ cpu ticks
        10694 softirq cpu ticks
          174 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1069452 K paged in
       368625 K paged out
            0 pages swapped in
            0 pages swapped out
      7471359 interrupts
     33463662 CPU context switches
   1766067251 boot time
        99243 forks
