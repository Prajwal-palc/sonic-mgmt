      3840632 K total memory
      2663116 K used memory
       503456 K active memory
      2504204 K inactive memory
       290032 K free memory
       111544 K buffer memory
      1064636 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       575500 non-nice user cpu ticks
        65286 nice user cpu ticks
       236222 system cpu ticks
      1757059 idle cpu ticks
          804 IO-wait cpu ticks
            0 IRQ cpu ticks
        20748 softirq cpu ticks
          327 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1330851 K paged in
       880125 K paged out
            0 pages swapped in
            0 pages swapped out
     14650967 interrupts
     65997371 CPU context switches
   1766067251 boot time
       230315 forks
