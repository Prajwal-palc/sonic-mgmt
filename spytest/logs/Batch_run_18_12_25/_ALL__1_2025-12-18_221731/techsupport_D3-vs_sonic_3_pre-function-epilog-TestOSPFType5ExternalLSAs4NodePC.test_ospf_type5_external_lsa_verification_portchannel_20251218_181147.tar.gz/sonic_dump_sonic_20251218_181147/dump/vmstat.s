      3840620 K total memory
      2652072 K used memory
       419508 K active memory
      2584844 K inactive memory
       298476 K free memory
        62468 K buffer memory
      1104880 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       278537 non-nice user cpu ticks
        25710 nice user cpu ticks
       109119 system cpu ticks
       987324 idle cpu ticks
          342 IO-wait cpu ticks
            0 IRQ cpu ticks
         9829 softirq cpu ticks
          148 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1060955 K paged in
       344697 K paged out
            0 pages swapped in
            0 pages swapped out
      7225942 interrupts
     32745092 CPU context switches
   1766067252 boot time
        95496 forks
