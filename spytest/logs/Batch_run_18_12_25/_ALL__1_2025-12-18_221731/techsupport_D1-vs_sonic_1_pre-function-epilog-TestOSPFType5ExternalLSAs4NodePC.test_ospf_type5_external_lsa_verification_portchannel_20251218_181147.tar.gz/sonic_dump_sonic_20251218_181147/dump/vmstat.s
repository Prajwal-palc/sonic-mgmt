      3840620 K total memory
      2642388 K used memory
       421820 K active memory
      2580140 K inactive memory
       320352 K free memory
        64464 K buffer memory
      1089148 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       286428 non-nice user cpu ticks
        25508 nice user cpu ticks
       115941 system cpu ticks
       971900 idle cpu ticks
          319 IO-wait cpu ticks
            0 IRQ cpu ticks
        10814 softirq cpu ticks
          179 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1093009 K paged in
       347965 K paged out
            0 pages swapped in
            0 pages swapped out
      7216181 interrupts
     33013408 CPU context switches
   1766067245 boot time
        98183 forks
