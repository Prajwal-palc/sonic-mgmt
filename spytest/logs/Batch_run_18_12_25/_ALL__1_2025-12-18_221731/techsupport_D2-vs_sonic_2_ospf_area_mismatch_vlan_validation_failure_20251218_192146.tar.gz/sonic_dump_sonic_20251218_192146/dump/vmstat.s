      3840632 K total memory
      2663796 K used memory
       456956 K active memory
      2566532 K inactive memory
       262772 K free memory
        85324 K buffer memory
      1110800 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       388148 non-nice user cpu ticks
        41107 nice user cpu ticks
       157637 system cpu ticks
      1223372 idle cpu ticks
          534 IO-wait cpu ticks
            0 IRQ cpu ticks
        14026 softirq cpu ticks
          229 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1178647 K paged in
       548285 K paged out
            0 pages swapped in
            0 pages swapped out
      9930683 interrupts
     44474223 CPU context switches
   1766067251 boot time
       146856 forks
