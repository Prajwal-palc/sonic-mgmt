      3840632 K total memory
      2662484 K used memory
       473740 K active memory
      2460388 K inactive memory
       387228 K free memory
       103080 K buffer memory
       977624 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       504289 non-nice user cpu ticks
        50014 nice user cpu ticks
       197357 system cpu ticks
      1583190 idle cpu ticks
          745 IO-wait cpu ticks
            0 IRQ cpu ticks
        17770 softirq cpu ticks
          254 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1353545 K paged in
       726241 K paged out
            0 pages swapped in
            0 pages swapped out
     12428353 interrupts
     56803997 CPU context switches
   1766067245 boot time
       186660 forks
