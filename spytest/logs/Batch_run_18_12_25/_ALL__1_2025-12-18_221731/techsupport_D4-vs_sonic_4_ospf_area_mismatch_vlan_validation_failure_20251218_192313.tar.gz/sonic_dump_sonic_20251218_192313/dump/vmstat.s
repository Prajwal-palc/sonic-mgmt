      3840632 K total memory
      2693800 K used memory
       467920 K active memory
      2556616 K inactive memory
       258912 K free memory
        86980 K buffer memory
      1081636 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       385566 non-nice user cpu ticks
        40223 nice user cpu ticks
       151966 system cpu ticks
      1243599 idle cpu ticks
          542 IO-wait cpu ticks
            0 IRQ cpu ticks
        13617 softirq cpu ticks
          193 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1210677 K paged in
       556325 K paged out
            0 pages swapped in
            0 pages swapped out
      9621397 interrupts
     43907888 CPU context switches
   1766067245 boot time
       146309 forks
