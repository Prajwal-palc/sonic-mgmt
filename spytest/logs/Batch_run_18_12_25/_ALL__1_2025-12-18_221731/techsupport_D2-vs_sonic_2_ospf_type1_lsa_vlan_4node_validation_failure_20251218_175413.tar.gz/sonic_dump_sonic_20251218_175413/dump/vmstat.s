      3840632 K total memory
      2643340 K used memory
       421484 K active memory
      2580848 K inactive memory
       300740 K free memory
        64104 K buffer memory
      1107824 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       267078 non-nice user cpu ticks
        21327 nice user cpu ticks
       104792 system cpu ticks
       903003 idle cpu ticks
          361 IO-wait cpu ticks
            0 IRQ cpu ticks
         9868 softirq cpu ticks
          163 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1041029 K paged in
       313821 K paged out
            0 pages swapped in
            0 pages swapped out
      6843966 interrupts
     30596543 CPU context switches
   1766067251 boot time
        84652 forks
