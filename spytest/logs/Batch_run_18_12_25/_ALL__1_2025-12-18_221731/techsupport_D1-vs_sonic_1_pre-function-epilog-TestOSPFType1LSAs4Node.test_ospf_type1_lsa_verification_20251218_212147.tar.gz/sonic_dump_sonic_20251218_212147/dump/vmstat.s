      3840620 K total memory
      2672056 K used memory
       476464 K active memory
      2501180 K inactive memory
       337796 K free memory
        99936 K buffer memory
      1016292 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       530031 non-nice user cpu ticks
        56304 nice user cpu ticks
       219166 system cpu ticks
      1710281 idle cpu ticks
          657 IO-wait cpu ticks
            0 IRQ cpu ticks
        19518 softirq cpu ticks
          325 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1345711 K paged in
       763105 K paged out
            0 pages swapped in
            0 pages swapped out
     13406318 interrupts
     61117002 CPU context switches
   1766067245 boot time
       204695 forks
