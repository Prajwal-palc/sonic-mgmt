      3840620 K total memory
      2601232 K used memory
       415512 K active memory
      2593416 K inactive memory
       344700 K free memory
        58992 K buffer memory
      1112648 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       257824 non-nice user cpu ticks
        20824 nice user cpu ticks
        99276 system cpu ticks
       927704 idle cpu ticks
          317 IO-wait cpu ticks
            0 IRQ cpu ticks
         9131 softirq cpu ticks
          139 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1035822 K paged in
       290925 K paged out
            0 pages swapped in
            0 pages swapped out
      6648887 interrupts
     30129065 CPU context switches
   1766067252 boot time
        81380 forks
