      3840620 K total memory
      2704244 K used memory
       449164 K active memory
      2579312 K inactive memory
       252456 K free memory
        77524 K buffer memory
      1086300 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       368637 non-nice user cpu ticks
        34996 nice user cpu ticks
       148710 system cpu ticks
      1187702 idle cpu ticks
          413 IO-wait cpu ticks
            0 IRQ cpu ticks
        13418 softirq cpu ticks
          223 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1163035 K paged in
       482093 K paged out
            0 pages swapped in
            0 pages swapped out
      9162600 interrupts
     41772706 CPU context switches
   1766067245 boot time
       132711 forks
