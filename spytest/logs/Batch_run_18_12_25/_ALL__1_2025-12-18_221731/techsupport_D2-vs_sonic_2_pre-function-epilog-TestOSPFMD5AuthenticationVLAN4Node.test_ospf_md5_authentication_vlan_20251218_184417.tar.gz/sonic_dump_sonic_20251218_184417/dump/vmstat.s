      3840632 K total memory
      2646084 K used memory
       438620 K active memory
      2578924 K inactive memory
       292808 K free memory
        76144 K buffer memory
      1104856 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       335825 non-nice user cpu ticks
        31099 nice user cpu ticks
       133634 system cpu ticks
      1089804 idle cpu ticks
          463 IO-wait cpu ticks
            0 IRQ cpu ticks
        12268 softirq cpu ticks
          197 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1108412 K paged in
       438465 K paged out
            0 pages swapped in
            0 pages swapped out
      8578350 interrupts
     38444924 CPU context switches
   1766067251 boot time
       117528 forks
