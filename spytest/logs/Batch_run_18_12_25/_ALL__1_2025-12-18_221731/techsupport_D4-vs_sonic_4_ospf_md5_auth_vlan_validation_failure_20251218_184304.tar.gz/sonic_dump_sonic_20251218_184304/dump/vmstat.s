      3840632 K total memory
      2637420 K used memory
       447140 K active memory
      2561720 K inactive memory
       325168 K free memory
        77328 K buffer memory
      1074860 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       331337 non-nice user cpu ticks
        28192 nice user cpu ticks
       126870 system cpu ticks
      1099076 idle cpu ticks
          464 IO-wait cpu ticks
            0 IRQ cpu ticks
        11792 softirq cpu ticks
          167 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1135210 K paged in
       422409 K paged out
            0 pages swapped in
            0 pages swapped out
      8204084 interrupts
     37417731 CPU context switches
   1766067245 boot time
       110966 forks
