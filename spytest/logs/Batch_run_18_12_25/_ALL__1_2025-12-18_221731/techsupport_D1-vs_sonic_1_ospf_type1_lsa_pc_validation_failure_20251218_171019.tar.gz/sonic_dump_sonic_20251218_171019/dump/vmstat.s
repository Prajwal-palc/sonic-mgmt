      3840620 K total memory
      2625128 K used memory
       405688 K active memory
      2615900 K inactive memory
       327660 K free memory
        53060 K buffer memory
      1108164 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       206184 non-nice user cpu ticks
        11214 nice user cpu ticks
        79554 system cpu ticks
       741896 idle cpu ticks
          238 IO-wait cpu ticks
            0 IRQ cpu ticks
         8007 softirq cpu ticks
          136 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       976972 K paged in
       189397 K paged out
            0 pages swapped in
            0 pages swapped out
      5114470 interrupts
     23476387 CPU context switches
   1766067245 boot time
        53107 forks
