      3840620 K total memory
      2660736 K used memory
       442296 K active memory
      2524740 K inactive memory
       361316 K free memory
        93860 K buffer memory
      1007056 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       486387 non-nice user cpu ticks
        46823 nice user cpu ticks
       197308 system cpu ticks
      1576887 idle cpu ticks
          582 IO-wait cpu ticks
            0 IRQ cpu ticks
        17900 softirq cpu ticks
          293 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1280626 K paged in
       662249 K paged out
            0 pages swapped in
            0 pages swapped out
     12192567 interrupts
     55588256 CPU context switches
   1766067245 boot time
       176906 forks
