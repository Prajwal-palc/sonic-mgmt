      3840632 K total memory
      2669004 K used memory
       457260 K active memory
      2566000 K inactive memory
       281124 K free memory
        81552 K buffer memory
      1088508 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       355017 non-nice user cpu ticks
        33089 nice user cpu ticks
       137512 system cpu ticks
      1158616 idle cpu ticks
          498 IO-wait cpu ticks
            0 IRQ cpu ticks
        12569 softirq cpu ticks
          178 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1173146 K paged in
       476233 K paged out
            0 pages swapped in
            0 pages swapped out
      8797618 interrupts
     40132147 CPU context switches
   1766067245 boot time
       125555 forks
