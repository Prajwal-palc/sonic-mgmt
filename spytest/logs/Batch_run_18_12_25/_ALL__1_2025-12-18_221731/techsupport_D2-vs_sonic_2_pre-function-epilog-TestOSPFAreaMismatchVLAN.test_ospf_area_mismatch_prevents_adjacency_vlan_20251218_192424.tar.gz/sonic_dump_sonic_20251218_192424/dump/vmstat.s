      3840632 K total memory
      2633060 K used memory
       458612 K active memory
      2562232 K inactive memory
       301644 K free memory
        85948 K buffer memory
      1100460 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       391622 non-nice user cpu ticks
        43532 nice user cpu ticks
       160427 system cpu ticks
      1230266 idle cpu ticks
          538 IO-wait cpu ticks
            0 IRQ cpu ticks
        14159 softirq cpu ticks
          231 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1190824 K paged in
       573157 K paged out
            0 pages swapped in
            0 pages swapped out
     10061039 interrupts
     45076485 CPU context switches
   1766067251 boot time
       152963 forks
