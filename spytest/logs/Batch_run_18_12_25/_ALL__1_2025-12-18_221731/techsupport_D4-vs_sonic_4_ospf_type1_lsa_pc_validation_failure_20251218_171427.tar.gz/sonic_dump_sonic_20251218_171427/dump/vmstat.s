      3840632 K total memory
      2655892 K used memory
       412768 K active memory
      2597328 K inactive memory
       305532 K free memory
        56588 K buffer memory
      1094060 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       207402 non-nice user cpu ticks
        11420 nice user cpu ticks
        76698 system cpu ticks
       769264 idle cpu ticks
          290 IO-wait cpu ticks
            0 IRQ cpu ticks
         7682 softirq cpu ticks
          111 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       990196 K paged in
       202621 K paged out
            0 pages swapped in
            0 pages swapped out
      5223696 interrupts
     23836847 CPU context switches
   1766067245 boot time
        53246 forks
