      3840632 K total memory
      2627536 K used memory
       442852 K active memory
      2570400 K inactive memory
       313228 K free memory
        80084 K buffer memory
      1099416 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       358031 non-nice user cpu ticks
        33561 nice user cpu ticks
       142344 system cpu ticks
      1148454 idle cpu ticks
          494 IO-wait cpu ticks
            0 IRQ cpu ticks
        12983 softirq cpu ticks
          209 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1132676 K paged in
       473461 K paged out
            0 pages swapped in
            0 pages swapped out
      9101161 interrupts
     40777787 CPU context switches
   1766067251 boot time
       126168 forks
