      3840632 K total memory
      2668832 K used memory
       421984 K active memory
      2594264 K inactive memory
       283752 K free memory
        63012 K buffer memory
      1100060 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       245423 non-nice user cpu ticks
        18594 nice user cpu ticks
        93544 system cpu ticks
       869131 idle cpu ticks
          351 IO-wait cpu ticks
            0 IRQ cpu ticks
         8933 softirq cpu ticks
          128 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1041673 K paged in
       287589 K paged out
            0 pages swapped in
            0 pages swapped out
      6185748 interrupts
     28227666 CPU context switches
   1766067245 boot time
        75849 forks
