      3840620 K total memory
      2655204 K used memory
       445264 K active memory
      2571528 K inactive memory
       288252 K free memory
        76996 K buffer memory
      1099984 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       371096 non-nice user cpu ticks
        40223 nice user cpu ticks
       149210 system cpu ticks
      1267238 idle cpu ticks
          463 IO-wait cpu ticks
            0 IRQ cpu ticks
        12883 softirq cpu ticks
          199 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1149160 K paged in
       519089 K paged out
            0 pages swapped in
            0 pages swapped out
      9647376 interrupts
     43683317 CPU context switches
   1766067252 boot time
       140674 forks
