      3840632 K total memory
      2660920 K used memory
       414804 K active memory
      2590460 K inactive memory
       299268 K free memory
        58104 K buffer memory
      1096936 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       216861 non-nice user cpu ticks
        16177 nice user cpu ticks
        83039 system cpu ticks
       790701 idle cpu ticks
          305 IO-wait cpu ticks
            0 IRQ cpu ticks
         8014 softirq cpu ticks
          116 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1022883 K paged in
       244165 K paged out
            0 pages swapped in
            0 pages swapped out
      5531697 interrupts
     25257176 CPU context switches
   1766067245 boot time
        65842 forks
