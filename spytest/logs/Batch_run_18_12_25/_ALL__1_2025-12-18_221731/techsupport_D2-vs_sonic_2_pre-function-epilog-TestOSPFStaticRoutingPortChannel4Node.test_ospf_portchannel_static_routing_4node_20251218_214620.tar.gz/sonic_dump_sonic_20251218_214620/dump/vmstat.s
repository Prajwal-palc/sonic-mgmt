      3840632 K total memory
      2669240 K used memory
       506376 K active memory
      2499552 K inactive memory
       284444 K free memory
       112264 K buffer memory
      1063568 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       580320 non-nice user cpu ticks
        67656 nice user cpu ticks
       239471 system cpu ticks
      1771211 idle cpu ticks
          811 IO-wait cpu ticks
            0 IRQ cpu ticks
        20940 softirq cpu ticks
          329 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1340338 K paged in
       902221 K paged out
            0 pages swapped in
            0 pages swapped out
     14815345 interrupts
     66775329 CPU context switches
   1766067251 boot time
       236442 forks
