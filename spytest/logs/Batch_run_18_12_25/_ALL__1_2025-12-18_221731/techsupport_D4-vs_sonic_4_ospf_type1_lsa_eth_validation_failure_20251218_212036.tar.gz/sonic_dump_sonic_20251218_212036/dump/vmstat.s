      3840632 K total memory
      2674556 K used memory
       481984 K active memory
      2472752 K inactive memory
       350236 K free memory
       109248 K buffer memory
       997244 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       542057 non-nice user cpu ticks
        59222 nice user cpu ticks
       216108 system cpu ticks
      1693476 idle cpu ticks
          806 IO-wait cpu ticks
            0 IRQ cpu ticks
        19141 softirq cpu ticks
          275 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1385816 K paged in
       834445 K paged out
            0 pages swapped in
            0 pages swapped out
     13483657 interrupts
     61673153 CPU context switches
   1766067245 boot time
       213740 forks
