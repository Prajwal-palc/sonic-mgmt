      3840632 K total memory
      2703388 K used memory
       464792 K active memory
      2588560 K inactive memory
       256104 K free memory
        84968 K buffer memory
      1076196 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       374885 non-nice user cpu ticks
        37830 nice user cpu ticks
       147012 system cpu ticks
      1213522 idle cpu ticks
          523 IO-wait cpu ticks
            0 IRQ cpu ticks
        13252 softirq cpu ticks
          188 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1197568 K paged in
       528997 K paged out
            0 pages swapped in
            0 pages swapped out
      9330109 interrupts
     42587155 CPU context switches
   1766067245 boot time
       139298 forks
