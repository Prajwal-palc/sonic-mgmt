      3840620 K total memory
      2670144 K used memory
       441852 K active memory
      2569996 K inactive memory
       279184 K free memory
        74748 K buffer memory
      1095968 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       356872 non-nice user cpu ticks
        35433 nice user cpu ticks
       141169 system cpu ticks
      1223680 idle cpu ticks
          445 IO-wait cpu ticks
            0 IRQ cpu ticks
        12393 softirq cpu ticks
          191 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1129749 K paged in
       469257 K paged out
            0 pages swapped in
            0 pages swapped out
      9205790 interrupts
     41663410 CPU context switches
   1766067252 boot time
       127840 forks
