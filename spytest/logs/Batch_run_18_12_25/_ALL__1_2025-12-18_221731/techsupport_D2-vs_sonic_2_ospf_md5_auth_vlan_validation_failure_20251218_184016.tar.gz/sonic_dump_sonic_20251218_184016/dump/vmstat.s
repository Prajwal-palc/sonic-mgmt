      3840632 K total memory
      2655232 K used memory
       433384 K active memory
      2582088 K inactive memory
       278680 K free memory
        75096 K buffer memory
      1108476 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       331010 non-nice user cpu ticks
        28620 nice user cpu ticks
       130347 system cpu ticks
      1076400 idle cpu ticks
          455 IO-wait cpu ticks
            0 IRQ cpu ticks
        12070 softirq cpu ticks
          194 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1094731 K paged in
       416725 K paged out
            0 pages swapped in
            0 pages swapped out
      8408342 interrupts
     37660062 CPU context switches
   1766067251 boot time
       111375 forks
