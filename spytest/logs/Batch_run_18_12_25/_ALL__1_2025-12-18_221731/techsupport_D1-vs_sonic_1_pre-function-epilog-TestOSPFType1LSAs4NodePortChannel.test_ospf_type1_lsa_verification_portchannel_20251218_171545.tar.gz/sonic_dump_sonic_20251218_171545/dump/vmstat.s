      3840620 K total memory
      2663220 K used memory
       406340 K active memory
      2609240 K inactive memory
       288040 K free memory
        53676 K buffer memory
      1109180 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       212148 non-nice user cpu ticks
        13579 nice user cpu ticks
        83264 system cpu ticks
       761505 idle cpu ticks
          242 IO-wait cpu ticks
            0 IRQ cpu ticks
         8245 softirq cpu ticks
          139 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       986464 K paged in
       207681 K paged out
            0 pages swapped in
            0 pages swapped out
      5309414 interrupts
     24376099 CPU context switches
   1766067245 boot time
        59308 forks
