      3840632 K total memory
      2618256 K used memory
       410348 K active memory
      2598084 K inactive memory
       320840 K free memory
        56284 K buffer memory
      1118648 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       211844 non-nice user cpu ticks
        14085 nice user cpu ticks
        82520 system cpu ticks
       761336 idle cpu ticks
          290 IO-wait cpu ticks
            0 IRQ cpu ticks
         8121 softirq cpu ticks
          138 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       984214 K paged in
       218281 K paged out
            0 pages swapped in
            0 pages swapped out
      5499502 interrupts
     24582838 CPU context switches
   1766067251 boot time
        58940 forks
