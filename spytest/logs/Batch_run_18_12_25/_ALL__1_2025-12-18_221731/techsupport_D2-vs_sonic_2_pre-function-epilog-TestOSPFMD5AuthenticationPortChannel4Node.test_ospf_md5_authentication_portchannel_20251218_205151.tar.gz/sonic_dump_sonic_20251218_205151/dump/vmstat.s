      3840632 K total memory
      2639588 K used memory
       483820 K active memory
      2520560 K inactive memory
       316052 K free memory
       101408 K buffer memory
      1068280 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       509332 non-nice user cpu ticks
        53197 nice user cpu ticks
       206000 system cpu ticks
      1570968 idle cpu ticks
          696 IO-wait cpu ticks
            0 IRQ cpu ticks
        18354 softirq cpu ticks
          290 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1254820 K paged in
       735533 K paged out
            0 pages swapped in
            0 pages swapped out
     12897719 interrupts
     58034352 CPU context switches
   1766067251 boot time
       193403 forks
