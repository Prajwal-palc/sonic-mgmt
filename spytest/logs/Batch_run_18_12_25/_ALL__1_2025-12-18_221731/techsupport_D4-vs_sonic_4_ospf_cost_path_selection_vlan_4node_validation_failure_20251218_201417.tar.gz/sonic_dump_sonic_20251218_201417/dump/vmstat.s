      3840632 K total memory
      2654708 K used memory
       423484 K active memory
      2480328 K inactive memory
       428340 K free memory
        96440 K buffer memory
       942116 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       452798 non-nice user cpu ticks
        45065 nice user cpu ticks
       176727 system cpu ticks
      1447139 idle cpu ticks
          650 IO-wait cpu ticks
            0 IRQ cpu ticks
        15967 softirq cpu ticks
          228 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1311096 K paged in
       646961 K paged out
            0 pages swapped in
            0 pages swapped out
     11216615 interrupts
     51181888 CPU context switches
   1766067245 boot time
       166618 forks
