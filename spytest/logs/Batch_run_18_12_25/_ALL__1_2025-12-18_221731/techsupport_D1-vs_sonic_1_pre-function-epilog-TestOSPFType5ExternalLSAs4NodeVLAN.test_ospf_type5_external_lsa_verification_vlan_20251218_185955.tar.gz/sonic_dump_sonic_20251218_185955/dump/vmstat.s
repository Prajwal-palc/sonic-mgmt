      3840620 K total memory
      2672480 K used memory
       443248 K active memory
      2577128 K inactive memory
       283908 K free memory
        75352 K buffer memory
      1088580 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       355939 non-nice user cpu ticks
        32639 nice user cpu ticks
       142843 system cpu ticks
      1151355 idle cpu ticks
          394 IO-wait cpu ticks
            0 IRQ cpu ticks
        12965 softirq cpu ticks
          216 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1145509 K paged in
       454777 K paged out
            0 pages swapped in
            0 pages swapped out
      8827452 interrupts
     40251171 CPU context switches
   1766067245 boot time
       125451 forks
