      3840632 K total memory
      2671172 K used memory
       436028 K active memory
      2572012 K inactive memory
       285480 K free memory
        70516 K buffer memory
      1090964 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       286421 non-nice user cpu ticks
        25772 nice user cpu ticks
       111062 system cpu ticks
       978197 idle cpu ticks
          406 IO-wait cpu ticks
            0 IRQ cpu ticks
        10294 softirq cpu ticks
          145 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1097520 K paged in
       371193 K paged out
            0 pages swapped in
            0 pages swapped out
      7209160 interrupts
     32936011 CPU context switches
   1766067245 boot time
        98673 forks
