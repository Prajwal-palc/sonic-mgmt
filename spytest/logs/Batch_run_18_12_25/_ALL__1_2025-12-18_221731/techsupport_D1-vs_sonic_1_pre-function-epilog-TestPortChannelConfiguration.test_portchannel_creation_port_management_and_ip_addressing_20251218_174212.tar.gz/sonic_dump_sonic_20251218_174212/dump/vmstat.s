      3840620 K total memory
      2664736 K used memory
       409664 K active memory
      2602524 K inactive memory
       291524 K free memory
        58436 K buffer memory
      1101112 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       248383 non-nice user cpu ticks
        18311 nice user cpu ticks
        98425 system cpu ticks
       860753 idle cpu ticks
          277 IO-wait cpu ticks
            0 IRQ cpu ticks
         9455 softirq cpu ticks
          158 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1028198 K paged in
       269773 K paged out
            0 pages swapped in
            0 pages swapped out
      6204723 interrupts
     28398972 CPU context switches
   1766067245 boot time
        76078 forks
