      3840620 K total memory
      2663228 K used memory
       427072 K active memory
      2587136 K inactive memory
       293552 K free memory
        70416 K buffer memory
      1089628 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       322854 non-nice user cpu ticks
        27861 nice user cpu ticks
       129596 system cpu ticks
      1078158 idle cpu ticks
          366 IO-wait cpu ticks
            0 IRQ cpu ticks
        12034 softirq cpu ticks
          200 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1111887 K paged in
       396513 K paged out
            0 pages swapped in
            0 pages swapped out
      8078599 interrupts
     36887005 CPU context switches
   1766067245 boot time
       109398 forks
