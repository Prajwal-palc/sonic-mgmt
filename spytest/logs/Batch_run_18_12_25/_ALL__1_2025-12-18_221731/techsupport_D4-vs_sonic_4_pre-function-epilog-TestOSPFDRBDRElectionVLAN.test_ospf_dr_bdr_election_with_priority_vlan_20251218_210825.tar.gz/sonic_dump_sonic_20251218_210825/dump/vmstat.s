      3840632 K total memory
      2679520 K used memory
       479168 K active memory
      2473388 K inactive memory
       352656 K free memory
       106708 K buffer memory
       992168 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       526778 non-nice user cpu ticks
        56885 nice user cpu ticks
       209443 system cpu ticks
      1646154 idle cpu ticks
          778 IO-wait cpu ticks
            0 IRQ cpu ticks
        18583 softirq cpu ticks
          267 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1376050 K paged in
       798109 K paged out
            0 pages swapped in
            0 pages swapped out
     13080274 interrupts
     59828529 CPU context switches
   1766067245 boot time
       206192 forks
