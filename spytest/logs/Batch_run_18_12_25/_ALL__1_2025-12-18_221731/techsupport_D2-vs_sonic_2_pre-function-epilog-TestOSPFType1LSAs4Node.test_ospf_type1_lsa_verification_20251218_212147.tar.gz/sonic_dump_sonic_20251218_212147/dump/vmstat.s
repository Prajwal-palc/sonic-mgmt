      3840632 K total memory
      2646716 K used memory
       496788 K active memory
      2500104 K inactive memory
       315776 K free memory
       107256 K buffer memory
      1056456 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       548807 non-nice user cpu ticks
        62957 nice user cpu ticks
       225770 system cpu ticks
      1677515 idle cpu ticks
          764 IO-wait cpu ticks
            0 IRQ cpu ticks
        19774 softirq cpu ticks
          312 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1314410 K paged in
       842497 K paged out
            0 pages swapped in
            0 pages swapped out
     13995455 interrupts
     63006355 CPU context switches
   1766067251 boot time
       220720 forks
