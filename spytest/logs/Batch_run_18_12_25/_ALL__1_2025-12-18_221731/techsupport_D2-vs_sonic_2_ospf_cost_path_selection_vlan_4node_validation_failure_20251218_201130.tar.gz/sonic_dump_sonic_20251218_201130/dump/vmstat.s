      3840632 K total memory
      2649828 K used memory
       470188 K active memory
      2544132 K inactive memory
       289956 K free memory
        94544 K buffer memory
      1089928 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       453251 non-nice user cpu ticks
        45824 nice user cpu ticks
       182079 system cpu ticks
      1420587 idle cpu ticks
          631 IO-wait cpu ticks
            0 IRQ cpu ticks
        16395 softirq cpu ticks
          262 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1213313 K paged in
       636985 K paged out
            0 pages swapped in
            0 pages swapped out
     11517824 interrupts
     51618195 CPU context switches
   1766067251 boot time
       166920 forks
