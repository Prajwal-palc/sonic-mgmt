      3840632 K total memory
      2693340 K used memory
       491784 K active memory
      2530000 K inactive memory
       282172 K free memory
       104644 K buffer memory
      1051488 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       531468 non-nice user cpu ticks
        57942 nice user cpu ticks
       216463 system cpu ticks
      1630055 idle cpu ticks
          732 IO-wait cpu ticks
            0 IRQ cpu ticks
        19124 softirq cpu ticks
          302 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1289876 K paged in
       788309 K paged out
            0 pages swapped in
            0 pages swapped out
     13490256 interrupts
     60707715 CPU context switches
   1766067251 boot time
       207333 forks
