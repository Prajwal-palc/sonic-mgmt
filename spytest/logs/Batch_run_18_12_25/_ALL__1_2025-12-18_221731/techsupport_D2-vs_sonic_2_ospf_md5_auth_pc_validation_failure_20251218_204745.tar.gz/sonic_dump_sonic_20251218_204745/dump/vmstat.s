      3840632 K total memory
      2663376 K used memory
       481908 K active memory
      2535580 K inactive memory
       275420 K free memory
       100664 K buffer memory
      1085724 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       504210 non-nice user cpu ticks
        50622 nice user cpu ticks
       202364 system cpu ticks
      1557696 idle cpu ticks
          689 IO-wait cpu ticks
            0 IRQ cpu ticks
        18129 softirq cpu ticks
          286 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1243733 K paged in
       713505 K paged out
            0 pages swapped in
            0 pages swapped out
     12724150 interrupts
     57245565 CPU context switches
   1766067251 boot time
       187252 forks
