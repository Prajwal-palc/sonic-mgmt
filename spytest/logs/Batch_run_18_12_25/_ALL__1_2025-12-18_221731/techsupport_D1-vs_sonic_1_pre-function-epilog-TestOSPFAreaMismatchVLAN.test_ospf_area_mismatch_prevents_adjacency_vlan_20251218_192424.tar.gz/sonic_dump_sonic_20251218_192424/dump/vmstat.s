      3840620 K total memory
      2675720 K used memory
       454508 K active memory
      2565376 K inactive memory
       280172 K free memory
        80468 K buffer memory
      1084520 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       385370 non-nice user cpu ticks
        39676 nice user cpu ticks
       157616 system cpu ticks
      1244001 idle cpu ticks
          437 IO-wait cpu ticks
            0 IRQ cpu ticks
        14097 softirq cpu ticks
          232 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1186115 K paged in
       530509 K paged out
            0 pages swapped in
            0 pages swapped out
      9663107 interrupts
     44103926 CPU context switches
   1766067245 boot time
       145734 forks
