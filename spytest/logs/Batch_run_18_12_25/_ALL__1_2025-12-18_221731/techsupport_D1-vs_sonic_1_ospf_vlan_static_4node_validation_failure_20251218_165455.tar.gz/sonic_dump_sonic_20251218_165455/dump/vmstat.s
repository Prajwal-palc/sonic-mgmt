      3840620 K total memory
      2671316 K used memory
       402304 K active memory
      2607276 K inactive memory
       286964 K free memory
        50532 K buffer memory
      1104816 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       186137 non-nice user cpu ticks
         6525 nice user cpu ticks
        69643 system cpu ticks
       686039 idle cpu ticks
          218 IO-wait cpu ticks
            0 IRQ cpu ticks
         7304 softirq cpu ticks
          125 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       957984 K paged in
       145229 K paged out
            0 pages swapped in
            0 pages swapped out
      4566603 interrupts
     20965341 CPU context switches
   1766067245 boot time
        38815 forks
