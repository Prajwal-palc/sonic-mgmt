      3840632 K total memory
      2641936 K used memory
       488140 K active memory
      2488356 K inactive memory
       336292 K free memory
       104164 K buffer memory
      1043216 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       528495 non-nice user cpu ticks
        55547 nice user cpu ticks
       213811 system cpu ticks
      1623390 idle cpu ticks
          728 IO-wait cpu ticks
            0 IRQ cpu ticks
        19001 softirq cpu ticks
          300 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1277446 K paged in
       768629 K paged out
            0 pages swapped in
            0 pages swapped out
     13368568 interrupts
     60138883 CPU context switches
   1766067251 boot time
       201441 forks
