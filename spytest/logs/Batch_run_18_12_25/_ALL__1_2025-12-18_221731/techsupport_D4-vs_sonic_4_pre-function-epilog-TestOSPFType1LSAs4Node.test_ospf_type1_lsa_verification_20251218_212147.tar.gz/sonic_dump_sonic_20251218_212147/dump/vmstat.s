      3840632 K total memory
      2658800 K used memory
       473672 K active memory
      2448440 K inactive memory
       399004 K free memory
       109368 K buffer memory
       957976 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       543669 non-nice user cpu ticks
        61522 nice user cpu ticks
       218219 system cpu ticks
      1694413 idle cpu ticks
          808 IO-wait cpu ticks
            0 IRQ cpu ticks
        19203 softirq cpu ticks
          276 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1405952 K paged in
       854897 K paged out
            0 pages swapped in
            0 pages swapped out
     13566296 interrupts
     62071019 CPU context switches
   1766067245 boot time
       219574 forks
