      3840620 K total memory
      2659768 K used memory
       400992 K active memory
      2590172 K inactive memory
       303140 K free memory
        49312 K buffer memory
      1109516 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       184535 non-nice user cpu ticks
         6473 nice user cpu ticks
        65943 system cpu ticks
       707831 idle cpu ticks
          238 IO-wait cpu ticks
            0 IRQ cpu ticks
         6650 softirq cpu ticks
          102 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       953242 K paged in
       140509 K paged out
            0 pages swapped in
            0 pages swapped out
      4666594 interrupts
     21144618 CPU context switches
   1766067252 boot time
        38038 forks
