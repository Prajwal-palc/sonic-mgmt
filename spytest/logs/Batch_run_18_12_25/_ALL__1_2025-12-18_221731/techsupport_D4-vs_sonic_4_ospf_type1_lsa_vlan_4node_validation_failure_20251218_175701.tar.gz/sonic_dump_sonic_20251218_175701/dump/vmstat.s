      3840632 K total memory
      2635436 K used memory
       428068 K active memory
      2577304 K inactive memory
       329720 K free memory
        66428 K buffer memory
      1082320 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       266090 non-nice user cpu ticks
        20958 nice user cpu ticks
       101389 system cpu ticks
       926056 idle cpu ticks
          378 IO-wait cpu ticks
            0 IRQ cpu ticks
         9626 softirq cpu ticks
          137 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1065662 K paged in
       318949 K paged out
            0 pages swapped in
            0 pages swapped out
      6667820 interrupts
     30442846 CPU context switches
   1766067245 boot time
        84293 forks
