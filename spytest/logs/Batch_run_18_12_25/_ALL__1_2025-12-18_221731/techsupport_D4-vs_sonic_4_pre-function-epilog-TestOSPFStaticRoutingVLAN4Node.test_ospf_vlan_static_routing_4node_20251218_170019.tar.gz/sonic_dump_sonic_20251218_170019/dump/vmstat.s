      3840632 K total memory
      2661000 K used memory
       405976 K active memory
      2605032 K inactive memory
       295976 K free memory
        54036 K buffer memory
      1101996 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       189625 non-nice user cpu ticks
         8988 nice user cpu ticks
        69161 system cpu ticks
       713608 idle cpu ticks
          265 IO-wait cpu ticks
            0 IRQ cpu ticks
         7081 softirq cpu ticks
          102 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       966432 K paged in
       176909 K paged out
            0 pages swapped in
            0 pages swapped out
      4765533 interrupts
     21758897 CPU context switches
   1766067245 boot time
        45076 forks
