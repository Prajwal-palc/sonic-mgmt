      3840620 K total memory
      2664764 K used memory
       428148 K active memory
      2583932 K inactive memory
       287740 K free memory
        68936 K buffer memory
      1093164 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       320633 non-nice user cpu ticks
        30545 nice user cpu ticks
       126003 system cpu ticks
      1114754 idle cpu ticks
          396 IO-wait cpu ticks
            0 IRQ cpu ticks
        11193 softirq cpu ticks
          171 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1092896 K paged in
       409849 K paged out
            0 pages swapped in
            0 pages swapped out
      8277528 interrupts
     37516874 CPU context switches
   1766067252 boot time
       112223 forks
