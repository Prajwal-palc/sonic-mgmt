      3840620 K total memory
      2672216 K used memory
       485288 K active memory
      2513684 K inactive memory
       294920 K free memory
        95808 K buffer memory
      1062268 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       511515 non-nice user cpu ticks
        54844 nice user cpu ticks
       206332 system cpu ticks
      1728380 idle cpu ticks
          667 IO-wait cpu ticks
            0 IRQ cpu ticks
        17830 softirq cpu ticks
          286 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1260493 K paged in
       729361 K paged out
            0 pages swapped in
            0 pages swapped out
     13255665 interrupts
     60038601 CPU context switches
   1766067252 boot time
       191511 forks
