      3840620 K total memory
      2622132 K used memory
       407068 K active memory
      2593900 K inactive memory
       325464 K free memory
        52184 K buffer memory
      1114084 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       203797 non-nice user cpu ticks
        11219 nice user cpu ticks
        75559 system cpu ticks
       764752 idle cpu ticks
          261 IO-wait cpu ticks
            0 IRQ cpu ticks
         7320 softirq cpu ticks
          113 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       974920 K paged in
       186737 K paged out
            0 pages swapped in
            0 pages swapped out
      5212766 interrupts
     23621379 CPU context switches
   1766067252 boot time
        51850 forks
