      3840620 K total memory
      2656760 K used memory
       427044 K active memory
      2587000 K inactive memory
       285168 K free memory
        68328 K buffer memory
      1106280 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       317202 non-nice user cpu ticks
        28091 nice user cpu ticks
       123171 system cpu ticks
      1107565 idle cpu ticks
          394 IO-wait cpu ticks
            0 IRQ cpu ticks
        11080 softirq cpu ticks
          169 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1077086 K paged in
       386881 K paged out
            0 pages swapped in
            0 pages swapped out
      8145892 interrupts
     36903595 CPU context switches
   1766067252 boot time
       106122 forks
