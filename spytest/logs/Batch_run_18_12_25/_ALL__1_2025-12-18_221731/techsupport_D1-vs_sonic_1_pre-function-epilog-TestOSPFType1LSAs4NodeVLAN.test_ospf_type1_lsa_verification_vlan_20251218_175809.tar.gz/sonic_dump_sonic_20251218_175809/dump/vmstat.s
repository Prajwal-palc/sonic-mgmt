      3840620 K total memory
      2653836 K used memory
       415608 K active memory
      2596408 K inactive memory
       305932 K free memory
        61180 K buffer memory
      1095260 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       268908 non-nice user cpu ticks
        23095 nice user cpu ticks
       108478 system cpu ticks
       919577 idle cpu ticks
          295 IO-wait cpu ticks
            0 IRQ cpu ticks
        10207 softirq cpu ticks
          170 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1074000 K paged in
       316933 K paged out
            0 pages swapped in
            0 pages swapped out
      6769432 interrupts
     30974067 CPU context switches
   1766067245 boot time
        90017 forks
