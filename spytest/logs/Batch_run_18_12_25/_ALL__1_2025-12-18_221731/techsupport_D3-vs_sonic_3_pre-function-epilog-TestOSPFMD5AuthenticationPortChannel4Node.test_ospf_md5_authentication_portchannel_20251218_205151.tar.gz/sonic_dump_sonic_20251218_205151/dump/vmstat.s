      3840620 K total memory
      2642356 K used memory
       466272 K active memory
      2512152 K inactive memory
       344556 K free memory
        90984 K buffer memory
      1046288 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       479571 non-nice user cpu ticks
        50049 nice user cpu ticks
       192257 system cpu ticks
      1618984 idle cpu ticks
          614 IO-wait cpu ticks
            0 IRQ cpu ticks
        16654 softirq cpu ticks
          264 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1228440 K paged in
       672269 K paged out
            0 pages swapped in
            0 pages swapped out
     12379829 interrupts
     56083044 CPU context switches
   1766067252 boot time
       176775 forks
