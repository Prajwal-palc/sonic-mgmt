      3840620 K total memory
      2688580 K used memory
       461004 K active memory
      2519636 K inactive memory
       317660 K free memory
        94712 K buffer memory
      1025548 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       492384 non-nice user cpu ticks
        49188 nice user cpu ticks
       201142 system cpu ticks
      1597068 idle cpu ticks
          597 IO-wait cpu ticks
            0 IRQ cpu ticks
        18162 softirq cpu ticks
          298 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1305708 K paged in
       680269 K paged out
            0 pages swapped in
            0 pages swapped out
     12394896 interrupts
     56516675 CPU context switches
   1766067245 boot time
       183119 forks
