      3840620 K total memory
      2634644 K used memory
       436000 K active memory
      2567996 K inactive memory
       320080 K free memory
        72304 K buffer memory
      1093236 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       341175 non-nice user cpu ticks
        33013 nice user cpu ticks
       134464 system cpu ticks
      1175145 idle cpu ticks
          423 IO-wait cpu ticks
            0 IRQ cpu ticks
        11869 softirq cpu ticks
          182 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1114600 K paged in
       442561 K paged out
            0 pages swapped in
            0 pages swapped out
      8790497 interrupts
     39806065 CPU context switches
   1766067252 boot time
       120366 forks
