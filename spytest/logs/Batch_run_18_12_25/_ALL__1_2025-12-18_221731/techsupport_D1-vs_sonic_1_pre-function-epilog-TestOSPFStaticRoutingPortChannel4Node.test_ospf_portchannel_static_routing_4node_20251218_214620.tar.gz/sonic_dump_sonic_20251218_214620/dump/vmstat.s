      3840620 K total memory
      2621112 K used memory
       496484 K active memory
      2433664 K inactive memory
       372276 K free memory
       104220 K buffer memory
      1036928 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       559739 non-nice user cpu ticks
        61114 nice user cpu ticks
       233212 system cpu ticks
      1805376 idle cpu ticks
          704 IO-wait cpu ticks
            0 IRQ cpu ticks
        20617 softirq cpu ticks
          343 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1371519 K paged in
       821741 K paged out
            0 pages swapped in
            0 pages swapped out
     14211388 interrupts
     64799116 CPU context switches
   1766067245 boot time
       220055 forks
