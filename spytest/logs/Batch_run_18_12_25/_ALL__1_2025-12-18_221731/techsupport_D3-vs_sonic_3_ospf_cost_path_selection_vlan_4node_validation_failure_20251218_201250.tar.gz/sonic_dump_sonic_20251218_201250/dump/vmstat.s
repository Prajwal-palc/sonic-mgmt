      3840620 K total memory
      2582936 K used memory
       468760 K active memory
      2474584 K inactive memory
       357180 K free memory
        85036 K buffer memory
      1096944 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       429287 non-nice user cpu ticks
        42712 nice user cpu ticks
       170357 system cpu ticks
      1469416 idle cpu ticks
          547 IO-wait cpu ticks
            0 IRQ cpu ticks
        14965 softirq cpu ticks
          234 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1171091 K paged in
       575117 K paged out
            0 pages swapped in
            0 pages swapped out
     11080439 interrupts
     50116774 CPU context switches
   1766067252 boot time
       152962 forks
