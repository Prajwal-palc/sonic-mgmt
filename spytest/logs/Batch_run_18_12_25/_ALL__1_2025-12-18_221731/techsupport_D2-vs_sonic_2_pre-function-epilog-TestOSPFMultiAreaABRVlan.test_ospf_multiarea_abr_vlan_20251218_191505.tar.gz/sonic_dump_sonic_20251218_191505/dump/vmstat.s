      3840632 K total memory
      2702180 K used memory
       454044 K active memory
      2625148 K inactive memory
       232352 K free memory
        83668 K buffer memory
      1102468 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       379000 non-nice user cpu ticks
        38590 nice user cpu ticks
       152866 system cpu ticks
      1200915 idle cpu ticks
          518 IO-wait cpu ticks
            0 IRQ cpu ticks
        13703 softirq cpu ticks
          223 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1167994 K paged in
       524841 K paged out
            0 pages swapped in
            0 pages swapped out
      9672176 interrupts
     43325914 CPU context switches
   1766067251 boot time
       139981 forks
