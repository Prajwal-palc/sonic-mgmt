      3840620 K total memory
      2640584 K used memory
       408352 K active memory
      2600624 K inactive memory
       301340 K free memory
        53992 K buffer memory
      1121128 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       214649 non-nice user cpu ticks
        15973 nice user cpu ticks
        82336 system cpu ticks
       793157 idle cpu ticks
          273 IO-wait cpu ticks
            0 IRQ cpu ticks
         7691 softirq cpu ticks
          118 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       989641 K paged in
       227121 K paged out
            0 pages swapped in
            0 pages swapped out
      5566473 interrupts
     25241528 CPU context switches
   1766067252 boot time
        64589 forks
