      3840632 K total memory
      2666692 K used memory
       478336 K active memory
      2467708 K inactive memory
       370064 K free memory
       106420 K buffer memory
       987720 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       524960 non-nice user cpu ticks
        54560 nice user cpu ticks
       207253 system cpu ticks
      1645420 idle cpu ticks
          777 IO-wait cpu ticks
            0 IRQ cpu ticks
        18520 softirq cpu ticks
          266 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1370014 K paged in
       777725 K paged out
            0 pages swapped in
            0 pages swapped out
     12994404 interrupts
     59420579 CPU context switches
   1766067245 boot time
       200307 forks
