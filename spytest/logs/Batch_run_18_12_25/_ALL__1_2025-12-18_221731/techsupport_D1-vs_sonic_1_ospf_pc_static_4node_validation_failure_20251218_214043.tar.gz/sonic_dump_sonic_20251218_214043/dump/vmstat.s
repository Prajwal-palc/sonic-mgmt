      3840620 K total memory
      2635848 K used memory
       494324 K active memory
      2425628 K inactive memory
       362360 K free memory
       103452 K buffer memory
      1029728 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       553610 non-nice user cpu ticks
        58736 nice user cpu ticks
       229335 system cpu ticks
      1784987 idle cpu ticks
          697 IO-wait cpu ticks
            0 IRQ cpu ticks
        20381 softirq cpu ticks
          339 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1364829 K paged in
       802625 K paged out
            0 pages swapped in
            0 pages swapped out
     14011318 interrupts
     63862484 CPU context switches
   1766067245 boot time
       213828 forks
