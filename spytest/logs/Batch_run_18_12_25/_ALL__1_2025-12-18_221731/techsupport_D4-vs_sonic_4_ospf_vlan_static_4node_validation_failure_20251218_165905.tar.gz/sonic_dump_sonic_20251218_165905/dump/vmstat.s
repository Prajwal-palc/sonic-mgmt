      3840632 K total memory
      2637024 K used memory
       404852 K active memory
      2610108 K inactive memory
       314080 K free memory
        54048 K buffer memory
      1108352 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       187909 non-nice user cpu ticks
         6578 nice user cpu ticks
        66978 system cpu ticks
       712725 idle cpu ticks
          262 IO-wait cpu ticks
            0 IRQ cpu ticks
         7026 softirq cpu ticks
          101 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       955926 K paged in
       158877 K paged out
            0 pages swapped in
            0 pages swapped out
      4677091 interrupts
     21344140 CPU context switches
   1766067245 boot time
        39153 forks
