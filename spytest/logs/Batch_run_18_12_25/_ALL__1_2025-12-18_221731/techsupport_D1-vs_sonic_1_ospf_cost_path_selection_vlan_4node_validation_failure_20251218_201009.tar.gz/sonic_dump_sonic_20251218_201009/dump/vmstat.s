      3840620 K total memory
      2606888 K used memory
       478096 K active memory
      2481428 K inactive memory
       345372 K free memory
        88424 K buffer memory
      1082016 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       439978 non-nice user cpu ticks
        42018 nice user cpu ticks
       178107 system cpu ticks
      1434467 idle cpu ticks
          514 IO-wait cpu ticks
            0 IRQ cpu ticks
        16197 softirq cpu ticks
          266 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1208476 K paged in
       586901 K paged out
            0 pages swapped in
            0 pages swapped out
     11023060 interrupts
     50209719 CPU context switches
   1766067245 boot time
       158257 forks
