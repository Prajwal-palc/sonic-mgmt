      3840620 K total memory
      2657252 K used memory
       414744 K active memory
      2591564 K inactive memory
       294212 K free memory
        59540 K buffer memory
      1104964 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       260944 non-nice user cpu ticks
        23207 nice user cpu ticks
       101830 system cpu ticks
       934507 idle cpu ticks
          320 IO-wait cpu ticks
            0 IRQ cpu ticks
         9247 softirq cpu ticks
          140 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1048326 K paged in
       313149 K paged out
            0 pages swapped in
            0 pages swapped out
      6771519 interrupts
     30693740 CPU context switches
   1766067252 boot time
        87351 forks
