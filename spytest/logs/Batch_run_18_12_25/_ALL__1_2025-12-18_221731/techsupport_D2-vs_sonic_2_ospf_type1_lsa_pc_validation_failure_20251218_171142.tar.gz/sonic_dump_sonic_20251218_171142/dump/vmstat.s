      3840632 K total memory
      2642948 K used memory
       408356 K active memory
      2592132 K inactive memory
       300228 K free memory
        55504 K buffer memory
      1115188 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       207212 non-nice user cpu ticks
        11644 nice user cpu ticks
        79235 system cpu ticks
       747904 idle cpu ticks
          285 IO-wait cpu ticks
            0 IRQ cpu ticks
         7926 softirq cpu ticks
          136 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       976730 K paged in
       195605 K paged out
            0 pages swapped in
            0 pages swapped out
      5330918 interrupts
     23818780 CPU context switches
   1766067251 boot time
        52796 forks
