      3840620 K total memory
      2601136 K used memory
       500268 K active memory
      2454808 K inactive memory
       341420 K free memory
       101180 K buffer memory
      1086172 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       545911 non-nice user cpu ticks
        62145 nice user cpu ticks
       222874 system cpu ticks
      1829759 idle cpu ticks
          720 IO-wait cpu ticks
            0 IRQ cpu ticks
        19011 softirq cpu ticks
          312 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1293516 K paged in
       816077 K paged out
            0 pages swapped in
            0 pages swapped out
     14214696 interrupts
     64399541 CPU context switches
   1766067252 boot time
       213073 forks
