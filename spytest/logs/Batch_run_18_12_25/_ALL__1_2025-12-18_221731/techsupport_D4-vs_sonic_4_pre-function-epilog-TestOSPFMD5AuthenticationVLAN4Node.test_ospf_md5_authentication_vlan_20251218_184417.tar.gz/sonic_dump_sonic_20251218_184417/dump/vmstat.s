      3840632 K total memory
      2682892 K used memory
       451456 K active memory
      2564948 K inactive memory
       272604 K free memory
        77780 K buffer memory
      1086724 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       333192 non-nice user cpu ticks
        30628 nice user cpu ticks
       129160 system cpu ticks
      1099928 idle cpu ticks
          469 IO-wait cpu ticks
            0 IRQ cpu ticks
        11859 softirq cpu ticks
          167 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1156046 K paged in
       441901 K paged out
            0 pages swapped in
            0 pages swapped out
      8295264 interrupts
     37853423 CPU context switches
   1766067245 boot time
       116926 forks
