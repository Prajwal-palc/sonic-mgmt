      3840620 K total memory
      2659948 K used memory
       403172 K active memory
      2606572 K inactive memory
       296976 K free memory
        51056 K buffer memory
      1105808 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       192175 non-nice user cpu ticks
         8842 nice user cpu ticks
        73325 system cpu ticks
       705695 idle cpu ticks
          222 IO-wait cpu ticks
            0 IRQ cpu ticks
         7560 softirq cpu ticks
          127 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       965798 K paged in
       162577 K paged out
            0 pages swapped in
            0 pages swapped out
      4760361 interrupts
     21877412 CPU context switches
   1766067245 boot time
        45119 forks
