      3840632 K total memory
      2631736 K used memory
       424408 K active memory
      2584268 K inactive memory
       309444 K free memory
        65064 K buffer memory
      1109936 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       271603 non-nice user cpu ticks
        23768 nice user cpu ticks
       107977 system cpu ticks
       915891 idle cpu ticks
          372 IO-wait cpu ticks
            0 IRQ cpu ticks
        10066 softirq cpu ticks
          165 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1053926 K paged in
       334781 K paged out
            0 pages swapped in
            0 pages swapped out
      7005767 interrupts
     31340932 CPU context switches
   1766067251 boot time
        90700 forks
