      3840632 K total memory
      2645924 K used memory
       404092 K active memory
      2594020 K inactive memory
       302312 K free memory
        52380 K buffer memory
      1112916 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       187742 non-nice user cpu ticks
         6798 nice user cpu ticks
        69430 system cpu ticks
       691874 idle cpu ticks
          258 IO-wait cpu ticks
            0 IRQ cpu ticks
         7230 softirq cpu ticks
          125 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       954755 K paged in
       152525 K paged out
            0 pages swapped in
            0 pages swapped out
      4770114 interrupts
     21291660 CPU context switches
   1766067251 boot time
        38736 forks
