      3840632 K total memory
      2655252 K used memory
       474564 K active memory
      2463076 K inactive memory
       389656 K free memory
       103460 K buffer memory
       982288 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       505821 non-nice user cpu ticks
        52334 nice user cpu ticks
       199379 system cpu ticks
      1584145 idle cpu ticks
          746 IO-wait cpu ticks
            0 IRQ cpu ticks
        17826 softirq cpu ticks
          255 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1359510 K paged in
       743945 K paged out
            0 pages swapped in
            0 pages swapped out
     12507576 interrupts
     57187652 CPU context switches
   1766067245 boot time
       192483 forks
