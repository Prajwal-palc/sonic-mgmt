      3840632 K total memory
      2652888 K used memory
       469424 K active memory
      2548008 K inactive memory
       309348 K free memory
        87312 K buffer memory
      1071508 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       387436 non-nice user cpu ticks
        42620 nice user cpu ticks
       154117 system cpu ticks
      1244388 idle cpu ticks
          544 IO-wait cpu ticks
            0 IRQ cpu ticks
        13682 softirq cpu ticks
          194 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1219766 K paged in
       576669 K paged out
            0 pages swapped in
            0 pages swapped out
      9710351 interrupts
     44334069 CPU context switches
   1766067245 boot time
       152303 forks
