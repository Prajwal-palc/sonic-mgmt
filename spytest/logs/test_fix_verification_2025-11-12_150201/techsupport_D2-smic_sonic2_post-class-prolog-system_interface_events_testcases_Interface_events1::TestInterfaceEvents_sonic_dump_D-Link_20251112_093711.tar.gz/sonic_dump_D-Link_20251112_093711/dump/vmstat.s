      3845316 K total memory
      2872920 K used memory
       319528 K active memory
      2517956 K inactive memory
       272480 K free memory
       100304 K buffer memory
       599612 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6722119 non-nice user cpu ticks
        23686 nice user cpu ticks
      2974152 system cpu ticks
     47480206 idle cpu ticks
        16004 IO-wait cpu ticks
            0 IRQ cpu ticks
        72966 softirq cpu ticks
        44377 stolen cpu ticks
      3576034 pages paged in
      9998384 pages paged out
            0 pages swapped in
            0 pages swapped out
    737850796 interrupts
   1739396686 CPU context switches
   1762339277 boot time
       989103 forks
