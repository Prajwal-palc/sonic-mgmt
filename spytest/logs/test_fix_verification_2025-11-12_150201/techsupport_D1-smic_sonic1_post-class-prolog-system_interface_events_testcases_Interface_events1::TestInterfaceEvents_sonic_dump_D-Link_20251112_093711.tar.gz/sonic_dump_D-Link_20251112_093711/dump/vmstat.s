      3845316 K total memory
      2786156 K used memory
       330488 K active memory
      2384568 K inactive memory
       381300 K free memory
        68532 K buffer memory
       609328 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6729724 non-nice user cpu ticks
        23434 nice user cpu ticks
      3018228 system cpu ticks
     47303171 idle cpu ticks
        14929 IO-wait cpu ticks
            0 IRQ cpu ticks
        73607 softirq cpu ticks
        43679 stolen cpu ticks
      3556881 pages paged in
      9863972 pages paged out
            0 pages swapped in
            0 pages swapped out
    746404787 interrupts
   1759666943 CPU context switches
   1762341321 boot time
       994163 forks
