      3845316 K total memory
      2798116 K used memory
       318072 K active memory
      2516896 K inactive memory
       319848 K free memory
       108944 K buffer memory
       618408 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6609046 non-nice user cpu ticks
        15602 nice user cpu ticks
      2959568 system cpu ticks
     46574848 idle cpu ticks
        14692 IO-wait cpu ticks
            0 IRQ cpu ticks
        72341 softirq cpu ticks
        42953 stolen cpu ticks
      3425639 pages paged in
      9626516 pages paged out
            0 pages swapped in
            0 pages swapped out
    734444395 interrupts
   1730221937 CPU context switches
   1762341321 boot time
       956183 forks
