      3845316 K total memory
      2805216 K used memory
       312088 K active memory
      2507428 K inactive memory
       315228 K free memory
       125360 K buffer memory
       599512 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6691928 non-nice user cpu ticks
        17877 nice user cpu ticks
      2956949 system cpu ticks
     47311478 idle cpu ticks
        15942 IO-wait cpu ticks
            0 IRQ cpu ticks
        72646 softirq cpu ticks
        44210 stolen cpu ticks
      3526963 pages paged in
      9905652 pages paged out
            0 pages swapped in
            0 pages swapped out
    734917654 interrupts
   1731850809 CPU context switches
   1762339277 boot time
       971312 forks
