      3845316 K total memory
      2770532 K used memory
       321856 K active memory
      2526396 K inactive memory
       317300 K free memory
       144220 K buffer memory
       613264 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6608914 non-nice user cpu ticks
        15963 nice user cpu ticks
      2918277 system cpu ticks
     46743626 idle cpu ticks
        15778 IO-wait cpu ticks
            0 IRQ cpu ticks
        71761 softirq cpu ticks
        43676 stolen cpu ticks
      3464122 pages paged in
      9763696 pages paged out
            0 pages swapped in
            0 pages swapped out
    725875019 interrupts
   1710124194 CPU context switches
   1762339277 boot time
       953320 forks
