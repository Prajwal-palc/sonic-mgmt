      3845316 K total memory
      2761452 K used memory
       311804 K active memory
      2388072 K inactive memory
       417588 K free memory
        68692 K buffer memory
       597584 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6696896 non-nice user cpu ticks
        17554 nice user cpu ticks
      2999800 system cpu ticks
     47138155 idle cpu ticks
        14867 IO-wait cpu ticks
            0 IRQ cpu ticks
        73274 softirq cpu ticks
        43484 stolen cpu ticks
      3521902 pages paged in
      9768420 pages paged out
            0 pages swapped in
            0 pages swapped out
    743441668 interrupts
   1752020748 CPU context switches
   1762341321 boot time
       975604 forks
