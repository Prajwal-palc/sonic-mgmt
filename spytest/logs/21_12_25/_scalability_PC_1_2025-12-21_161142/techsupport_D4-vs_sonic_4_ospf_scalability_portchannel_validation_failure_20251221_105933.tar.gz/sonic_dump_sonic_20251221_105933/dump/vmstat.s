      3840632 K total memory
      2664172 K used memory
       367272 K active memory
      2636036 K inactive memory
       310076 K free memory
        42264 K buffer memory
      1092456 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        90248 non-nice user cpu ticks
         1733 nice user cpu ticks
        34552 system cpu ticks
       272377 idle cpu ticks
          141 IO-wait cpu ticks
            0 IRQ cpu ticks
         2968 softirq cpu ticks
           46 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       915414 K paged in
        93597 K paged out
            0 pages swapped in
            0 pages swapped out
      2073585 interrupts
      9347408 CPU context switches
   1766310746 boot time
        20892 forks
