      3840620 K total memory
      2743588 K used memory
       364268 K active memory
      2723500 K inactive memory
       243692 K free memory
        39828 K buffer memory
      1085156 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        83620 non-nice user cpu ticks
         1739 nice user cpu ticks
        32114 system cpu ticks
       260413 idle cpu ticks
          116 IO-wait cpu ticks
            0 IRQ cpu ticks
         2793 softirq cpu ticks
           41 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       932819 K paged in
        83697 K paged out
            0 pages swapped in
            0 pages swapped out
      1927185 interrupts
      8735312 CPU context switches
   1766310699 boot time
        19128 forks
