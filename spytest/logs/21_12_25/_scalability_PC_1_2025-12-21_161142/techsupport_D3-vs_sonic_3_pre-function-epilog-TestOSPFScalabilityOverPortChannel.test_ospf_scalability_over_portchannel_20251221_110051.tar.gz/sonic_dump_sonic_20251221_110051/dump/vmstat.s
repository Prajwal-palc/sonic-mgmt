      3840620 K total memory
      2624852 K used memory
       382020 K active memory
      2608876 K inactive memory
       340140 K free memory
        42764 K buffer memory
      1117268 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        89433 non-nice user cpu ticks
         4184 nice user cpu ticks
        36578 system cpu ticks
       275161 idle cpu ticks
          107 IO-wait cpu ticks
            0 IRQ cpu ticks
         2986 softirq cpu ticks
           48 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       925307 K paged in
       105169 K paged out
            0 pages swapped in
            0 pages swapped out
      2131447 interrupts
      9630779 CPU context switches
   1766310760 boot time
        25281 forks
