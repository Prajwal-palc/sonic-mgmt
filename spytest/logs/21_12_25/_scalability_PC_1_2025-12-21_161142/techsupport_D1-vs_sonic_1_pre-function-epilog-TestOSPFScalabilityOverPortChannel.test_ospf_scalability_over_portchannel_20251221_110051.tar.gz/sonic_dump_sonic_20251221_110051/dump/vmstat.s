      3840620 K total memory
      2646408 K used memory
       380384 K active memory
      2622152 K inactive memory
       314112 K free memory
        42388 K buffer memory
      1113336 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        90418 non-nice user cpu ticks
         4284 nice user cpu ticks
        36516 system cpu ticks
       280538 idle cpu ticks
          120 IO-wait cpu ticks
            0 IRQ cpu ticks
         3054 softirq cpu ticks
           46 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       951222 K paged in
       100785 K paged out
            0 pages swapped in
            0 pages swapped out
      2143580 interrupts
      9712451 CPU context switches
   1766310699 boot time
        25507 forks
