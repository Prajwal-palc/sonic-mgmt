      3840632 K total memory
      2626088 K used memory
       384244 K active memory
      2637664 K inactive memory
       329184 K free memory
        44356 K buffer memory
      1112148 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        91869 non-nice user cpu ticks
         4149 nice user cpu ticks
        36884 system cpu ticks
       273203 idle cpu ticks
          144 IO-wait cpu ticks
            0 IRQ cpu ticks
         3022 softirq cpu ticks
           47 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       936195 K paged in
       109477 K paged out
            0 pages swapped in
            0 pages swapped out
      2161926 interrupts
      9763485 CPU context switches
   1766310746 boot time
        26917 forks
