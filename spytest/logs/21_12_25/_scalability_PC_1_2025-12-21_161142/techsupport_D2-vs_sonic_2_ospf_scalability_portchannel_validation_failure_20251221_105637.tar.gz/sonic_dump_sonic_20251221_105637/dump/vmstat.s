      3840620 K total memory
      2646684 K used memory
       367156 K active memory
      2617076 K inactive memory
       329856 K free memory
        41348 K buffer memory
      1091320 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        89033 non-nice user cpu ticks
         1698 nice user cpu ticks
        34729 system cpu ticks
       259089 idle cpu ticks
          116 IO-wait cpu ticks
            0 IRQ cpu ticks
         2876 softirq cpu ticks
           60 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       917879 K paged in
        90941 K paged out
            0 pages swapped in
            0 pages swapped out
      2020196 interrupts
      9079863 CPU context switches
   1766310717 boot time
        20991 forks
