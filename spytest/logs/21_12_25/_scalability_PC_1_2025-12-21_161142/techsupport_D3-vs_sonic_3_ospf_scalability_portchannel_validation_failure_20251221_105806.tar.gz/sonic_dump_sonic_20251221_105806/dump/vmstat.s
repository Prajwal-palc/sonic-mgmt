      3840620 K total memory
      2617956 K used memory
       366300 K active memory
      2596812 K inactive memory
       373656 K free memory
        40524 K buffer memory
      1088996 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        85948 non-nice user cpu ticks
         1711 nice user cpu ticks
        33510 system cpu ticks
       267479 idle cpu ticks
          104 IO-wait cpu ticks
            0 IRQ cpu ticks
         2866 softirq cpu ticks
           46 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       907056 K paged in
        85837 K paged out
            0 pages swapped in
            0 pages swapped out
      1995185 interrupts
      9016871 CPU context switches
   1766310760 boot time
        19128 forks
