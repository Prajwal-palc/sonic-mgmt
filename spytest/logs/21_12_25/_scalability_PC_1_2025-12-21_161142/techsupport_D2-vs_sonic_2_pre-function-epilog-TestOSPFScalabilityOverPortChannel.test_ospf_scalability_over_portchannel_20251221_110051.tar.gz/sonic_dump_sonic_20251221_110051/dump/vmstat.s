      3840620 K total memory
      2635532 K used memory
       383812 K active memory
      2619824 K inactive memory
       318088 K free memory
        43836 K buffer memory
      1115648 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        93696 non-nice user cpu ticks
         4066 nice user cpu ticks
        38165 system cpu ticks
       272979 idle cpu ticks
          122 IO-wait cpu ticks
            0 IRQ cpu ticks
         3060 softirq cpu ticks
           65 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       938467 K paged in
       107581 K paged out
            0 pages swapped in
            0 pages swapped out
      2186660 interrupts
      9840166 CPU context switches
   1766310717 boot time
        27201 forks
