      3840632 K total memory
      2670688 K used memory
       400804 K active memory
      2626060 K inactive memory
       278228 K free memory
        48968 K buffer memory
      1116588 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       128573 non-nice user cpu ticks
         6550 nice user cpu ticks
        51439 system cpu ticks
       390309 idle cpu ticks
          173 IO-wait cpu ticks
            0 IRQ cpu ticks
         4317 softirq cpu ticks
           65 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       955133 K paged in
       150033 K paged out
            0 pages swapped in
            0 pages swapped out
      3051350 interrupts
     13754819 CPU context switches
   1766310745 boot time
        37428 forks
