      3840632 K total memory
      2633868 K used memory
       402392 K active memory
      2615752 K inactive memory
       330496 K free memory
        48972 K buffer memory
      1099488 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       130427 non-nice user cpu ticks
         8930 nice user cpu ticks
        53786 system cpu ticks
       391147 idle cpu ticks
          173 IO-wait cpu ticks
            0 IRQ cpu ticks
         4372 softirq cpu ticks
           66 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       969258 K paged in
       166801 K paged out
            0 pages swapped in
            0 pages swapped out
      3140890 interrupts
     14176681 CPU context switches
   1766310745 boot time
        43378 forks
