      3840620 K total memory
      2647736 K used memory
       397312 K active memory
      2609412 K inactive memory
       307648 K free memory
        45780 K buffer memory
      1117096 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       121031 non-nice user cpu ticks
         6713 nice user cpu ticks
        48742 system cpu ticks
       379251 idle cpu ticks
          141 IO-wait cpu ticks
            0 IRQ cpu ticks
         4218 softirq cpu ticks
           64 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       964533 K paged in
       135061 K paged out
            0 pages swapped in
            0 pages swapped out
      2906033 interrupts
     13128750 CPU context switches
   1766310698 boot time
        34983 forks
