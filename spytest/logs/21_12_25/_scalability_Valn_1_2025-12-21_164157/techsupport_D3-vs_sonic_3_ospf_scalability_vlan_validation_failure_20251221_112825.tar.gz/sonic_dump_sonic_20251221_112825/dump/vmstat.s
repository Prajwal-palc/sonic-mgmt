      3840620 K total memory
      2650528 K used memory
       398844 K active memory
      2601108 K inactive memory
       308532 K free memory
        46688 K buffer memory
      1120964 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       123680 non-nice user cpu ticks
         6649 nice user cpu ticks
        50419 system cpu ticks
       386351 idle cpu ticks
          130 IO-wait cpu ticks
            0 IRQ cpu ticks
         4237 softirq cpu ticks
           67 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       939075 K paged in
       139201 K paged out
            0 pages swapped in
            0 pages swapped out
      2984137 interrupts
     13405223 CPU context switches
   1766310760 boot time
        34994 forks
