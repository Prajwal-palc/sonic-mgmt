      3840620 K total memory
      2654328 K used memory
       399108 K active memory
      2606552 K inactive memory
       296808 K free memory
        46656 K buffer memory
      1116504 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       127479 non-nice user cpu ticks
         9128 nice user cpu ticks
        52748 system cpu ticks
       399354 idle cpu ticks
          145 IO-wait cpu ticks
            0 IRQ cpu ticks
         4477 softirq cpu ticks
           67 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       973443 K paged in
       152509 K paged out
            0 pages swapped in
            0 pages swapped out
      3110072 interrupts
     14078754 CPU context switches
   1766310698 boot time
        41244 forks
