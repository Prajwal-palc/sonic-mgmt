      3840620 K total memory
      2656336 K used memory
       400816 K active memory
      2608272 K inactive memory
       292852 K free memory
        48288 K buffer memory
      1117220 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       127249 non-nice user cpu ticks
         6517 nice user cpu ticks
        51618 system cpu ticks
       376869 idle cpu ticks
          149 IO-wait cpu ticks
            0 IRQ cpu ticks
         4276 softirq cpu ticks
           89 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       957118 K paged in
       146701 K paged out
            0 pages swapped in
            0 pages swapped out
      3005796 interrupts
     13518947 CPU context switches
   1766310716 boot time
        37577 forks
