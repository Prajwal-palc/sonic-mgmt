      3840620 K total memory
      2630460 K used memory
       401964 K active memory
      2605592 K inactive memory
       317180 K free memory
        48816 K buffer memory
      1118400 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       132223 non-nice user cpu ticks
         9046 nice user cpu ticks
        55454 system cpu ticks
       390596 idle cpu ticks
          154 IO-wait cpu ticks
            0 IRQ cpu ticks
         4466 softirq cpu ticks
           95 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       965136 K paged in
       168897 K paged out
            0 pages swapped in
            0 pages swapped out
      3180672 interrupts
     14301090 CPU context switches
   1766310716 boot time
        43660 forks
