      3840620 K total memory
      2616824 K used memory
       400956 K active memory
      2619464 K inactive memory
       330136 K free memory
        47224 K buffer memory
      1120368 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       127088 non-nice user cpu ticks
         9265 nice user cpu ticks
        53604 system cpu ticks
       393237 idle cpu ticks
          132 IO-wait cpu ticks
            0 IRQ cpu ticks
         4361 softirq cpu ticks
           70 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       948030 K paged in
       158277 K paged out
            0 pages swapped in
            0 pages swapped out
      3119247 interrupts
     14015085 CPU context switches
   1766310760 boot time
        40975 forks
