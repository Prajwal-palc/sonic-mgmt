      3845316 K total memory
      2602900 K used memory
       392700 K active memory
      2541592 K inactive memory
       323392 K free memory
        50252 K buffer memory
       868772 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        69320 non-nice user cpu ticks
         7216 nice user cpu ticks
        35455 system cpu ticks
       306421 idle cpu ticks
          302 IO-wait cpu ticks
            0 IRQ cpu ticks
          540 softirq cpu ticks
          276 stolen cpu ticks
       967357 pages paged in
       222344 pages paged out
            0 pages swapped in
            0 pages swapped out
      5522432 interrupts
     15409862 CPU context switches
   1763011716 boot time
        40594 forks
