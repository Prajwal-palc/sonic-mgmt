      3845316 K total memory
      2595388 K used memory
       374824 K active memory
      2560256 K inactive memory
       317480 K free memory
        49156 K buffer memory
       883292 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        66167 non-nice user cpu ticks
         6808 nice user cpu ticks
        33757 system cpu ticks
       311791 idle cpu ticks
          322 IO-wait cpu ticks
            0 IRQ cpu ticks
          583 softirq cpu ticks
          304 stolen cpu ticks
       942782 pages paged in
       224644 pages paged out
            0 pages swapped in
            0 pages swapped out
      5520154 interrupts
     15526880 CPU context switches
   1763011705 boot time
        40048 forks
