      3840632 K total memory
      2454300 K used memory
       349928 K active memory
      2438776 K inactive memory
       545724 K free memory
        33056 K buffer memory
      1074456 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        17717 non-nice user cpu ticks
         1668 nice user cpu ticks
         8246 system cpu ticks
        27928 idle cpu ticks
           65 IO-wait cpu ticks
            0 IRQ cpu ticks
          347 softirq cpu ticks
            6 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       889516 K paged in
        51733 K paged out
            0 pages swapped in
            0 pages swapped out
       369935 interrupts
      1803063 CPU context switches
   1766067246 boot time
        11245 forks
