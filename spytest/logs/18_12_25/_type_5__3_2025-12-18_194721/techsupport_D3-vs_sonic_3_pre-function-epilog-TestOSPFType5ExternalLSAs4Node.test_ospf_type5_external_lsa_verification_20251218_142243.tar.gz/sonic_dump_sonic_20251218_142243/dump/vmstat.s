      3840620 K total memory
      2436876 K used memory
       351252 K active memory
      2438408 K inactive memory
       564040 K free memory
        32740 K buffer memory
      1073964 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        17300 non-nice user cpu ticks
         1710 nice user cpu ticks
         8050 system cpu ticks
        27907 idle cpu ticks
          101 IO-wait cpu ticks
            0 IRQ cpu ticks
          340 softirq cpu ticks
            7 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       893601 K paged in
        47821 K paged out
            0 pages swapped in
            0 pages swapped out
       369720 interrupts
      1789315 CPU context switches
   1766067252 boot time
        11134 forks
