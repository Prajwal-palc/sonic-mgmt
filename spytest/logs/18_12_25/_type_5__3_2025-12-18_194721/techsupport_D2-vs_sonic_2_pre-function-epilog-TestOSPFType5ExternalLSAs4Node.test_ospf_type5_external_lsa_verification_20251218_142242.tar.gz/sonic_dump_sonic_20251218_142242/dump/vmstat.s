      3840632 K total memory
      2442664 K used memory
       350672 K active memory
      2424876 K inactive memory
       557636 K free memory
        32868 K buffer memory
      1074308 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        18524 non-nice user cpu ticks
         1747 nice user cpu ticks
         8634 system cpu ticks
        26201 idle cpu ticks
           63 IO-wait cpu ticks
            0 IRQ cpu ticks
          350 softirq cpu ticks
           10 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       896435 K paged in
        50713 K paged out
            0 pages swapped in
            0 pages swapped out
       384162 interrupts
      1807776 CPU context switches
   1766067252 boot time
        11214 forks
