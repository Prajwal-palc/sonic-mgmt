      3840620 K total memory
      2555848 K used memory
       352784 K active memory
      2527216 K inactive memory
       442848 K free memory
        33104 K buffer memory
      1076140 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        19015 non-nice user cpu ticks
         1710 nice user cpu ticks
         8701 system cpu ticks
        26252 idle cpu ticks
           84 IO-wait cpu ticks
            0 IRQ cpu ticks
          361 softirq cpu ticks
            7 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       892431 K paged in
        51621 K paged out
            0 pages swapped in
            0 pages swapped out
       388129 interrupts
      1873056 CPU context switches
   1766067246 boot time
        12021 forks
