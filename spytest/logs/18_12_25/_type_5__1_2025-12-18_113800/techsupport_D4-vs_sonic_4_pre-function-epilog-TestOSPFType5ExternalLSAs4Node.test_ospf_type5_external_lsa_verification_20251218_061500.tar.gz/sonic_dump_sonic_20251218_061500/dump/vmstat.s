      3840620 K total memory
      2653332 K used memory
       409256 K active memory
      2637444 K inactive memory
       277780 K free memory
        43116 K buffer memory
      1141356 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       105050 non-nice user cpu ticks
         1838 nice user cpu ticks
        38128 system cpu ticks
       316955 idle cpu ticks
           97 IO-wait cpu ticks
            0 IRQ cpu ticks
         3150 softirq cpu ticks
           58 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       905882 K paged in
       296800 K paged out
            0 pages swapped in
            0 pages swapped out
      2300020 interrupts
     10571094 CPU context switches
   1766033834 boot time
        25555 forks
