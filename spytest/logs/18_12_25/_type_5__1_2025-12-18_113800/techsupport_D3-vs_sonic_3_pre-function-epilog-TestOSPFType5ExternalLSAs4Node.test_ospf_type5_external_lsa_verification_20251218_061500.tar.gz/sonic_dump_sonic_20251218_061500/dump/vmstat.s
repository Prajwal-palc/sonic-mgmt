      3840620 K total memory
      2680412 K used memory
       405176 K active memory
      2640640 K inactive memory
       276036 K free memory
        42820 K buffer memory
      1115972 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       103357 non-nice user cpu ticks
         1761 nice user cpu ticks
        37475 system cpu ticks
       319682 idle cpu ticks
          112 IO-wait cpu ticks
            0 IRQ cpu ticks
         3281 softirq cpu ticks
           50 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       916795 K paged in
       298152 K paged out
            0 pages swapped in
            0 pages swapped out
      2254497 interrupts
     10454347 CPU context switches
   1766033831 boot time
        27433 forks
