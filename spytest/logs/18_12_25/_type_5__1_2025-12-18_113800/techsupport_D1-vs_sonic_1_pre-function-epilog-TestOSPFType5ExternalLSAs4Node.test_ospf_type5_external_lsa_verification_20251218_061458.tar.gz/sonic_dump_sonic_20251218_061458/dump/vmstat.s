      3840632 K total memory
      2674736 K used memory
       408904 K active memory
      2642856 K inactive memory
       266196 K free memory
        43360 K buffer memory
      1130848 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       106467 non-nice user cpu ticks
         1946 nice user cpu ticks
        37955 system cpu ticks
       316755 idle cpu ticks
          116 IO-wait cpu ticks
            0 IRQ cpu ticks
         3189 softirq cpu ticks
           59 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       913534 K paged in
       300300 K paged out
            0 pages swapped in
            0 pages swapped out
      2320179 interrupts
     10677336 CPU context switches
   1766033824 boot time
        25922 forks
