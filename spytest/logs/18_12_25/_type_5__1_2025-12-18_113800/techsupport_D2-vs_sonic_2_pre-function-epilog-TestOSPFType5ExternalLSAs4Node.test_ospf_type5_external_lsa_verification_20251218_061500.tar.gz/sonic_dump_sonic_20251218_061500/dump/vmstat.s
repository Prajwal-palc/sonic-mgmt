      3840632 K total memory
      2717448 K used memory
       390172 K active memory
      2665304 K inactive memory
       250452 K free memory
        42892 K buffer memory
      1104472 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       105663 non-nice user cpu ticks
         1739 nice user cpu ticks
        37191 system cpu ticks
       317707 idle cpu ticks
           99 IO-wait cpu ticks
            0 IRQ cpu ticks
         3435 softirq cpu ticks
           49 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       917213 K paged in
       298388 K paged out
            0 pages swapped in
            0 pages swapped out
      2299079 interrupts
     10694398 CPU context switches
   1766033827 boot time
        26002 forks
