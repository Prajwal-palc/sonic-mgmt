      3840620 K total memory
      2779800 K used memory
       381380 K active memory
      2777396 K inactive memory
       193784 K free memory
        41716 K buffer memory
      1097640 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        87955 non-nice user cpu ticks
         4160 nice user cpu ticks
        34275 system cpu ticks
       286443 idle cpu ticks
          151 IO-wait cpu ticks
            0 IRQ cpu ticks
         3241 softirq cpu ticks
           57 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       925888 K paged in
        95101 K paged out
            0 pages swapped in
            0 pages swapped out
      2091036 interrupts
      9613800 CPU context switches
   1766067245 boot time
        24248 forks
