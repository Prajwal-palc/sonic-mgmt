      3840620 K total memory
      2637008 K used memory
       380296 K active memory
      2592076 K inactive memory
       343452 K free memory
        41028 K buffer memory
      1099432 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        83690 non-nice user cpu ticks
         4129 nice user cpu ticks
        31538 system cpu ticks
       293086 idle cpu ticks
          170 IO-wait cpu ticks
            0 IRQ cpu ticks
         2874 softirq cpu ticks
           44 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       925251 K paged in
        90469 K paged out
            0 pages swapped in
            0 pages swapped out
      2071228 interrupts
      9472987 CPU context switches
   1766067251 boot time
        23247 forks
