      3840632 K total memory
      2800092 K used memory
       381432 K active memory
      2773272 K inactive memory
       171768 K free memory
        42732 K buffer memory
      1098060 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        85224 non-nice user cpu ticks
         4090 nice user cpu ticks
        31919 system cpu ticks
       292322 idle cpu ticks
          144 IO-wait cpu ticks
            0 IRQ cpu ticks
         2925 softirq cpu ticks
           45 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       922788 K paged in
        99397 K paged out
            0 pages swapped in
            0 pages swapped out
      2067938 interrupts
      9526143 CPU context switches
   1766067245 boot time
        23806 forks
