      3840632 K total memory
      2631792 K used memory
       380044 K active memory
      2638248 K inactive memory
       339008 K free memory
        41424 K buffer memory
      1100392 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        86603 non-nice user cpu ticks
         4240 nice user cpu ticks
        33526 system cpu ticks
       287922 idle cpu ticks
          156 IO-wait cpu ticks
            0 IRQ cpu ticks
         3092 softirq cpu ticks
           60 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       927424 K paged in
        95089 K paged out
            0 pages swapped in
            0 pages swapped out
      2141849 interrupts
      9608862 CPU context switches
   1766067251 boot time
        23678 forks
