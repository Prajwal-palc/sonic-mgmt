      3840620 K total memory
      2689160 K used memory
       396644 K active memory
      2642760 K inactive memory
       251384 K free memory
        69260 K buffer memory
      1103364 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       508505 non-nice user cpu ticks
         1967 nice user cpu ticks
       178773 system cpu ticks
      2066767 idle cpu ticks
          478 IO-wait cpu ticks
            0 IRQ cpu ticks
        20659 softirq cpu ticks
          345 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       993147 K paged in
       188357 K paged out
            0 pages swapped in
            0 pages swapped out
     12855937 interrupts
     57591836 CPU context switches
   1766038816 boot time
        49738 forks
