      3840632 K total memory
      2655140 K used memory
       397032 K active memory
      2633516 K inactive memory
       282148 K free memory
        68300 K buffer memory
      1107772 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       501189 non-nice user cpu ticks
         1867 nice user cpu ticks
       166995 system cpu ticks
      2087152 idle cpu ticks
          406 IO-wait cpu ticks
            0 IRQ cpu ticks
        20843 softirq cpu ticks
          294 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       987732 K paged in
       186093 K paged out
            0 pages swapped in
            0 pages swapped out
     12514467 interrupts
     56831778 CPU context switches
   1766038812 boot time
        49860 forks
