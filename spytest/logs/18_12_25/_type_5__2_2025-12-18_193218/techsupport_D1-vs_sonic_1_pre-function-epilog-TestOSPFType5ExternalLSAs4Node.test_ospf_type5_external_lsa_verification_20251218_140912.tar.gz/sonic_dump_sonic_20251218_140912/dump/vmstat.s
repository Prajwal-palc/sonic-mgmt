      3840620 K total memory
      2672708 K used memory
       396228 K active memory
      2645916 K inactive memory
       267008 K free memory
        69028 K buffer memory
      1104512 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       505024 non-nice user cpu ticks
         1918 nice user cpu ticks
       171268 system cpu ticks
      2079905 idle cpu ticks
          780 IO-wait cpu ticks
            0 IRQ cpu ticks
        20481 softirq cpu ticks
          329 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       996928 K paged in
       190621 K paged out
            0 pages swapped in
            0 pages swapped out
     12833977 interrupts
     57893970 CPU context switches
   1766038800 boot time
        49708 forks
