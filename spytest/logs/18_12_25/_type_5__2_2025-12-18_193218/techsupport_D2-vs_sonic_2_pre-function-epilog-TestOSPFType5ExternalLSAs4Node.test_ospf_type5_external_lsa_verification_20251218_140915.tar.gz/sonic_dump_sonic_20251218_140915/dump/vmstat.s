      3840620 K total memory
      2678692 K used memory
       400892 K active memory
      2682856 K inactive memory
       254968 K free memory
        71056 K buffer memory
      1108852 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       500262 non-nice user cpu ticks
         2009 nice user cpu ticks
       168536 system cpu ticks
      2087523 idle cpu ticks
          448 IO-wait cpu ticks
            0 IRQ cpu ticks
        20466 softirq cpu ticks
          304 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       989771 K paged in
       200701 K paged out
            0 pages swapped in
            0 pages swapped out
     12737580 interrupts
     57373471 CPU context switches
   1766038804 boot time
        50051 forks
