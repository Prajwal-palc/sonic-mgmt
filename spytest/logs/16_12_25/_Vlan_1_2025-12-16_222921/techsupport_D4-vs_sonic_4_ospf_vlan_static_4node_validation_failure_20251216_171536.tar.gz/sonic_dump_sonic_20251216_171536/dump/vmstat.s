      3840620 K total memory
      2827532 K used memory
       371092 K active memory
      2547136 K inactive memory
       424200 K free memory
       101588 K buffer memory
       758412 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       548972 non-nice user cpu ticks
         1993 nice user cpu ticks
       190864 system cpu ticks
      2258312 idle cpu ticks
          777 IO-wait cpu ticks
            0 IRQ cpu ticks
        25578 softirq cpu ticks
          329 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1129572 K paged in
       318297 K paged out
            0 pages swapped in
            0 pages swapped out
     17427553 interrupts
     74720685 CPU context switches
   1765874691 boot time
        54590 forks
