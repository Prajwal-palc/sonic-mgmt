      3840620 K total memory
      2661648 K used memory
       404116 K active memory
      2535668 K inactive memory
       387616 K free memory
       109084 K buffer memory
       956704 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       557521 non-nice user cpu ticks
         2029 nice user cpu ticks
       193150 system cpu ticks
      2305061 idle cpu ticks
         1104 IO-wait cpu ticks
            0 IRQ cpu ticks
        26313 softirq cpu ticks
          345 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1117010 K paged in
       328725 K paged out
            0 pages swapped in
            0 pages swapped out
     17706278 interrupts
     71001975 CPU context switches
   1765873911 boot time
        55419 forks
