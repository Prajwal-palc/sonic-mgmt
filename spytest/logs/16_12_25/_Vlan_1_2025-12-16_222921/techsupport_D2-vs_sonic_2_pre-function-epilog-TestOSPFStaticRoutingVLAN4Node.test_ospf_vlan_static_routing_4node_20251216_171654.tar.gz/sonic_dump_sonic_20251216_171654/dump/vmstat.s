      3840620 K total memory
      2663176 K used memory
       434884 K active memory
      2548892 K inactive memory
       342240 K free memory
       112196 K buffer memory
      1001456 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       562092 non-nice user cpu ticks
         4412 nice user cpu ticks
       196440 system cpu ticks
      2319128 idle cpu ticks
         1124 IO-wait cpu ticks
            0 IRQ cpu ticks
        26502 softirq cpu ticks
          348 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1154411 K paged in
       352397 K paged out
            0 pages swapped in
            0 pages swapped out
     17874753 interrupts
     71777011 CPU context switches
   1765873911 boot time
        61790 forks
