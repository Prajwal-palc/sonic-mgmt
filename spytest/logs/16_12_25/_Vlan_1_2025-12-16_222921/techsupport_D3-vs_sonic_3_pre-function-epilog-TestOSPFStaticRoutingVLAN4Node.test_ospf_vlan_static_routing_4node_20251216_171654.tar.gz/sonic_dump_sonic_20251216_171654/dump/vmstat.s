      3840620 K total memory
      2585188 K used memory
       439704 K active memory
      2562272 K inactive memory
       323728 K free memory
        92580 K buffer memory
      1115536 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       554225 non-nice user cpu ticks
         4428 nice user cpu ticks
       192134 system cpu ticks
      2295616 idle cpu ticks
          776 IO-wait cpu ticks
            0 IRQ cpu ticks
        24463 softirq cpu ticks
          333 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1037169 K paged in
       291589 K paged out
            0 pages swapped in
            0 pages swapped out
     16522864 interrupts
     70460056 CPU context switches
   1765874304 boot time
        61114 forks
