      3840620 K total memory
      2595180 K used memory
       424956 K active memory
      2584920 K inactive memory
       298236 K free memory
        90520 K buffer memory
      1131332 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       550931 non-nice user cpu ticks
         2008 nice user cpu ticks
       189358 system cpu ticks
      2288071 idle cpu ticks
          762 IO-wait cpu ticks
            0 IRQ cpu ticks
        24350 softirq cpu ticks
          330 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1004874 K paged in
       268169 K paged out
            0 pages swapped in
            0 pages swapped out
     16395949 interrupts
     69867764 CPU context switches
   1765874304 boot time
        54859 forks
