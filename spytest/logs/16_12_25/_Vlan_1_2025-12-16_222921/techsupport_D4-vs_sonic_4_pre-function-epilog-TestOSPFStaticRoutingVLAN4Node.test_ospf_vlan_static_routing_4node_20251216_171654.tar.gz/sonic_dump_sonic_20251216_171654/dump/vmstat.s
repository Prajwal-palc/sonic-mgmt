      3840620 K total memory
      2847016 K used memory
       405552 K active memory
      2569024 K inactive memory
       350696 K free memory
       104072 K buffer memory
       813828 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       550570 non-nice user cpu ticks
         4455 nice user cpu ticks
       193043 system cpu ticks
      2259159 idle cpu ticks
          800 IO-wait cpu ticks
            0 IRQ cpu ticks
        25634 softirq cpu ticks
          329 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1181171 K paged in
       339337 K paged out
            0 pages swapped in
            0 pages swapped out
     17514129 interrupts
     75130617 CPU context switches
   1765874691 boot time
        60790 forks
