      3840632 K total memory
      2712008 K used memory
       432468 K active memory
      2571532 K inactive memory
       281268 K free memory
        95068 K buffer memory
      1030592 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       572523 non-nice user cpu ticks
         4440 nice user cpu ticks
       194572 system cpu ticks
      2351524 idle cpu ticks
          878 IO-wait cpu ticks
            0 IRQ cpu ticks
        25455 softirq cpu ticks
          332 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1111627 K paged in
       309249 K paged out
            0 pages swapped in
            0 pages swapped out
     16971312 interrupts
     72436658 CPU context switches
   1765873517 boot time
        62436 forks
