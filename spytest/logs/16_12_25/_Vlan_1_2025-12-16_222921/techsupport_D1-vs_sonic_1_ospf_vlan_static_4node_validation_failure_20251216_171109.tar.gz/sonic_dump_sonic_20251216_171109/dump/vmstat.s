      3840632 K total memory
      2639392 K used memory
       401668 K active memory
      2491328 K inactive memory
       396280 K free memory
        91772 K buffer memory
       987472 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       566034 non-nice user cpu ticks
         1993 nice user cpu ticks
       190690 system cpu ticks
      2330909 idle cpu ticks
          835 IO-wait cpu ticks
            0 IRQ cpu ticks
        25209 softirq cpu ticks
          329 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1074459 K paged in
       281949 K paged out
            0 pages swapped in
            0 pages swapped out
     16758089 interrupts
     71466935 CPU context switches
   1765873517 boot time
        55845 forks
