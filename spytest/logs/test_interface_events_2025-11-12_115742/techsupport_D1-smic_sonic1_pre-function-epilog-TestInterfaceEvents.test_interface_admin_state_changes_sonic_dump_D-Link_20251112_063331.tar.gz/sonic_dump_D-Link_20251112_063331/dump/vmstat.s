      3845316 K total memory
      2714368 K used memory
       339356 K active memory
      2431924 K inactive memory
       389836 K free memory
       146096 K buffer memory
       595016 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6590672 non-nice user cpu ticks
        13549 nice user cpu ticks
      2950372 system cpu ticks
     46466108 idle cpu ticks
        14509 IO-wait cpu ticks
            0 IRQ cpu ticks
        72140 softirq cpu ticks
        42851 stolen cpu ticks
      3266223 pages paged in
      9570092 pages paged out
            0 pages swapped in
            0 pages swapped out
    732605610 interrupts
   1725693303 CPU context switches
   1762341321 boot time
       948784 forks
