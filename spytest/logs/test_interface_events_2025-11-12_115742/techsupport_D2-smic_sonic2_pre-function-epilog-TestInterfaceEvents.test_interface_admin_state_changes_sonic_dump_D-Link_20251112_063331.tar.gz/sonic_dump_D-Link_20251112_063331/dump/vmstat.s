      3845316 K total memory
      2811204 K used memory
       320740 K active memory
      2531292 K inactive memory
       315520 K free memory
       170828 K buffer memory
       547764 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
      6590862 non-nice user cpu ticks
        13730 nice user cpu ticks
      2908648 system cpu ticks
     46635649 idle cpu ticks
        15649 IO-wait cpu ticks
            0 IRQ cpu ticks
        71582 softirq cpu ticks
        43575 stolen cpu ticks
      3336629 pages paged in
      9710308 pages paged out
            0 pages swapped in
            0 pages swapped out
    724047907 interrupts
   1705664798 CPU context switches
   1762339277 boot time
       946431 forks
