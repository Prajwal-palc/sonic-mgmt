      3840620 K total memory
      2624640 K used memory
       444396 K active memory
      2575892 K inactive memory
       306568 K free memory
        49572 K buffer memory
      1137656 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        81377 non-nice user cpu ticks
         8778 nice user cpu ticks
        32582 system cpu ticks
       268829 idle cpu ticks
          245 IO-wait cpu ticks
            0 IRQ cpu ticks
          293 softirq cpu ticks
           44 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       972084 K paged in
       375300 K paged out
            0 pages swapped in
            0 pages swapped out
      2092104 interrupts
      8083546 CPU context switches
   1765343970 boot time
        48850 forks
