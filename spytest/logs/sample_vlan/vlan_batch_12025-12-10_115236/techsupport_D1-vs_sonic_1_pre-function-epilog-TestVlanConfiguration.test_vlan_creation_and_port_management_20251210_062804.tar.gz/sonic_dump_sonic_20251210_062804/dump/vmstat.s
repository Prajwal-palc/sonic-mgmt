      3840620 K total memory
      2636556 K used memory
       433900 K active memory
      2573104 K inactive memory
       306400 K free memory
        49652 K buffer memory
      1125980 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        85968 non-nice user cpu ticks
        11225 nice user cpu ticks
        35618 system cpu ticks
       277086 idle cpu ticks
          255 IO-wait cpu ticks
            0 IRQ cpu ticks
          338 softirq cpu ticks
           46 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       993348 K paged in
       395296 K paged out
            0 pages swapped in
            0 pages swapped out
      2238575 interrupts
      8671662 CPU context switches
   1765343970 boot time
        55484 forks
