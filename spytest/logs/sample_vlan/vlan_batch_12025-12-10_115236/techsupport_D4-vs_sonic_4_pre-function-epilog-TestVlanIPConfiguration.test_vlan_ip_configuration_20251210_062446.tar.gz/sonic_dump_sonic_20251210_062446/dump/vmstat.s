      3840632 K total memory
      2644696 K used memory
       417544 K active memory
      2599216 K inactive memory
       281356 K free memory
        47384 K buffer memory
      1146060 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        76374 non-nice user cpu ticks
         8800 nice user cpu ticks
        31286 system cpu ticks
       271770 idle cpu ticks
          101 IO-wait cpu ticks
            0 IRQ cpu ticks
          311 softirq cpu ticks
           41 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       938268 K paged in
       363876 K paged out
            0 pages swapped in
            0 pages swapped out
      1998164 interrupts
      7763794 CPU context switches
   1765343993 boot time
        46477 forks
