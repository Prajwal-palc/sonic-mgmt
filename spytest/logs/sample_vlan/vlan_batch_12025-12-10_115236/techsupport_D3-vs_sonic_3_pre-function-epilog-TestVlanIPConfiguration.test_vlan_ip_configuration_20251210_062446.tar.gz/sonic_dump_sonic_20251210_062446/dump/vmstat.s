      3840620 K total memory
      2649640 K used memory
       413928 K active memory
      2614308 K inactive memory
       282932 K free memory
        47312 K buffer memory
      1139736 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        76640 non-nice user cpu ticks
         9135 nice user cpu ticks
        31494 system cpu ticks
       271435 idle cpu ticks
          118 IO-wait cpu ticks
            0 IRQ cpu ticks
          315 softirq cpu ticks
           47 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       932905 K paged in
       364316 K paged out
            0 pages swapped in
            0 pages swapped out
      2031173 interrupts
      7841397 CPU context switches
   1765343987 boot time
        46385 forks
