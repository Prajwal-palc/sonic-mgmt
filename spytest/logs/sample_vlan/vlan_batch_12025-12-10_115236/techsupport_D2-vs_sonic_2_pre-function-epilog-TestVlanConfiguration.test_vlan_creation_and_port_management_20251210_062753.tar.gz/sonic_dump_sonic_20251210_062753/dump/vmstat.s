      3840620 K total memory
      2644796 K used memory
       419848 K active memory
      2578364 K inactive memory
       297956 K free memory
        48388 K buffer memory
      1128268 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        80466 non-nice user cpu ticks
        11065 nice user cpu ticks
        34419 system cpu ticks
       282220 idle cpu ticks
          134 IO-wait cpu ticks
            0 IRQ cpu ticks
          340 softirq cpu ticks
           55 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       952961 K paged in
       383804 K paged out
            0 pages swapped in
            0 pages swapped out
      2175687 interrupts
      8398835 CPU context switches
   1765343975 boot time
        50965 forks
