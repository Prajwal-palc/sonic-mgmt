      3840620 K total memory
      2615588 K used memory
       385348 K active memory
      2524300 K inactive memory
       429940 K free memory
        45240 K buffer memory
      1027508 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        79909 non-nice user cpu ticks
        11521 nice user cpu ticks
        34159 system cpu ticks
       281605 idle cpu ticks
          127 IO-wait cpu ticks
            0 IRQ cpu ticks
          347 softirq cpu ticks
           49 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       973819 K paged in
       384944 K paged out
            0 pages swapped in
            0 pages swapped out
      2165821 interrupts
      8383646 CPU context switches
   1765343987 boot time
        52634 forks
