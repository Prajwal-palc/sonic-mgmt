      3840632 K total memory
      2643688 K used memory
       415924 K active memory
      2595236 K inactive memory
       284420 K free memory
        48156 K buffer memory
      1143320 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        79838 non-nice user cpu ticks
        11306 nice user cpu ticks
        34194 system cpu ticks
       282039 idle cpu ticks
          109 IO-wait cpu ticks
            0 IRQ cpu ticks
          356 softirq cpu ticks
           44 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       947924 K paged in
       385600 K paged out
            0 pages swapped in
            0 pages swapped out
      2140981 interrupts
      8330862 CPU context switches
   1765343993 boot time
        52752 forks
