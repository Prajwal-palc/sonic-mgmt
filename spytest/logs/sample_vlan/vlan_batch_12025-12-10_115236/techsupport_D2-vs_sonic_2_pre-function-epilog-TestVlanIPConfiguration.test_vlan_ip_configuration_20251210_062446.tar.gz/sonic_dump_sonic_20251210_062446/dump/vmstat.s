      3840620 K total memory
      2649084 K used memory
       420796 K active memory
      2580876 K inactive memory
       292724 K free memory
        47708 K buffer memory
      1129716 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        77270 non-nice user cpu ticks
         8709 nice user cpu ticks
        31850 system cpu ticks
       272000 idle cpu ticks
          130 IO-wait cpu ticks
            0 IRQ cpu ticks
          293 softirq cpu ticks
           53 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       942810 K paged in
       362136 K paged out
            0 pages swapped in
            0 pages swapped out
      2042298 interrupts
      7855503 CPU context switches
   1765343975 boot time
        44680 forks
