      3840620 K total memory
      2627352 K used memory
       421352 K active memory
      2582152 K inactive memory
       312376 K free memory
        46496 K buffer memory
      1132872 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        71671 non-nice user cpu ticks
         6350 nice user cpu ticks
        28510 system cpu ticks
       250048 idle cpu ticks
          117 IO-wait cpu ticks
            0 IRQ cpu ticks
          249 softirq cpu ticks
           49 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       931082 K paged in
       341092 K paged out
            0 pages swapped in
            0 pages swapped out
      1841965 interrupts
      7075076 CPU context switches
   1765343975 boot time
        37823 forks
