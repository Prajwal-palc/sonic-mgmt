      3840632 K total memory
      2635644 K used memory
       417832 K active memory
      2598864 K inactive memory
       286952 K free memory
        46192 K buffer memory
      1150644 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        70867 non-nice user cpu ticks
         6517 nice user cpu ticks
        27963 system cpu ticks
       249948 idle cpu ticks
           91 IO-wait cpu ticks
            0 IRQ cpu ticks
          265 softirq cpu ticks
           38 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       922512 K paged in
       342816 K paged out
            0 pages swapped in
            0 pages swapped out
      1802144 interrupts
      6984598 CPU context switches
   1765343993 boot time
        39532 forks
