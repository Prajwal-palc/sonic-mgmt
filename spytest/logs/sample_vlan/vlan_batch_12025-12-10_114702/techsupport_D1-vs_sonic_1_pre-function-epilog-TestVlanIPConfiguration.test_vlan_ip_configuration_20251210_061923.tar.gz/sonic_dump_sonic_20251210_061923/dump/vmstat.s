      3840620 K total memory
      2627848 K used memory
       442860 K active memory
      2586112 K inactive memory
       292884 K free memory
        48352 K buffer memory
      1149620 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        75155 non-nice user cpu ticks
         6433 nice user cpu ticks
        28971 system cpu ticks
       248279 idle cpu ticks
          222 IO-wait cpu ticks
            0 IRQ cpu ticks
          249 softirq cpu ticks
           39 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       954283 K paged in
       352504 K paged out
            0 pages swapped in
            0 pages swapped out
      1881829 interrupts
      7265552 CPU context switches
   1765343970 boot time
        41609 forks
