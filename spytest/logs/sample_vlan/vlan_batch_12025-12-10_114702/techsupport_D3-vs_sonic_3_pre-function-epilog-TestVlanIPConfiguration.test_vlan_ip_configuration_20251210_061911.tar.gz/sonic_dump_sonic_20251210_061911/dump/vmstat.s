      3840620 K total memory
      2641748 K used memory
       416012 K active memory
      2607168 K inactive memory
       290500 K free memory
        46160 K buffer memory
      1145176 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        70940 non-nice user cpu ticks
         6744 nice user cpu ticks
        27993 system cpu ticks
       250052 idle cpu ticks
          108 IO-wait cpu ticks
            0 IRQ cpu ticks
          268 softirq cpu ticks
           42 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       915522 K paged in
       342772 K paged out
            0 pages swapped in
            0 pages swapped out
      1826266 interrupts
      7038468 CPU context switches
   1765343986 boot time
        39416 forks
