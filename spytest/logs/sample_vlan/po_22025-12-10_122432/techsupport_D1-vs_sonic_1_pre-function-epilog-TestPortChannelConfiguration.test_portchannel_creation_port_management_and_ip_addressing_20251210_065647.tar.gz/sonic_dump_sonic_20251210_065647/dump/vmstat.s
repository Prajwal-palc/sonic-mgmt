      3840620 K total memory
      2633576 K used memory
       449204 K active memory
      2563540 K inactive memory
       317632 K free memory
        54724 K buffer memory
      1114880 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       118789 non-nice user cpu ticks
        13579 nice user cpu ticks
        46617 system cpu ticks
       400903 idle cpu ticks
          326 IO-wait cpu ticks
            0 IRQ cpu ticks
          450 softirq cpu ticks
           64 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1027349 K paged in
       439660 K paged out
            0 pages swapped in
            0 pages swapped out
      3092281 interrupts
     11759587 CPU context switches
   1765343970 boot time
        67745 forks
