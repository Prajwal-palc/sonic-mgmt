      3840620 K total memory
      2657640 K used memory
       411496 K active memory
      2531056 K inactive memory
       367068 K free memory
        49848 K buffer memory
      1046952 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       104484 non-nice user cpu ticks
        14027 nice user cpu ticks
        43616 system cpu ticks
       415121 idle cpu ticks
          167 IO-wait cpu ticks
            0 IRQ cpu ticks
          462 softirq cpu ticks
           69 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1014747 K paged in
       419120 K paged out
            0 pages swapped in
            0 pages swapped out
      2971510 interrupts
     11287899 CPU context switches
   1765343986 boot time
        62673 forks
