      3840632 K total memory
      2690016 K used memory
       420292 K active memory
      2640800 K inactive memory
       236200 K free memory
        52576 K buffer memory
      1142492 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       104605 non-nice user cpu ticks
        13663 nice user cpu ticks
        43718 system cpu ticks
       414161 idle cpu ticks
          153 IO-wait cpu ticks
            0 IRQ cpu ticks
          467 softirq cpu ticks
           63 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       973577 K paged in
       418372 K paged out
            0 pages swapped in
            0 pages swapped out
      2936417 interrupts
     11197471 CPU context switches
   1765343993 boot time
        62740 forks
