      3840620 K total memory
      2640296 K used memory
       441364 K active memory
      2578796 K inactive memory
       295944 K free memory
        53376 K buffer memory
      1130520 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       107676 non-nice user cpu ticks
        13467 nice user cpu ticks
        44879 system cpu ticks
       413172 idle cpu ticks
          195 IO-wait cpu ticks
            0 IRQ cpu ticks
          460 softirq cpu ticks
           74 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1002233 K paged in
       423596 K paged out
            0 pages swapped in
            0 pages swapped out
      2995711 interrupts
     11359185 CPU context switches
   1765343975 boot time
        61998 forks
