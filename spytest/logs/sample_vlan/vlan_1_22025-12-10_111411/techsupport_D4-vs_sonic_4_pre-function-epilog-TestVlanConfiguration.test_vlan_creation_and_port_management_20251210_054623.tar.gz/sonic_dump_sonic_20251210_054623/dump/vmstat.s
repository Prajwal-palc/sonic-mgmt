      3840632 K total memory
      2612816 K used memory
       389268 K active memory
      2645752 K inactive memory
       324468 K free memory
        39580 K buffer memory
      1137428 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        43912 non-nice user cpu ticks
         1801 nice user cpu ticks
        16377 system cpu ticks
        99616 idle cpu ticks
           50 IO-wait cpu ticks
            0 IRQ cpu ticks
          129 softirq cpu ticks
           17 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       882490 K paged in
       288056 K paged out
            0 pages swapped in
            0 pages swapped out
       870904 interrupts
      3555251 CPU context switches
   1765343993 boot time
        23762 forks
