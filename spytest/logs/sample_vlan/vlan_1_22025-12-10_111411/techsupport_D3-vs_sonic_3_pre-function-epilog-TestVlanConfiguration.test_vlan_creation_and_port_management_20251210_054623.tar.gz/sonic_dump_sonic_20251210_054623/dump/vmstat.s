      3840620 K total memory
      2575636 K used memory
       390356 K active memory
      2588592 K inactive memory
       362732 K free memory
        39740 K buffer memory
      1136312 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        43606 non-nice user cpu ticks
         1845 nice user cpu ticks
        16077 system cpu ticks
       100867 idle cpu ticks
           67 IO-wait cpu ticks
            0 IRQ cpu ticks
          124 softirq cpu ticks
           18 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       880823 K paged in
       287072 K paged out
            0 pages swapped in
            0 pages swapped out
       879905 interrupts
      3600340 CPU context switches
   1765343987 boot time
        23754 forks
