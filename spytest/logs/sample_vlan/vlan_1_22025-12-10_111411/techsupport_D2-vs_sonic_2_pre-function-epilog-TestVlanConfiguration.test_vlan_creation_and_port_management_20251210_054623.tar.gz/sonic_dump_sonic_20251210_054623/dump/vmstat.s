      3840620 K total memory
      2597376 K used memory
       390036 K active memory
      2581932 K inactive memory
       339344 K free memory
        39840 K buffer memory
      1137480 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        44264 non-nice user cpu ticks
         1626 nice user cpu ticks
        16531 system cpu ticks
       100692 idle cpu ticks
           75 IO-wait cpu ticks
            0 IRQ cpu ticks
          111 softirq cpu ticks
           26 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       880096 K paged in
       287668 K paged out
            0 pages swapped in
            0 pages swapped out
       892097 interrupts
      3625061 CPU context switches
   1765343975 boot time
        22058 forks
