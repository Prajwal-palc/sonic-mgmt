      3840620 K total memory
      2592632 K used memory
       409544 K active memory
      2591848 K inactive memory
       323744 K free memory
        40732 K buffer memory
      1157972 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        46815 non-nice user cpu ticks
         1691 nice user cpu ticks
        16856 system cpu ticks
        99549 idle cpu ticks
          165 IO-wait cpu ticks
            0 IRQ cpu ticks
          125 softirq cpu ticks
           18 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       896967 K paged in
       287908 K paged out
            0 pages swapped in
            0 pages swapped out
       926313 interrupts
      3769661 CPU context switches
   1765343970 boot time
        24930 forks
