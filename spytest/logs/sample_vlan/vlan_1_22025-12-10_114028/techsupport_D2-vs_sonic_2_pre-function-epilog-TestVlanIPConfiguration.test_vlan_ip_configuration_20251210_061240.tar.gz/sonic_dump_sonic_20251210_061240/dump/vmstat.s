      3840620 K total memory
      2632144 K used memory
       414624 K active memory
      2588492 K inactive memory
       308180 K free memory
        45080 K buffer memory
      1130480 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        65496 non-nice user cpu ticks
         4013 nice user cpu ticks
        24869 system cpu ticks
       224022 idle cpu ticks
          106 IO-wait cpu ticks
            0 IRQ cpu ticks
          198 softirq cpu ticks
           45 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       912419 K paged in
       321792 K paged out
            0 pages swapped in
            0 pages swapped out
      1614816 interrupts
      6204266 CPU context switches
   1765343975 boot time
        30942 forks
