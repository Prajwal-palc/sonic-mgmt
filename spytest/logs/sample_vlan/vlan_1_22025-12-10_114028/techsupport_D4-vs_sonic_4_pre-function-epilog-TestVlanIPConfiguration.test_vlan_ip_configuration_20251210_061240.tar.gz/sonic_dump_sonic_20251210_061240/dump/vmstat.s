      3840632 K total memory
      2634348 K used memory
       411480 K active memory
      2608344 K inactive memory
       284964 K free memory
        44736 K buffer memory
      1154100 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        64847 non-nice user cpu ticks
         4180 nice user cpu ticks
        24509 system cpu ticks
       223117 idle cpu ticks
           80 IO-wait cpu ticks
            0 IRQ cpu ticks
          217 softirq cpu ticks
           34 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       909216 K paged in
       323460 K paged out
            0 pages swapped in
            0 pages swapped out
      1585236 interrupts
      6132263 CPU context switches
   1765343993 boot time
        32640 forks
