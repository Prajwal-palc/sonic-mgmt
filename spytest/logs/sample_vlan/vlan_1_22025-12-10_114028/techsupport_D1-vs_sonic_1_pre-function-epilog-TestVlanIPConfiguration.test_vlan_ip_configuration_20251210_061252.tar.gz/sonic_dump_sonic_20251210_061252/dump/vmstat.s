      3840620 K total memory
      2640264 K used memory
       430344 K active memory
      2594176 K inactive memory
       280076 K free memory
        46832 K buffer memory
      1149668 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        68088 non-nice user cpu ticks
         4062 nice user cpu ticks
        25110 system cpu ticks
       222632 idle cpu ticks
          205 IO-wait cpu ticks
            0 IRQ cpu ticks
          205 softirq cpu ticks
           34 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       922923 K paged in
       326180 K paged out
            0 pages swapped in
            0 pages swapped out
      1646205 interrupts
      6361172 CPU context switches
   1765343970 boot time
        34153 forks
