      3840620 K total memory
      2626496 K used memory
       408492 K active memory
      2612960 K inactive memory
       298628 K free memory
        44708 K buffer memory
      1148452 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        64817 non-nice user cpu ticks
         4323 nice user cpu ticks
        24346 system cpu ticks
       223979 idle cpu ticks
           97 IO-wait cpu ticks
            0 IRQ cpu ticks
          214 softirq cpu ticks
           36 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       901238 K paged in
       320744 K paged out
            0 pages swapped in
            0 pages swapped out
      1599895 interrupts
      6169738 CPU context switches
   1765343987 boot time
        32546 forks
