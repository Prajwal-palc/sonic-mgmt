      3840620 K total memory
      2626700 K used memory
       461008 K active memory
      2613996 K inactive memory
       257328 K free memory
       136428 K buffer memory
      1101820 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       767933 non-nice user cpu ticks
         2325 nice user cpu ticks
       230430 system cpu ticks
      5296872 idle cpu ticks
         1244 IO-wait cpu ticks
            0 IRQ cpu ticks
         2222 softirq cpu ticks
          661 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1194022 K paged in
       479369 K paged out
            0 pages swapped in
            0 pages swapped out
     27088203 interrupts
     93453213 CPU context switches
   1765279292 boot time
       103597 forks
