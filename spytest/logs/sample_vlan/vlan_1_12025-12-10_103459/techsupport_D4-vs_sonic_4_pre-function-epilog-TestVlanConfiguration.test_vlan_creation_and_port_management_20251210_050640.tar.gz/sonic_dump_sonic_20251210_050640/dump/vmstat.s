      3840620 K total memory
      2695228 K used memory
       489232 K active memory
      2634540 K inactive memory
       190968 K free memory
       150176 K buffer memory
      1086296 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       761972 non-nice user cpu ticks
         2353 nice user cpu ticks
       233865 system cpu ticks
      5301550 idle cpu ticks
         1524 IO-wait cpu ticks
            0 IRQ cpu ticks
         2344 softirq cpu ticks
          620 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1210871 K paged in
       589033 K paged out
            0 pages swapped in
            0 pages swapped out
     26630721 interrupts
     92727482 CPU context switches
   1765279287 boot time
       105486 forks
