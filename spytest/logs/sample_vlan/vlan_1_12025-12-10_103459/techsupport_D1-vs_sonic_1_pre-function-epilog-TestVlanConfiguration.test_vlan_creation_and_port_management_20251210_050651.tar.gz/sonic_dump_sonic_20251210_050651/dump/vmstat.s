      3840620 K total memory
      2652600 K used memory
       476544 K active memory
      2599760 K inactive memory
       234000 K free memory
       137500 K buffer memory
      1096944 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       773702 non-nice user cpu ticks
         2299 nice user cpu ticks
       235602 system cpu ticks
      5293080 idle cpu ticks
         1323 IO-wait cpu ticks
            0 IRQ cpu ticks
         2282 softirq cpu ticks
          650 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1207831 K paged in
       493157 K paged out
            0 pages swapped in
            0 pages swapped out
     26660153 interrupts
     93009158 CPU context switches
   1765279276 boot time
       104306 forks
