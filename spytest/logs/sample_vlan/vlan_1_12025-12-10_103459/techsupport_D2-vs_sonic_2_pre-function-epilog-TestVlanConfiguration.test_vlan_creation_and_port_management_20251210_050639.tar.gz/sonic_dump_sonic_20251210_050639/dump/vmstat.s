      3840620 K total memory
      2744196 K used memory
       493248 K active memory
      2688676 K inactive memory
       115028 K free memory
       158728 K buffer memory
      1105368 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       773059 non-nice user cpu ticks
         2314 nice user cpu ticks
       237391 system cpu ticks
      5286001 idle cpu ticks
         1569 IO-wait cpu ticks
            0 IRQ cpu ticks
         2334 softirq cpu ticks
          674 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1202344 K paged in
       621281 K paged out
            0 pages swapped in
            0 pages swapped out
     26976777 interrupts
     93484239 CPU context switches
   1765279282 boot time
       105453 forks
