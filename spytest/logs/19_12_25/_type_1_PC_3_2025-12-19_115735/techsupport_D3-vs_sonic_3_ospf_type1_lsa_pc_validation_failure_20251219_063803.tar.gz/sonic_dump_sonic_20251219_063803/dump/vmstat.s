      3840620 K total memory
      2731848 K used memory
       405104 K active memory
      2662304 K inactive memory
       237564 K free memory
        46072 K buffer memory
      1100864 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        98827 non-nice user cpu ticks
         1766 nice user cpu ticks
        37413 system cpu ticks
       256517 idle cpu ticks
          150 IO-wait cpu ticks
            0 IRQ cpu ticks
         2760 softirq cpu ticks
           47 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       933815 K paged in
       319808 K paged out
            0 pages swapped in
            0 pages swapped out
      2083701 interrupts
      9463063 CPU context switches
   1766122300 boot time
        28785 forks
