      3840620 K total memory
      2730116 K used memory
       415504 K active memory
      2684112 K inactive memory
       224008 K free memory
        48608 K buffer memory
      1114412 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       102043 non-nice user cpu ticks
         1765 nice user cpu ticks
        38476 system cpu ticks
       244001 idle cpu ticks
          157 IO-wait cpu ticks
            0 IRQ cpu ticks
         2550 softirq cpu ticks
           47 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       929234 K paged in
       328116 K paged out
            0 pages swapped in
            0 pages swapped out
      2115268 interrupts
      9556878 CPU context switches
   1766122297 boot time
        31006 forks
