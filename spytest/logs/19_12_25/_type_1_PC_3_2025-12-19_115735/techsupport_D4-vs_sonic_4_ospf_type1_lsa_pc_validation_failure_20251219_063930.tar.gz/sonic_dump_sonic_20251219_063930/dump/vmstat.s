      3840620 K total memory
      2691144 K used memory
       419632 K active memory
      2642980 K inactive memory
       259912 K free memory
        48876 K buffer memory
      1117156 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       102123 non-nice user cpu ticks
         1765 nice user cpu ticks
        38719 system cpu ticks
       259993 idle cpu ticks
          162 IO-wait cpu ticks
            0 IRQ cpu ticks
         2895 softirq cpu ticks
           55 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       940259 K paged in
       329420 K paged out
            0 pages swapped in
            0 pages swapped out
      2157495 interrupts
      9758058 CPU context switches
   1766122305 boot time
        30143 forks
