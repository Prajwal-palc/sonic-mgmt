      3840620 K total memory
      2697680 K used memory
       409388 K active memory
      2619048 K inactive memory
       311756 K free memory
        47108 K buffer memory
      1061708 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       102460 non-nice user cpu ticks
         4306 nice user cpu ticks
        40395 system cpu ticks
       264435 idle cpu ticks
          174 IO-wait cpu ticks
            0 IRQ cpu ticks
         2904 softirq cpu ticks
           43 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       987772 K paged in
       342212 K paged out
            0 pages swapped in
            0 pages swapped out
      2208510 interrupts
     10113177 CPU context switches
   1766122294 boot time
        35294 forks
