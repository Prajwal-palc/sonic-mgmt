      3840620 K total memory
      2714716 K used memory
       413692 K active memory
      2616144 K inactive memory
       268072 K free memory
        49108 K buffer memory
      1087524 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       104173 non-nice user cpu ticks
         4172 nice user cpu ticks
        41196 system cpu ticks
       260875 idle cpu ticks
          163 IO-wait cpu ticks
            0 IRQ cpu ticks
         2966 softirq cpu ticks
           56 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       990490 K paged in
       355400 K paged out
            0 pages swapped in
            0 pages swapped out
      2249214 interrupts
     10191128 CPU context switches
   1766122305 boot time
        36400 forks
