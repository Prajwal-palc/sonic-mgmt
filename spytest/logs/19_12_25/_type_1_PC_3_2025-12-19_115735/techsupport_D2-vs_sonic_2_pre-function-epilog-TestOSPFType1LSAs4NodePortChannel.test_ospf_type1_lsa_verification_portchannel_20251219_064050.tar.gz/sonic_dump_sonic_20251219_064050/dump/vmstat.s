      3840620 K total memory
      2671040 K used memory
       422224 K active memory
      2611524 K inactive memory
       307964 K free memory
        49848 K buffer memory
      1090132 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       107394 non-nice user cpu ticks
         4299 nice user cpu ticks
        42290 system cpu ticks
       257776 idle cpu ticks
          165 IO-wait cpu ticks
            0 IRQ cpu ticks
         2745 softirq cpu ticks
           50 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       986693 K paged in
       354788 K paged out
            0 pages swapped in
            0 pages swapped out
      2300051 interrupts
     10384457 CPU context switches
   1766122297 boot time
        37484 forks
