      3840620 K total memory
      2699496 K used memory
       421516 K active memory
      2616484 K inactive memory
       298552 K free memory
        47648 K buffer memory
      1072364 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       102362 non-nice user cpu ticks
         4249 nice user cpu ticks
        40526 system cpu ticks
       263824 idle cpu ticks
          155 IO-wait cpu ticks
            0 IRQ cpu ticks
         2888 softirq cpu ticks
           49 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       982874 K paged in
       343852 K paged out
            0 pages swapped in
            0 pages swapped out
      2219528 interrupts
     10087956 CPU context switches
   1766122300 boot time
        35143 forks
