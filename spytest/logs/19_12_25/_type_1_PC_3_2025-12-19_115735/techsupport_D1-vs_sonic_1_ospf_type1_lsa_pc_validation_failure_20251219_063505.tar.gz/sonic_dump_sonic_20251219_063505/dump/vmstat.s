      3840620 K total memory
      2718552 K used memory
       387536 K active memory
      2673620 K inactive memory
       262232 K free memory
        44888 K buffer memory
      1090988 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        95898 non-nice user cpu ticks
         1815 nice user cpu ticks
        36129 system cpu ticks
       244163 idle cpu ticks
          163 IO-wait cpu ticks
            0 IRQ cpu ticks
         2655 softirq cpu ticks
           40 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       937307 K paged in
       317368 K paged out
            0 pages swapped in
            0 pages swapped out
      1992015 interrupts
      9136870 CPU context switches
   1766122294 boot time
        28776 forks
