      3840632 K total memory
      2617104 K used memory
       395636 K active memory
      2602968 K inactive memory
       309204 K free memory
        61796 K buffer memory
      1129112 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       271191 non-nice user cpu ticks
         1939 nice user cpu ticks
        88100 system cpu ticks
      1673399 idle cpu ticks
          325 IO-wait cpu ticks
            0 IRQ cpu ticks
          860 softirq cpu ticks
          225 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1010687 K paged in
       172073 K paged out
            0 pages swapped in
            0 pages swapped out
      8938576 interrupts
     31045608 CPU context switches
   1765255523 boot time
        42931 forks
