      3840620 K total memory
      2619172 K used memory
       378504 K active memory
      2606836 K inactive memory
       339064 K free memory
        48384 K buffer memory
      1104100 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       159603 non-nice user cpu ticks
         1752 nice user cpu ticks
        54766 system cpu ticks
       941651 idle cpu ticks
          195 IO-wait cpu ticks
            0 IRQ cpu ticks
          496 softirq cpu ticks
          157 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       953341 K paged in
       114161 K paged out
            0 pages swapped in
            0 pages swapped out
      5100731 interrupts
     17770146 CPU context switches
   1765264436 boot time
        27979 forks
