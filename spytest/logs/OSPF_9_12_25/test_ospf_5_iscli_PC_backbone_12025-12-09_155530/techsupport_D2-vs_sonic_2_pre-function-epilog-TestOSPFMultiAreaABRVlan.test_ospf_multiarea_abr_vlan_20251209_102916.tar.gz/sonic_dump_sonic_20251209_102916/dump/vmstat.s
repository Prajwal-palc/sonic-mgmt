      3840620 K total memory
      2591788 K used memory
       374200 K active memory
      2573748 K inactive memory
       379220 K free memory
        48324 K buffer memory
      1091100 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       154419 non-nice user cpu ticks
         1844 nice user cpu ticks
        48427 system cpu ticks
       955317 idle cpu ticks
          215 IO-wait cpu ticks
            0 IRQ cpu ticks
          457 softirq cpu ticks
          136 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       942510 K paged in
       111249 K paged out
            0 pages swapped in
            0 pages swapped out
      5170791 interrupts
     18009089 CPU context switches
   1765264420 boot time
        27926 forks
