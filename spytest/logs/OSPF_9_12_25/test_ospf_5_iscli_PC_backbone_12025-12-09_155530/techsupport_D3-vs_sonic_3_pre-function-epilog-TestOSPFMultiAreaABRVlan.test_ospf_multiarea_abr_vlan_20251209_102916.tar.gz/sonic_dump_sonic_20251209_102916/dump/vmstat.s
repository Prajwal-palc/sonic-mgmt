      3840620 K total memory
      2634096 K used memory
       394000 K active memory
      2617744 K inactive memory
       303576 K free memory
        61516 K buffer memory
      1113772 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       266251 non-nice user cpu ticks
         1814 nice user cpu ticks
        87824 system cpu ticks
      1676597 idle cpu ticks
          319 IO-wait cpu ticks
            0 IRQ cpu ticks
          877 softirq cpu ticks
          267 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1016358 K paged in
       169881 K paged out
            0 pages swapped in
            0 pages swapped out
      8904278 interrupts
     30788553 CPU context switches
   1765255545 boot time
        42338 forks
