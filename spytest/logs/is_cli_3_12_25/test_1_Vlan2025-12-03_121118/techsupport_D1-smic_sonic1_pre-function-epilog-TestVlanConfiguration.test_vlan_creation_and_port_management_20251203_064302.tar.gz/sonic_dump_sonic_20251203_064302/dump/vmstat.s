      3840620 K total memory
      2622880 K used memory
       420708 K active memory
      2608552 K inactive memory
       278656 K free memory
        47668 K buffer memory
      1166540 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        88886 non-nice user cpu ticks
         1673 nice user cpu ticks
        28568 system cpu ticks
       306275 idle cpu ticks
          178 IO-wait cpu ticks
            0 IRQ cpu ticks
          243 softirq cpu ticks
           57 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       918262 K paged in
       316116 K paged out
            0 pages swapped in
            0 pages swapped out
      2168460 interrupts
      7866526 CPU context switches
   1764739911 boot time
        30593 forks
