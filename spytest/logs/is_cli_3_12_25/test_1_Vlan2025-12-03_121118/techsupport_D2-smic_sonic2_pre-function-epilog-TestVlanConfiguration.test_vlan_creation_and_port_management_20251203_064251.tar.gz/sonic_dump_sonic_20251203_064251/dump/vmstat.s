      3840620 K total memory
      2549692 K used memory
       416584 K active memory
      2559476 K inactive memory
       359460 K free memory
        46156 K buffer memory
      1159480 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        75568 non-nice user cpu ticks
         1613 nice user cpu ticks
        24670 system cpu ticks
       321729 idle cpu ticks
          142 IO-wait cpu ticks
            0 IRQ cpu ticks
          211 softirq cpu ticks
           44 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       906888 K paged in
       307844 K paged out
            0 pages swapped in
            0 pages swapped out
      2026653 interrupts
      7525155 CPU context switches
   1764739917 boot time
        27586 forks
