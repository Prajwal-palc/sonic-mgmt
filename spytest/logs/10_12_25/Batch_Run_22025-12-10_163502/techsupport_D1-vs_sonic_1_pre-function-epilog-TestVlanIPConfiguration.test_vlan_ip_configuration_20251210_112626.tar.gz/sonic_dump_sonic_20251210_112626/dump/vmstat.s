      3840620 K total memory
      1881760 K used memory
       410344 K active memory
      2057088 K inactive memory
      1095512 K free memory
        46904 K buffer memory
      1083436 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        83676 non-nice user cpu ticks
         6459 nice user cpu ticks
        29622 system cpu ticks
       294269 idle cpu ticks
          246 IO-wait cpu ticks
            0 IRQ cpu ticks
          329 softirq cpu ticks
           47 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       977203 K paged in
       141469 K paged out
            0 pages swapped in
            0 pages swapped out
      2186772 interrupts
      8032120 CPU context switches
   1765361820 boot time
        35302 forks
