      3840620 K total memory
      2606208 K used memory
       379892 K active memory
      2570076 K inactive memory
       361064 K free memory
        43340 K buffer memory
      1102488 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        65391 non-nice user cpu ticks
         6755 nice user cpu ticks
        26281 system cpu ticks
       313765 idle cpu ticks
          152 IO-wait cpu ticks
            0 IRQ cpu ticks
          299 softirq cpu ticks
           46 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       954185 K paged in
       120785 K paged out
            0 pages swapped in
            0 pages swapped out
      2054846 interrupts
      7547449 CPU context switches
   1765361832 boot time
        31221 forks
