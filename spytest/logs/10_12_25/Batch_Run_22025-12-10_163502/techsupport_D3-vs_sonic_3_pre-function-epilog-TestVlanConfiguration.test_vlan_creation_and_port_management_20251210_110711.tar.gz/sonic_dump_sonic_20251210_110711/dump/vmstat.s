      3840620 K total memory
      2623892 K used memory
       344476 K active memory
      2576660 K inactive memory
       402244 K free memory
        37552 K buffer memory
      1052768 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        46806 non-nice user cpu ticks
         1663 nice user cpu ticks
        16703 system cpu ticks
       233835 idle cpu ticks
          100 IO-wait cpu ticks
            0 IRQ cpu ticks
          168 softirq cpu ticks
           33 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       903663 K paged in
        70857 K paged out
            0 pages swapped in
            0 pages swapped out
      1443571 interrupts
      5258422 CPU context switches
   1765361840 boot time
        16515 forks
