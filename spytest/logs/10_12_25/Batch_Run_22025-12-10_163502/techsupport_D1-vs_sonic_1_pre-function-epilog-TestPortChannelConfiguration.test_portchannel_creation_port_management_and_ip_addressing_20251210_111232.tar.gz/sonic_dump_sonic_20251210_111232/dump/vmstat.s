      3840620 K total memory
      2659880 K used memory
       388028 K active memory
      2637596 K inactive memory
       325240 K free memory
        42948 K buffer memory
      1083256 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        59475 non-nice user cpu ticks
         4033 nice user cpu ticks
        21922 system cpu ticks
       247152 idle cpu ticks
          218 IO-wait cpu ticks
            0 IRQ cpu ticks
          239 softirq cpu ticks
           37 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       958072 K paged in
       105697 K paged out
            0 pages swapped in
            0 pages swapped out
      1713371 interrupts
      6311064 CPU context switches
   1765361820 boot time
        25503 forks
