      3840632 K total memory
      2637180 K used memory
       396556 K active memory
      2608136 K inactive memory
       326896 K free memory
        45552 K buffer memory
      1103364 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        71353 non-nice user cpu ticks
         6511 nice user cpu ticks
        27316 system cpu ticks
       307892 idle cpu ticks
          161 IO-wait cpu ticks
            0 IRQ cpu ticks
          305 softirq cpu ticks
           44 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       961277 K paged in
       131917 K paged out
            0 pages swapped in
            0 pages swapped out
      2049896 interrupts
      7625872 CPU context switches
   1765361823 boot time
        32940 forks
