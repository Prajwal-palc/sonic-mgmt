      3840620 K total memory
      2570244 K used memory
       359776 K active memory
      2533068 K inactive memory
       476476 K free memory
        39784 K buffer memory
      1023472 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        51802 non-nice user cpu ticks
         4027 nice user cpu ticks
        19866 system cpu ticks
       253874 idle cpu ticks
          110 IO-wait cpu ticks
            0 IRQ cpu ticks
          211 softirq cpu ticks
           36 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       944613 K paged in
        94797 K paged out
            0 pages swapped in
            0 pages swapped out
      1632334 interrupts
      6004723 CPU context switches
   1765361840 boot time
        23250 forks
