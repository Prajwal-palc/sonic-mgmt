      3840632 K total memory
      2624528 K used memory
       382424 K active memory
      2616700 K inactive memory
       343416 K free memory
        42480 K buffer memory
      1102364 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        57088 non-nice user cpu ticks
         4201 nice user cpu ticks
        21582 system cpu ticks
       249264 idle cpu ticks
          138 IO-wait cpu ticks
            0 IRQ cpu ticks
          229 softirq cpu ticks
           36 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       946370 K paged in
       103613 K paged out
            0 pages swapped in
            0 pages swapped out
      1627239 interrupts
      6059539 CPU context switches
   1765361823 boot time
        24581 forks
