      3840632 K total memory
      2649624 K used memory
       364820 K active memory
      2610408 K inactive memory
       343772 K free memory
        39384 K buffer memory
      1076008 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        51318 non-nice user cpu ticks
         1664 nice user cpu ticks
        18083 system cpu ticks
       229801 idle cpu ticks
          128 IO-wait cpu ticks
            0 IRQ cpu ticks
          176 softirq cpu ticks
           33 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       927381 K paged in
        78213 K paged out
            0 pages swapped in
            0 pages swapped out
      1428158 interrupts
      5275752 CPU context switches
   1765361823 boot time
        17407 forks
