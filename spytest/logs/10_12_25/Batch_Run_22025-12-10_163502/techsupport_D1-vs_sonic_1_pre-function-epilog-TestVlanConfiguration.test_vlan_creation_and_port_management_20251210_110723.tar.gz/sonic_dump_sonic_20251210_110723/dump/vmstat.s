      3840620 K total memory
      2662704 K used memory
       365544 K active memory
      2649100 K inactive memory
       327616 K free memory
        39836 K buffer memory
      1079240 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        51979 non-nice user cpu ticks
         1652 nice user cpu ticks
        18070 system cpu ticks
       230113 idle cpu ticks
          206 IO-wait cpu ticks
            0 IRQ cpu ticks
          186 softirq cpu ticks
           33 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       929950 K paged in
        82641 K paged out
            0 pages swapped in
            0 pages swapped out
      1500360 interrupts
      5485249 CPU context switches
   1765361820 boot time
        17923 forks
