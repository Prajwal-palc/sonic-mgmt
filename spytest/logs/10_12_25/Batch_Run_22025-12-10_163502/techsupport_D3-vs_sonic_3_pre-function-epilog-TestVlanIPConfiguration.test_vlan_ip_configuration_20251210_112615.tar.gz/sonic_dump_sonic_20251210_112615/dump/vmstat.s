      3840620 K total memory
      2596160 K used memory
       382264 K active memory
      2523932 K inactive memory
       435072 K free memory
        42640 K buffer memory
      1038072 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        64282 non-nice user cpu ticks
         6448 nice user cpu ticks
        25351 system cpu ticks
       315566 idle cpu ticks
          134 IO-wait cpu ticks
            0 IRQ cpu ticks
          289 softirq cpu ticks
           45 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       968489 K paged in
       123401 K paged out
            0 pages swapped in
            0 pages swapped out
      2058708 interrupts
      7551568 CPU context switches
   1765361840 boot time
        30961 forks
