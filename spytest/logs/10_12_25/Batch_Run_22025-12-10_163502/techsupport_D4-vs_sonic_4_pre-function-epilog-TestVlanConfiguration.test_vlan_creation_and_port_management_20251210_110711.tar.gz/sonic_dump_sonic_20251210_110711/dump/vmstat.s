      3840620 K total memory
      2591492 K used memory
       357000 K active memory
      2570620 K inactive memory
       405708 K free memory
        37748 K buffer memory
      1074044 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        47661 non-nice user cpu ticks
         1819 nice user cpu ticks
        17519 system cpu ticks
       233601 idle cpu ticks
          114 IO-wait cpu ticks
            0 IRQ cpu ticks
          185 softirq cpu ticks
           33 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       923521 K paged in
        74033 K paged out
            0 pages swapped in
            0 pages swapped out
      1443945 interrupts
      5295777 CPU context switches
   1765361832 boot time
        16768 forks
