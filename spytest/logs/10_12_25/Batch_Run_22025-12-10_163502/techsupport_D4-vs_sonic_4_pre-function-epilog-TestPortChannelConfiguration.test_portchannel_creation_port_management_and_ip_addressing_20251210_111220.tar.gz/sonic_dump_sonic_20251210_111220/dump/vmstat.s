      3840620 K total memory
      2614644 K used memory
       366548 K active memory
      2577332 K inactive memory
       359772 K free memory
        40616 K buffer memory
      1097848 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        52882 non-nice user cpu ticks
         4396 nice user cpu ticks
        20849 system cpu ticks
       252624 idle cpu ticks
          124 IO-wait cpu ticks
            0 IRQ cpu ticks
          232 softirq cpu ticks
           36 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       941128 K paged in
        95041 K paged out
            0 pages swapped in
            0 pages swapped out
      1640397 interrupts
      6036655 CPU context switches
   1765361832 boot time
        23528 forks
