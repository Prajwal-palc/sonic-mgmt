     31977784 K total memory
      4947268 K used memory
       839588 K active memory
      5688496 K inactive memory
     24598908 K free memory
       344680 K buffer memory
      3003580 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
     32461560 non-nice user cpu ticks
        15234 nice user cpu ticks
     11465888 system cpu ticks
    549570634 idle cpu ticks
        54213 IO-wait cpu ticks
            0 IRQ cpu ticks
        88150 softirq cpu ticks
            0 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
     13057437 K paged in
      5764308 K paged out
            0 pages swapped in
            0 pages swapped out
   1801909110 interrupts
   4823394605 CPU context switches
   1764997122 boot time
     10591302 forks
