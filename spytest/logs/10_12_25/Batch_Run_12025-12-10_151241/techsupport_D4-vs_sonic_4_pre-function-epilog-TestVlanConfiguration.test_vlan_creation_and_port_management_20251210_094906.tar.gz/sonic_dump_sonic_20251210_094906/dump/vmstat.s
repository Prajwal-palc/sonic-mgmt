      3840620 K total memory
      2439872 K used memory
       336860 K active memory
      2408416 K inactive memory
       585184 K free memory
        33532 K buffer memory
      1048248 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        17598 non-nice user cpu ticks
         1786 nice user cpu ticks
         8119 system cpu ticks
        52271 idle cpu ticks
          115 IO-wait cpu ticks
            0 IRQ cpu ticks
           63 softirq cpu ticks
            9 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       883936 K paged in
        49585 K paged out
            0 pages swapped in
            0 pages swapped out
       462814 interrupts
      1857233 CPU context switches
   1765359384 boot time
        11460 forks
