      3840620 K total memory
      2451776 K used memory
       358060 K active memory
      2428316 K inactive memory
       547436 K free memory
        34360 K buffer memory
      1074660 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        25493 non-nice user cpu ticks
         1675 nice user cpu ticks
         9382 system cpu ticks
        45825 idle cpu ticks
          392 IO-wait cpu ticks
            0 IRQ cpu ticks
           71 softirq cpu ticks
            9 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       881798 K paged in
        53285 K paged out
            0 pages swapped in
            0 pages swapped out
       526325 interrupts
      2109987 CPU context switches
   1765359367 boot time
        13259 forks
