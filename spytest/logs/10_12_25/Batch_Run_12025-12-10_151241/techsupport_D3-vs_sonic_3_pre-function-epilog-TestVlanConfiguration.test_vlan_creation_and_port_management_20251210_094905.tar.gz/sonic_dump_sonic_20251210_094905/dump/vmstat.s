      3840620 K total memory
      2450852 K used memory
       336880 K active memory
      2413688 K inactive memory
       574236 K free memory
        33220 K buffer memory
      1048540 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        17302 non-nice user cpu ticks
         1598 nice user cpu ticks
         7728 system cpu ticks
        52289 idle cpu ticks
          135 IO-wait cpu ticks
            0 IRQ cpu ticks
           60 softirq cpu ticks
            8 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       885561 K paged in
        51113 K paged out
            0 pages swapped in
            0 pages swapped out
       448970 interrupts
      1832149 CPU context switches
   1765359390 boot time
        11418 forks
