      3840620 K total memory
      2453888 K used memory
       337560 K active memory
      2412088 K inactive memory
       573816 K free memory
        33856 K buffer memory
      1049872 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        17490 non-nice user cpu ticks
         1655 nice user cpu ticks
         7952 system cpu ticks
        53349 idle cpu ticks
          163 IO-wait cpu ticks
            0 IRQ cpu ticks
           65 softirq cpu ticks
            8 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       854905 K paged in
        52241 K paged out
            0 pages swapped in
            0 pages swapped out
       457616 interrupts
      1849869 CPU context switches
   1765359375 boot time
        11428 forks
