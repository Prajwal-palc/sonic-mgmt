      3840632 K total memory
      2697784 K used memory
       414056 K active memory
      2586848 K inactive memory
       336952 K free memory
        44844 K buffer memory
      1037164 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        95732 non-nice user cpu ticks
         8957 nice user cpu ticks
        39404 system cpu ticks
       221371 idle cpu ticks
          156 IO-wait cpu ticks
            0 IRQ cpu ticks
         2481 softirq cpu ticks
           45 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1001600 K paged in
       352820 K paged out
            0 pages swapped in
            0 pages swapped out
      2109337 interrupts
      9596104 CPU context switches
   1766467660 boot time
        42863 forks
