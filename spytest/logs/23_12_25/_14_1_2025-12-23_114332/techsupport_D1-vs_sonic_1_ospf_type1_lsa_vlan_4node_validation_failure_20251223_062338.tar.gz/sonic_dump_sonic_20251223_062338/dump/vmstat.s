      3840620 K total memory
      2730668 K used memory
       415360 K active memory
      2613192 K inactive memory
       272524 K free memory
        43540 K buffer memory
      1070600 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        85733 non-nice user cpu ticks
         6867 nice user cpu ticks
        34596 system cpu ticks
       208475 idle cpu ticks
          273 IO-wait cpu ticks
            0 IRQ cpu ticks
         2291 softirq cpu ticks
           38 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       997950 K paged in
       335540 K paged out
            0 pages swapped in
            0 pages swapped out
      1853484 interrupts
      8574945 CPU context switches
   1766467641 boot time
        36498 forks
