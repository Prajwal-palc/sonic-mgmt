      3840620 K total memory
      2724348 K used memory
       413456 K active memory
      2592364 K inactive memory
       301436 K free memory
        43768 K buffer memory
      1047096 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        88000 non-nice user cpu ticks
         6436 nice user cpu ticks
        36276 system cpu ticks
       219257 idle cpu ticks
          272 IO-wait cpu ticks
            0 IRQ cpu ticks
         2438 softirq cpu ticks
           46 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1014917 K paged in
       336820 K paged out
            0 pages swapped in
            0 pages swapped out
      1935034 interrupts
      8898741 CPU context switches
   1766467657 boot time
        34998 forks
