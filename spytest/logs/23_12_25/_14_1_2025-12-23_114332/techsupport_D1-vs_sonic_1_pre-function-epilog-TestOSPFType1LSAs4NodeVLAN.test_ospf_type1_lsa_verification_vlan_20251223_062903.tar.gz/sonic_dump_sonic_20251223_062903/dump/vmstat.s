      3840620 K total memory
      2714760 K used memory
       423364 K active memory
      2605764 K inactive memory
       291788 K free memory
        44568 K buffer memory
      1066268 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        92310 non-nice user cpu ticks
         9406 nice user cpu ticks
        38620 system cpu ticks
       227535 idle cpu ticks
          280 IO-wait cpu ticks
            0 IRQ cpu ticks
         2539 softirq cpu ticks
           44 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1018028 K paged in
       356696 K paged out
            0 pages swapped in
            0 pages swapped out
      2063275 interrupts
      9520924 CPU context switches
   1766467641 boot time
        42868 forks
