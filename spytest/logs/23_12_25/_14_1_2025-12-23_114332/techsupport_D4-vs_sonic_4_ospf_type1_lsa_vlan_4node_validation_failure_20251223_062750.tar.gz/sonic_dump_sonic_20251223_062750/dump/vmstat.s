      3840632 K total memory
      2708492 K used memory
       417892 K active memory
      2590880 K inactive memory
       315812 K free memory
        44444 K buffer memory
      1047868 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        94045 non-nice user cpu ticks
         6579 nice user cpu ticks
        37209 system cpu ticks
       220700 idle cpu ticks
          155 IO-wait cpu ticks
            0 IRQ cpu ticks
         2429 softirq cpu ticks
           44 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       987433 K paged in
       337888 K paged out
            0 pages swapped in
            0 pages swapped out
      2025240 interrupts
      9191602 CPU context switches
   1766467660 boot time
        36827 forks
