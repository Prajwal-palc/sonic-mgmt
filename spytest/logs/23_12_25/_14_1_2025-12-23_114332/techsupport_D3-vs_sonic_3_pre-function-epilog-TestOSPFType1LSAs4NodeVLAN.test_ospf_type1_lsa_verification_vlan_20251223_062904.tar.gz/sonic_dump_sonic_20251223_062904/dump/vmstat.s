      3840620 K total memory
      2723236 K used memory
       411828 K active memory
      2593132 K inactive memory
       306704 K free memory
        44348 K buffer memory
      1042508 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        91165 non-nice user cpu ticks
         8952 nice user cpu ticks
        39107 system cpu ticks
       226234 idle cpu ticks
          276 IO-wait cpu ticks
            0 IRQ cpu ticks
         2556 softirq cpu ticks
           48 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1022039 K paged in
       358896 K paged out
            0 pages swapped in
            0 pages swapped out
      2062510 interrupts
      9490465 CPU context switches
   1766467657 boot time
        41112 forks
