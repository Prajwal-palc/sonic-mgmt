      3840632 K total memory
      2719076 K used memory
       409716 K active memory
      2607320 K inactive memory
       283904 K free memory
        45592 K buffer memory
      1069456 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        94705 non-nice user cpu ticks
         8795 nice user cpu ticks
        38680 system cpu ticks
       223560 idle cpu ticks
          267 IO-wait cpu ticks
            0 IRQ cpu ticks
         2629 softirq cpu ticks
           42 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       993305 K paged in
       361348 K paged out
            0 pages swapped in
            0 pages swapped out
      2074995 interrupts
      9532533 CPU context switches
   1766467653 boot time
        43849 forks
