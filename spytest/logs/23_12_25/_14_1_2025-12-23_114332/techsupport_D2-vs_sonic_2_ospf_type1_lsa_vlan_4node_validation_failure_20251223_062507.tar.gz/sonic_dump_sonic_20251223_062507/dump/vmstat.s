      3840632 K total memory
      2717064 K used memory
       404372 K active memory
      2644260 K inactive memory
       274976 K free memory
        44612 K buffer memory
      1081144 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        90030 non-nice user cpu ticks
         6440 nice user cpu ticks
        35332 system cpu ticks
       210749 idle cpu ticks
          257 IO-wait cpu ticks
            0 IRQ cpu ticks
         2438 softirq cpu ticks
           39 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       974782 K paged in
       339332 K paged out
            0 pages swapped in
            0 pages swapped out
      1913035 interrupts
      8790647 CPU context switches
   1766467653 boot time
        37622 forks
