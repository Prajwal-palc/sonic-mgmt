      3840620 K total memory
      2754508 K used memory
       461104 K active memory
      2594212 K inactive memory
       262356 K free memory
        82116 K buffer memory
      1023804 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       352117 non-nice user cpu ticks
        16705 nice user cpu ticks
       132209 system cpu ticks
      1270934 idle cpu ticks
          645 IO-wait cpu ticks
            0 IRQ cpu ticks
        12819 softirq cpu ticks
          195 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1131959 K paged in
       537236 K paged out
            0 pages swapped in
            0 pages swapped out
      8688333 interrupts
     39384163 CPU context switches
   1766467641 boot time
        83532 forks
