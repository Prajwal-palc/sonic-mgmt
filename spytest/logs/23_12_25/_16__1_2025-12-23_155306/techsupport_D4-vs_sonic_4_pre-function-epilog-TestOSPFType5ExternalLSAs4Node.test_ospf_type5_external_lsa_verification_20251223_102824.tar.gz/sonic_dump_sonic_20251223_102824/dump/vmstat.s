      3840632 K total memory
      2725408 K used memory
       467248 K active memory
      2563164 K inactive memory
       287992 K free memory
        91140 K buffer memory
      1017952 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       352333 non-nice user cpu ticks
        16255 nice user cpu ticks
       132812 system cpu ticks
      1268584 idle cpu ticks
          594 IO-wait cpu ticks
            0 IRQ cpu ticks
        12727 softirq cpu ticks
          193 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1101004 K paged in
       562388 K paged out
            0 pages swapped in
            0 pages swapped out
      8805230 interrupts
     39627584 CPU context switches
   1766467660 boot time
        83685 forks
