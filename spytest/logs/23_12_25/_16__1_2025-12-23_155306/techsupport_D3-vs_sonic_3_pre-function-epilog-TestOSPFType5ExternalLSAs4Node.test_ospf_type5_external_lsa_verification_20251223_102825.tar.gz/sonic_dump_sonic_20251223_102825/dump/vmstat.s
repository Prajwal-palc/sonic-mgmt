      3840620 K total memory
      2720572 K used memory
       436568 K active memory
      2563388 K inactive memory
       317908 K free memory
        79744 K buffer memory
      1005544 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       352627 non-nice user cpu ticks
        16574 nice user cpu ticks
       136870 system cpu ticks
      1264527 idle cpu ticks
          634 IO-wait cpu ticks
            0 IRQ cpu ticks
        13024 softirq cpu ticks
          238 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1138946 K paged in
       537500 K paged out
            0 pages swapped in
            0 pages swapped out
      8774061 interrupts
     39480576 CPU context switches
   1766467656 boot time
        81434 forks
