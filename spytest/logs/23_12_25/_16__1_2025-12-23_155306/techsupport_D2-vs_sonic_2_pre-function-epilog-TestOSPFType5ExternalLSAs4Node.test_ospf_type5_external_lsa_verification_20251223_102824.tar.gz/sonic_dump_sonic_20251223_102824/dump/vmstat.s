      3840632 K total memory
      2709292 K used memory
       449224 K active memory
      2575720 K inactive memory
       298004 K free memory
        86944 K buffer memory
      1029228 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       352572 non-nice user cpu ticks
        16284 nice user cpu ticks
       135085 system cpu ticks
      1265273 idle cpu ticks
          671 IO-wait cpu ticks
            0 IRQ cpu ticks
        13270 softirq cpu ticks
          228 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1095937 K paged in
       560412 K paged out
            0 pages swapped in
            0 pages swapped out
      8746559 interrupts
     39268858 CPU context switches
   1766467652 boot time
        84693 forks
