      3840620 K total memory
      2679124 K used memory
       383168 K active memory
      2610812 K inactive memory
       355736 K free memory
        38864 K buffer memory
      1041972 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        59735 non-nice user cpu ticks
         4058 nice user cpu ticks
        25058 system cpu ticks
       132768 idle cpu ticks
          227 IO-wait cpu ticks
            0 IRQ cpu ticks
         1507 softirq cpu ticks
           31 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       977480 K paged in
       302276 K paged out
            0 pages swapped in
            0 pages swapped out
      1244952 interrupts
      5804260 CPU context switches
   1766467657 boot time
        25050 forks
