      3840620 K total memory
      2683168 K used memory
       393184 K active memory
      2659844 K inactive memory
       288280 K free memory
        38428 K buffer memory
      1103972 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        53460 non-nice user cpu ticks
         1880 nice user cpu ticks
        20193 system cpu ticks
       115368 idle cpu ticks
          208 IO-wait cpu ticks
            0 IRQ cpu ticks
         1234 softirq cpu ticks
           21 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       904021 K paged in
       274572 K paged out
            0 pages swapped in
            0 pages swapped out
      1035432 interrupts
      4874773 CPU context switches
   1766467642 boot time
        20231 forks
