      3840632 K total memory
      2680024 K used memory
       365576 K active memory
      2612748 K inactive memory
       376732 K free memory
        36092 K buffer memory
      1018100 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        60500 non-nice user cpu ticks
         1697 nice user cpu ticks
        22754 system cpu ticks
       129707 idle cpu ticks
           98 IO-wait cpu ticks
            0 IRQ cpu ticks
         1413 softirq cpu ticks
           28 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       928953 K paged in
       277004 K paged out
            0 pages swapped in
            0 pages swapped out
      1188747 interrupts
      5440455 CPU context switches
   1766467661 boot time
        20282 forks
