      3840632 K total memory
      2682336 K used memory
       391948 K active memory
      2668320 K inactive memory
       271356 K free memory
        39648 K buffer memory
      1121304 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        56241 non-nice user cpu ticks
         1667 nice user cpu ticks
        21029 system cpu ticks
       119053 idle cpu ticks
          200 IO-wait cpu ticks
            0 IRQ cpu ticks
         1363 softirq cpu ticks
           23 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       897640 K paged in
       280064 K paged out
            0 pages swapped in
            0 pages swapped out
      1086328 interrupts
      5070604 CPU context switches
   1766467652 boot time
        20921 forks
