      3840632 K total memory
      2712408 K used memory
       390452 K active memory
      2653356 K inactive memory
       258608 K free memory
        40148 K buffer memory
      1105368 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        61129 non-nice user cpu ticks
         4076 nice user cpu ticks
        24383 system cpu ticks
       132682 idle cpu ticks
          217 IO-wait cpu ticks
            0 IRQ cpu ticks
         1567 softirq cpu ticks
           25 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       940776 K paged in
       304064 K paged out
            0 pages swapped in
            0 pages swapped out
      1253932 interrupts
      5845042 CPU context switches
   1766467652 boot time
        27290 forks
