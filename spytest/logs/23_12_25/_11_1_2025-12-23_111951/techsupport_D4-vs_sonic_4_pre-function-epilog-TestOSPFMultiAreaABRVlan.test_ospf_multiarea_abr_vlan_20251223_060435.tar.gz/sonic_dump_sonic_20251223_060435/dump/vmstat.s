      3840632 K total memory
      2720204 K used memory
       392928 K active memory
      2620428 K inactive memory
       296844 K free memory
        38844 K buffer memory
      1060976 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        62104 non-nice user cpu ticks
         4098 nice user cpu ticks
        25002 system cpu ticks
       130465 idle cpu ticks
          109 IO-wait cpu ticks
            0 IRQ cpu ticks
         1465 softirq cpu ticks
           28 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       965636 K paged in
       298432 K paged out
            0 pages swapped in
            0 pages swapped out
      1274963 interrupts
      5847777 CPU context switches
   1766467661 boot time
        26295 forks
