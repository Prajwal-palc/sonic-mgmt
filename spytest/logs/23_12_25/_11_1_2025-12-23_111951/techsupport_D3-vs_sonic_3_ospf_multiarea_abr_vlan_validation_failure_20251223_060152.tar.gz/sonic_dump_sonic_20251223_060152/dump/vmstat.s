      3840620 K total memory
      2720364 K used memory
       389268 K active memory
      2665232 K inactive memory
       253352 K free memory
        38284 K buffer memory
      1101984 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        56365 non-nice user cpu ticks
         1657 nice user cpu ticks
        22133 system cpu ticks
       125612 idle cpu ticks
          207 IO-wait cpu ticks
            0 IRQ cpu ticks
         1380 softirq cpu ticks
           30 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       902217 K paged in
       276356 K paged out
            0 pages swapped in
            0 pages swapped out
      1116344 interrupts
      5205808 CPU context switches
   1766467657 boot time
        18829 forks
