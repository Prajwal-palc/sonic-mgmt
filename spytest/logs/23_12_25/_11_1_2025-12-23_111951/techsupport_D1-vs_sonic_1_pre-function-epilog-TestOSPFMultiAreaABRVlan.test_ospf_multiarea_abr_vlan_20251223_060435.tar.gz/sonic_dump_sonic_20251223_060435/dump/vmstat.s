      3840620 K total memory
      2687900 K used memory
       395568 K active memory
      2648316 K inactive memory
       299480 K free memory
        39540 K buffer memory
      1088732 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        59960 non-nice user cpu ticks
         4412 nice user cpu ticks
        24232 system cpu ticks
       135325 idle cpu ticks
          233 IO-wait cpu ticks
            0 IRQ cpu ticks
         1480 softirq cpu ticks
           25 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       953137 K paged in
       299116 K paged out
            0 pages swapped in
            0 pages swapped out
      1241574 interrupts
      5821225 CPU context switches
   1766467642 boot time
        26642 forks
