      3840632 K total memory
      2715404 K used memory
       468172 K active memory
      2546996 K inactive memory
       315412 K free memory
        95468 K buffer memory
       996984 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       382108 non-nice user cpu ticks
        18769 nice user cpu ticks
       144633 system cpu ticks
      1351962 idle cpu ticks
          630 IO-wait cpu ticks
            0 IRQ cpu ticks
        13675 softirq cpu ticks
          209 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1141946 K paged in
       601512 K paged out
            0 pages swapped in
            0 pages swapped out
      9517012 interrupts
     42804285 CPU context switches
   1766467660 boot time
        94283 forks
