      3840620 K total memory
      2728572 K used memory
       448024 K active memory
      2569104 K inactive memory
       305944 K free memory
        82756 K buffer memory
      1006868 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       375649 non-nice user cpu ticks
        19210 nice user cpu ticks
       141923 system cpu ticks
      1338034 idle cpu ticks
          713 IO-wait cpu ticks
            0 IRQ cpu ticks
        13664 softirq cpu ticks
          207 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1208180 K paged in
       720868 K paged out
            0 pages swapped in
            0 pages swapped out
      9333135 interrupts
     41988156 CPU context switches
   1766467641 boot time
        92798 forks
