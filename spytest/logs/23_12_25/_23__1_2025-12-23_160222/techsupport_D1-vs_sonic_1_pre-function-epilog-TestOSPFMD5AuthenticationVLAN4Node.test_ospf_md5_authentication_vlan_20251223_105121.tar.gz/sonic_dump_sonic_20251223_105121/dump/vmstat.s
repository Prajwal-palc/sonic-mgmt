      3840620 K total memory
      2717664 K used memory
       460572 K active memory
      2538660 K inactive memory
       323676 K free memory
        83800 K buffer memory
       998912 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       381760 non-nice user cpu ticks
        21681 nice user cpu ticks
       145677 system cpu ticks
      1357665 idle cpu ticks
          736 IO-wait cpu ticks
            0 IRQ cpu ticks
        13887 softirq cpu ticks
          210 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1223709 K paged in
       741620 K paged out
            0 pages swapped in
            0 pages swapped out
      9532415 interrupts
     42909223 CPU context switches
   1766467641 boot time
        99045 forks
