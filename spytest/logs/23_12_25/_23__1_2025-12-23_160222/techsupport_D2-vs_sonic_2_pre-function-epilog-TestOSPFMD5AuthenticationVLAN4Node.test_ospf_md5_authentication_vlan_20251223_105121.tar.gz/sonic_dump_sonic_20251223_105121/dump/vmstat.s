      3840632 K total memory
      2709288 K used memory
       473340 K active memory
      2533728 K inactive memory
       318164 K free memory
        90640 K buffer memory
      1006192 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       382931 non-nice user cpu ticks
        20951 nice user cpu ticks
       148561 system cpu ticks
      1351804 idle cpu ticks
          717 IO-wait cpu ticks
            0 IRQ cpu ticks
        14356 softirq cpu ticks
          246 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1139275 K paged in
       611820 K paged out
            0 pages swapped in
            0 pages swapped out
      9527968 interrupts
     42830174 CPU context switches
   1766467652 boot time
       101221 forks
