      3840632 K total memory
      2732188 K used memory
       470992 K active memory
      2544336 K inactive memory
       284236 K free memory
        90828 K buffer memory
      1017060 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       378260 non-nice user cpu ticks
        18582 nice user cpu ticks
       145270 system cpu ticks
      1337879 idle cpu ticks
          707 IO-wait cpu ticks
            0 IRQ cpu ticks
        14175 softirq cpu ticks
          242 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1125101 K paged in
       593644 K paged out
            0 pages swapped in
            0 pages swapped out
      9364132 interrupts
     42066079 CPU context switches
   1766467652 boot time
        95000 forks
