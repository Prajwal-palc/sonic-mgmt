      3840620 K total memory
      2751960 K used memory
       442844 K active memory
      2552504 K inactive memory
       291868 K free memory
        83808 K buffer memory
       995396 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       381525 non-nice user cpu ticks
        21436 nice user cpu ticks
       150192 system cpu ticks
      1351151 idle cpu ticks
          677 IO-wait cpu ticks
            0 IRQ cpu ticks
        14023 softirq cpu ticks
          258 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1161565 K paged in
       587928 K paged out
            0 pages swapped in
            0 pages swapped out
      9539657 interrupts
     42933664 CPU context switches
   1766467656 boot time
        96880 forks
