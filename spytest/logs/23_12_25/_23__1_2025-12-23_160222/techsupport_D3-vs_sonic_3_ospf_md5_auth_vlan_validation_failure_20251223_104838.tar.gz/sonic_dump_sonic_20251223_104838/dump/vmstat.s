      3840620 K total memory
      2733972 K used memory
       440976 K active memory
      2556984 K inactive memory
       308312 K free memory
        83468 K buffer memory
       997208 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       377982 non-nice user cpu ticks
        18964 nice user cpu ticks
       147231 system cpu ticks
      1343534 idle cpu ticks
          673 IO-wait cpu ticks
            0 IRQ cpu ticks
        13897 softirq cpu ticks
          255 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1153242 K paged in
       570872 K paged out
            0 pages swapped in
            0 pages swapped out
      9406252 interrupts
     42313746 CPU context switches
   1766467656 boot time
        90739 forks
