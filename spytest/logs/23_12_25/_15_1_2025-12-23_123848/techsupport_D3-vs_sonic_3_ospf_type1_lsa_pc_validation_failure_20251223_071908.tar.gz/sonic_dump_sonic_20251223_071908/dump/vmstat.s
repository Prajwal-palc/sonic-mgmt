      3840620 K total memory
      2731044 K used memory
       424108 K active memory
      2600128 K inactive memory
       282448 K free memory
        53232 K buffer memory
      1053416 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       148008 non-nice user cpu ticks
        11400 nice user cpu ticks
        60820 system cpu ticks
       438799 idle cpu ticks
          364 IO-wait cpu ticks
            0 IRQ cpu ticks
         4734 softirq cpu ticks
           86 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1045357 K paged in
       407152 K paged out
            0 pages swapped in
            0 pages swapped out
      3495629 interrupts
     15927360 CPU context switches
   1766467657 boot time
        52460 forks
