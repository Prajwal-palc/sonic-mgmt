      3840632 K total memory
      2724484 K used memory
       431812 K active memory
      2577912 K inactive memory
       291608 K free memory
        57628 K buffer memory
      1044588 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       154444 non-nice user cpu ticks
        13801 nice user cpu ticks
        62853 system cpu ticks
       444785 idle cpu ticks
          386 IO-wait cpu ticks
            0 IRQ cpu ticks
         4970 softirq cpu ticks
           78 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1038308 K paged in
       437596 K paged out
            0 pages swapped in
            0 pages swapped out
      3640915 interrupts
     16569244 CPU context switches
   1766467653 boot time
        61618 forks
