      3840620 K total memory
      2745036 K used memory
       440768 K active memory
      2582576 K inactive memory
       267420 K free memory
        54308 K buffer memory
      1050972 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       151528 non-nice user cpu ticks
        14237 nice user cpu ticks
        62191 system cpu ticks
       448952 idle cpu ticks
          371 IO-wait cpu ticks
            0 IRQ cpu ticks
         4850 softirq cpu ticks
           78 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1060169 K paged in
       421076 K paged out
            0 pages swapped in
            0 pages swapped out
      3618430 interrupts
     16537932 CPU context switches
   1766467642 boot time
        60407 forks
