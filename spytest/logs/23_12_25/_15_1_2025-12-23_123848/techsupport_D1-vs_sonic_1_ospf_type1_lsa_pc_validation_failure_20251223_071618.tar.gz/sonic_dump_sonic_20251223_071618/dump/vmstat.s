      3840620 K total memory
      2733180 K used memory
       438344 K active memory
      2589476 K inactive memory
       275676 K free memory
        53168 K buffer memory
      1055692 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       145321 non-nice user cpu ticks
        11830 nice user cpu ticks
        58342 system cpu ticks
       429094 idle cpu ticks
          362 IO-wait cpu ticks
            0 IRQ cpu ticks
         4595 softirq cpu ticks
           75 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1050657 K paged in
       401540 K paged out
            0 pages swapped in
            0 pages swapped out
      3414211 interrupts
     15602819 CPU context switches
   1766467642 boot time
        54093 forks
