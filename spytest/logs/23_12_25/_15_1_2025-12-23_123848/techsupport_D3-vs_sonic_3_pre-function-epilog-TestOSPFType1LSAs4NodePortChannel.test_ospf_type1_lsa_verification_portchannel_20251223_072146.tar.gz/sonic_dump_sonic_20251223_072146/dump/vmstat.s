      3840620 K total memory
      2696688 K used memory
       389232 K active memory
      2552920 K inactive memory
       398136 K free memory
        53144 K buffer memory
       970416 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       151174 non-nice user cpu ticks
        13739 nice user cpu ticks
        63511 system cpu ticks
       446169 idle cpu ticks
          373 IO-wait cpu ticks
            0 IRQ cpu ticks
         4854 softirq cpu ticks
           87 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1076906 K paged in
       426872 K paged out
            0 pages swapped in
            0 pages swapped out
      3618818 interrupts
     16506553 CPU context switches
   1766467657 boot time
        58480 forks
