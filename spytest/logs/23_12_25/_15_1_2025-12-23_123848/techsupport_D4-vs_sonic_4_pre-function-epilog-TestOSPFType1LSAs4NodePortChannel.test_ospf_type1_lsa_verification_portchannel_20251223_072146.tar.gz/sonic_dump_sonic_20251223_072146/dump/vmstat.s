      3840632 K total memory
      2743640 K used memory
       439400 K active memory
      2575504 K inactive memory
       283024 K free memory
        57176 K buffer memory
      1033336 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       154643 non-nice user cpu ticks
        13811 nice user cpu ticks
        62747 system cpu ticks
       443837 idle cpu ticks
          270 IO-wait cpu ticks
            0 IRQ cpu ticks
         4683 softirq cpu ticks
           78 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1043934 K paged in
       434244 K paged out
            0 pages swapped in
            0 pages swapped out
      3677160 interrupts
     16651395 CPU context switches
   1766467661 boot time
        60613 forks
