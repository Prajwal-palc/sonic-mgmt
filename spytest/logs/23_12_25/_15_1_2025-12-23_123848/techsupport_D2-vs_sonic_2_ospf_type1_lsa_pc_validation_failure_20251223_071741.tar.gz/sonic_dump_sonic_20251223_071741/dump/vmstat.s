      3840632 K total memory
      2731160 K used memory
       429620 K active memory
      2585720 K inactive memory
       279404 K free memory
        56652 K buffer memory
      1051028 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       149412 non-nice user cpu ticks
        11284 nice user cpu ticks
        59225 system cpu ticks
       431584 idle cpu ticks
          378 IO-wait cpu ticks
            0 IRQ cpu ticks
         4767 softirq cpu ticks
           74 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1028533 K paged in
       417084 K paged out
            0 pages swapped in
            0 pages swapped out
      3467900 interrupts
     15787369 CPU context switches
   1766467653 boot time
        55413 forks
