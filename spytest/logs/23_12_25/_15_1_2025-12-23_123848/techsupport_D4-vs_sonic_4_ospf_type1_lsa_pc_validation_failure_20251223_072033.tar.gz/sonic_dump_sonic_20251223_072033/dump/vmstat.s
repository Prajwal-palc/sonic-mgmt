      3840632 K total memory
      2719416 K used memory
       435264 K active memory
      2592164 K inactive memory
       294976 K free memory
        56912 K buffer memory
      1045764 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       152976 non-nice user cpu ticks
        11369 nice user cpu ticks
        60508 system cpu ticks
       442897 idle cpu ticks
          269 IO-wait cpu ticks
            0 IRQ cpu ticks
         4622 softirq cpu ticks
           78 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
      1033902 K paged in
       414924 K paged out
            0 pages swapped in
            0 pages swapped out
      3589076 interrupts
     16242766 CPU context switches
   1766467661 boot time
        54713 forks
