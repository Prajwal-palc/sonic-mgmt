      3845316 K total memory
      2699748 K used memory
       401180 K active memory
      2561896 K inactive memory
       254696 K free memory
        59512 K buffer memory
       831360 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       104396 non-nice user cpu ticks
        15025 nice user cpu ticks
        55674 system cpu ticks
       447938 idle cpu ticks
          698 IO-wait cpu ticks
            0 IRQ cpu ticks
          842 softirq cpu ticks
          408 stolen cpu ticks
      1029257 pages paged in
       339436 pages paged out
            0 pages swapped in
            0 pages swapped out
      8365480 interrupts
     23057867 CPU context switches
   1763011716 boot time
        65838 forks
