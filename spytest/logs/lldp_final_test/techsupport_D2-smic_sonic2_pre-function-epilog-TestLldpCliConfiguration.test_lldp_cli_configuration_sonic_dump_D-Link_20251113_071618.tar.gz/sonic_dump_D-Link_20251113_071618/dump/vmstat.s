      3845316 K total memory
      2618700 K used memory
       414080 K active memory
      2468552 K inactive memory
       331652 K free memory
        58228 K buffer memory
       836736 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
        97256 non-nice user cpu ticks
        14223 nice user cpu ticks
        52067 system cpu ticks
       459074 idle cpu ticks
          755 IO-wait cpu ticks
            0 IRQ cpu ticks
          883 softirq cpu ticks
          447 stolen cpu ticks
      1008882 pages paged in
       341744 pages paged out
            0 pages swapped in
            0 pages swapped out
      8318260 interrupts
     22994414 CPU context switches
   1763011705 boot time
        63374 forks
